import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mtp/app-shell";
import { bootstrapMiner } from "@/lib/mtp/functions";

export const Route = createFileRoute("/")({
  loader: () => bootstrapMiner({ data: {} }),
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  return <AppShell initial={initial} />;
}
