import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main className="mx-auto max-w-xl px-5 py-10 text-fg">
      <p className="text-xs uppercase tracking-[0.14em] text-subtle">Ghairo</p>
      <h1 className="mt-2 font-display text-3xl font-semibold">Privacy</h1>
      <div className="mt-6 space-y-3 text-sm leading-relaxed text-muted">
        <p>
          We store your Telegram user id, display name, username, miner balances, connected TON address,
          task completions, and withdrawal or deposit records in MongoDB.
        </p>
        <p>
          Liveness checks run in your browser. We store motion scores and the review status, not a video
          recording of your face.
        </p>
        <p>
          Wallet connection uses TonConnect. The app never moves funds from your wallet without a transfer
          you approve in the wallet itself.
        </p>
      </div>
      <Link to="/" className="mt-8 inline-block text-sm text-mint">
        Back
      </Link>
    </main>
  );
}
