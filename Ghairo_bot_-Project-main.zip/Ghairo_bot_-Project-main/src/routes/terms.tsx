import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  component: TermsPage,
});

function TermsPage() {
  return (
    <main className="mx-auto max-w-xl px-5 py-10 text-fg">
      <p className="text-xs uppercase tracking-[0.14em] text-subtle">Ghairo</p>
      <h1 className="mt-2 font-display text-3xl font-semibold">Terms of use</h1>
      <div className="mt-6 space-y-3 text-sm leading-relaxed text-muted">
        <p>
          Ghairo is a Telegram Mini App for mining the Ghairo token. Connecting a TON wallet is required
          before withdrawals. Withdrawals are reviewed by an operator and are not automatic.
        </p>
        <p>
          Income comes from the gems you unlock. Each gem earns a fixed percentage of its price every day, and your first gem is bought with the free signup coin. Deposits are credited to your balance at the rate shown
          in the Deposit tab. Inviters receive 25% of the deposits made by their invited partners.
        </p>
        <p>
          Account checks are anti-bot liveness reviews. They are not identity verification and cannot be
          skipped by payment or NFT holding.
        </p>
      </div>
      <Link to="/" className="mt-8 inline-block text-sm text-mint">
        Back
      </Link>
    </main>
  );
}
