import { createFileRoute } from "@tanstack/react-router";
import { requestOrigin } from "@/lib/mtp/telegram.server";

function manifest(origin: string) {
  const body = JSON.stringify({
    url: origin,
    name: "Ghairo",
    iconUrl: `${origin}/mtp/token.jpg`,
    termsOfUseUrl: `${origin}/terms`,
    privacyPolicyUrl: `${origin}/privacy`,
  });
  return new Response(body, {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET, OPTIONS",
      "cache-control": "public, max-age=300",
    },
  });
}

export const Route = createFileRoute("/tonconnect-manifest.json")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "access-control-allow-origin": "*",
            "access-control-allow-methods": "GET, OPTIONS",
          },
        }),
      GET: async ({ request }) => {
        const origin = (process.env.WEBAPP_URL || requestOrigin(request)).replace(/\/$/, "");
        return manifest(origin);
      },
    },
  },
});
