import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () =>
        Response.json({
          ok: true,
          service: "ghairo",
          mongo: Boolean(process.env.MONGODB_URI),
          bot: Boolean(process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN),
          verifyBot: Boolean(process.env.VERIFY_BOT_TOKEN),
        }),
    },
  },
});
