import { createFileRoute } from "@tanstack/react-router";
import { KYC_MAX_SECONDS, MAX_KYC_VIDEO_BYTES, submitKycVideo } from "@/lib/mtp/kyc.server";
import { parseInitData, requestOrigin } from "@/lib/mtp/telegram.server";

export const Route = createFileRoute("/api/kyc-submit")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let form: FormData;
        try {
          form = await request.formData();
        } catch {
          return Response.json({ ok: false, error: "Bad upload." }, { status: 400 });
        }

        const initData = String(form.get("initData") || "");
        // The Mini App was opened from the Verification Bot, so its initData is signed
        // with VERIFY_BOT_TOKEN; fall back to the main bot's token just in case.
        const user =
          parseInitData(initData, process.env.VERIFY_BOT_TOKEN) ||
          parseInitData(initData, process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN);
        if (!user) {
          return Response.json(
            { ok: false, error: "Could not verify your Telegram session. Reopen this from the bot." },
            { status: 401 },
          );
        }

        const file = form.get("video");
        if (!(file instanceof Blob) || file.size === 0) {
          return Response.json({ ok: false, error: "No video was received." }, { status: 400 });
        }
        if (file.size > MAX_KYC_VIDEO_BYTES) {
          return Response.json({ ok: false, error: "The video is too large. Please try again." }, { status: 413 });
        }
        const durationMsRaw = Number(form.get("durationMs") || 0);
        const durationMs = Number.isFinite(durationMsRaw)
          ? Math.min(durationMsRaw, (KYC_MAX_SECONDS + 2) * 1000)
          : 0;

        try {
          const buffer = Buffer.from(await file.arrayBuffer());
          const name = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Miner";
          await submitKycVideo({
            telegramId: user.id,
            name,
            username: user.username,
            video: buffer,
            mimeType: file.type || "video/webm",
            durationMs,
            webAppUrl: process.env.WEBAPP_URL || requestOrigin(request),
          });
          return Response.json({ ok: true });
        } catch (err) {
          console.error("[mtp] kyc submit failed", err);
          const message = err instanceof Error ? err.message : "Could not submit your video.";
          return Response.json({ ok: false, error: message }, { status: 400 });
        }
      },
    },
  },
});
