import { createFileRoute } from "@tanstack/react-router";
import { handleBotUpdate } from "@/lib/mtp/admin.server";
import { requestOrigin, webhookAllowed } from "@/lib/mtp/telegram.server";

export const Route = createFileRoute("/api/bot")({
  server: {
    handlers: {
      GET: async () =>
        Response.json({
          ok: true,
          bot: Boolean(process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN),
          mongo: Boolean(process.env.MONGODB_URI),
          name: "Ghairo",
        }),
      POST: async ({ request }) => {
        if (!webhookAllowed(request, "WEBHOOK_SECRET")) {
          return Response.json({ ok: false, error: "forbidden" }, { status: 403 });
        }
        const token = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
        if (!token) {
          return Response.json({ ok: false, error: "BOT_TOKEN missing" }, { status: 503 });
        }
        let update: unknown;
        try {
          update = await request.json();
        } catch {
          return Response.json({ ok: false }, { status: 400 });
        }
        try {
          const u = update as {
            update_id?: number;
            message?: { text?: string };
            callback_query?: unknown;
            channel_post?: unknown;
          };
          const kind = u.message ? "message" : u.callback_query ? "callback_query" : u.channel_post ? "channel_post" : "other";
          const text = u.message?.text?.startsWith("/") ? u.message.text.split(/\s+/)[0] : "";
          console.log(`[ghairo] bot update ${u.update_id ?? "?"} ${kind} ${text}`.trim());
          await handleBotUpdate(update as Parameters<typeof handleBotUpdate>[0], requestOrigin(request));
        } catch (err) {
          console.error("[ghairo] bot update failed", err);
        }
        return Response.json({ ok: true });
      },
    },
  },
});
