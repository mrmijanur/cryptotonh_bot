import { createFileRoute } from "@tanstack/react-router";
import { handleVerifyBotUpdate } from "@/lib/mtp/admin.server";
import { requestOrigin, webhookAllowed } from "@/lib/mtp/telegram.server";

export const Route = createFileRoute("/api/verify-bot")({
  server: {
    handlers: {
      GET: async () =>
        Response.json({
          ok: true,
          bot: Boolean(process.env.VERIFY_BOT_TOKEN),
          name: "Ghairo Verify",
        }),
      POST: async ({ request }) => {
        if (!webhookAllowed(request, "VERIFY_WEBHOOK_SECRET")) {
          return Response.json({ ok: false, error: "forbidden" }, { status: 403 });
        }
        if (!process.env.VERIFY_BOT_TOKEN) {
          return Response.json({ ok: false, error: "VERIFY_BOT_TOKEN missing" }, { status: 503 });
        }
        let update: unknown;
        try {
          update = await request.json();
        } catch {
          return Response.json({ ok: false }, { status: 400 });
        }
        try {
          await handleVerifyBotUpdate(
            update as Parameters<typeof handleVerifyBotUpdate>[0],
            requestOrigin(request),
          );
        } catch (err) {
          console.error("[ghairo] verify bot update failed", err);
        }
        return Response.json({ ok: true });
      },
    },
  },
});
