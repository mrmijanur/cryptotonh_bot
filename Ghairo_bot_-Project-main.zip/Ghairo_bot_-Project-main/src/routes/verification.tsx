import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { KycCapture } from "@/components/mtp/kyc-capture";
import { TelegramOnly } from "@/components/mtp/telegram-only";
import { waitForTelegram } from "@/components/mtp/telegram";
import { bootstrapVerify } from "@/lib/mtp/functions";
import type { BootResult } from "@/lib/mtp/types";

export const Route = createFileRoute("/verification")({
  component: VerificationPage,
});

function VerificationPage() {
  const [boot, setBoot] = useState<BootResult | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      setLoadError(null);
      await waitForTelegram();
      const tg = window.Telegram?.WebApp;
      tg?.ready();
      tg?.expand();
      tg?.setHeaderColor("#07090f");
      tg?.setBackgroundColor("#07090f");
      try {
        const next = await bootstrapVerify({
          data: {
            initData: tg?.initData || undefined,
            name: tg?.initDataUnsafe?.user?.first_name,
          },
        });
        if (!cancelled) setBoot(next);
      } catch (err) {
        // Real server/network errors must not look like "open from Telegram".
        console.error("[mtp] bootstrapVerify failed", err);
        if (!cancelled) {
          const message = err instanceof Error ? err.message : "Could not open verification.";
          toast.error(message);
          setLoadError(message);
        }
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  if (loadError && !boot) {
    return (
      <main className="flex min-h-svh flex-col items-center justify-center gap-4 bg-bg px-6 text-center">
        <p className="text-sm text-muted">Could not open the check: {loadError}</p>
        <button
          type="button"
          className="rounded-xl bg-surface px-4 py-2 text-sm font-medium shadow-border"
          onClick={() => {
            setBoot(null);
            setAttempt((n) => n + 1);
          }}
        >
          Try again
        </button>
      </main>
    );
  }

  if (!boot) {
    return (
      <main className="flex min-h-svh items-center justify-center bg-bg text-sm text-muted">
        Opening check…
      </main>
    );
  }
  if (boot.access === "telegram_required") return <TelegramOnly />;

  const miner = boot.view.miner;
  return (
    <main className="mx-auto flex min-h-svh max-w-[430px] flex-col bg-bg px-4 pb-8 pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="flex items-center gap-3">
        <img src="/mtp/token.jpg" alt="" width={36} height={36} className="size-9 object-contain" />
        <div>
          <p className="font-display text-sm font-semibold">Account check</p>
          <p className="text-[11px] text-muted">{miner.name}</p>
        </div>
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted">
        A short face-scan video, reviewed by an admin. It only confirms you are a real person, not your
        identity, and this closes on its own once it is submitted.
      </p>
      <div className="mt-4">
        <KycCapture status={miner.livenessStatus} onSubmitted={() => toast.success("Submitted for review")} />
      </div>
    </main>
  );
        }
