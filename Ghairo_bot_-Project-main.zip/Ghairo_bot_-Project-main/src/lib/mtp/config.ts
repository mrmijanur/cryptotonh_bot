export const APP_NAME = "Ghairo";
export const TOKEN_SYMBOL = "Ghairo";
export const TOKEN_NAME = "Ghairo";
export const TOTAL_SUPPLY = 10_000_000_000;
export const TOKEN_USD = 0.003;
export const MIN_WITHDRAW = 5; // coins
export const DEFAULT_WITHDRAW_NOTICE = "Withdrawals are temporarily unavailable. Please try again later.";
export const MIN_CLAIM = 0.01; // smallest amount a user can collect
export const WITHDRAW_FEE = 0;
// Deposits (TON / USDT -> pool). Rates can be changed by the owner from the bot.
export const ADMIN_CONTACT_URL = "https://t.me/assistant_bd";
export const DEPOSIT_TON_RATE = 1.5; // coins credited per 1 Gram (owner sets with /setdepositrate)
export const COIN_USD = 0.2; // what 1 coin is worth in USD when withdrawing (owner sets with /setcoinvalue)
export const GRAM_USD_FALLBACK = 1.5; // used only if the live Gram price cannot be fetched
export const MIN_DEPOSIT_TON = 0.5;
export const MIN_DEPOSIT_USDT = 1;
export const DEPOSIT_USDT_RATE = 1; // coins credited per 1 USDT (owner sets with /setdepositrate usdt)
export const DEPOSIT_TTL_MS = 30 * 60 * 1000; // how long a deposit waits for its payment
export const USDT_JETTON_MASTER = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs";
export const REFERRAL_DEPOSIT_PERCENT = 0.25; // share of an invited partner's deposit credited to the inviter (no per-invite coin bonus)
export const SIGNUP_BONUS = 1; // free Ghairo every new user gets when they first open the bot
export const DAILY_BONUS = 8;
export const REACT_CLAIM_MS = 15_000;
export const DEFAULT_TASK_COOLDOWN_MS = 24 * 60 * 60 * 1000; // used when a task has no cooldownMs set
export const TASKS_REFRESH_MS = 3 * 60 * 60 * 1000;

export const DEFAULT_WELCOME = [
  "✨ Welcome to Ghairo! ✨",
  "",
  "🎁 Free start: 1 Ghairo coin is already in your balance.",
  "💎 Use it to unlock your first gem. It starts earning right away.",
  "⛏ Collect your coins any time, completely free.",
  "💳 Top up with Gram or USDT (TON network only) whenever you like. It is always your choice.",
  "💸 Withdraw in Gram or USDT (TON network) straight to your own address.",
  "👥 Invite friends and earn 25% of every top-up they make.",
  "",
  "Tap the button below to start 👇",
].join("\n");

export const DEFAULT_WELCOME_BUTTON = "🚀 Open Ghairo";

/**
 * Gem packages (stored internally as "birds"). Each gem is bought once, in order, and then earns price x percent every day.
 * The first gem (price 1) is meant for the free signup coin.
 * Keep the other percents low: payouts must be covered by your own revenue (ads, subscriptions).
 */
export type BirdPackage = { price: number; percent: number };

export const BIRD_PACKAGES: BirdPackage[] = [
  { price: 1, percent: 10 },
  { price: 3, percent: 0.5 },
  { price: 5, percent: 0.55 },
  { price: 10, percent: 0.6 },
  { price: 25, percent: 0.65 },
  { price: 50, percent: 0.7 },
  { price: 75, percent: 0.75 },
  { price: 100, percent: 0.8 },
  { price: 250, percent: 0.85 },
  { price: 500, percent: 0.9 },
  { price: 750, percent: 0.95 },
  { price: 1000, percent: 1 },
];

/** Income per day of one package, in coins. */
export function packageDaily(index: number, packs: BirdPackage[] = BIRD_PACKAGES): number {
  const p = packs[index];
  return p ? (p.price * p.percent) / 100 : 0;
}

/** Total coins per day for a miner that owns these packages. No birds, no income. */
export function dailyRate(birds: number[] | undefined, packs: BirdPackage[] = BIRD_PACKAGES): number {
  let total = 0;
  for (const i of birds ?? []) total += packageDaily(i, packs);
  return total;
}

export function ratePerSecond(birds?: number[], packs: BirdPackage[] = BIRD_PACKAGES): number {
  return dailyRate(birds, packs) / 86_400;
}

export function makeRefCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 8; i += 1) {
    out += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `GHR_${out}`;
}
