import { MongoClient, type Collection, type Db } from "mongodb";
import { DEFAULT_WELCOME, DEFAULT_WELCOME_BUTTON } from "./config";
import type {
  AdminRecord,
  AppSettings,
  Deposit,
  DepositStatus,
  HistoryEntry,
  HistoryKind,
  LivenessRecord,
  Miner,
  TaskDef,
  Withdrawal,
} from "./types";

type Memory = {
  miners: Map<string, Miner>;
  withdrawals: Map<string, Withdrawal>;
  tasks: Map<string, TaskDef>;
  admins: Map<number, AdminRecord>;
  deposits: Map<string, Deposit>;
  verifications: Map<string, LivenessRecord>;
  history: Map<string, HistoryEntry>;
  settings: AppSettings;
};

const g = globalThis as typeof globalThis & {
  __ghairoMemory?: Memory;
  __ghairoMongo?: { client: MongoClient; db: Db };
};

// Mongo adds `_id: ObjectId` to every document. ObjectId cannot be serialized by
// TanStack Start server functions (Seroval error), so never read it back.
const NO_ID = { projection: { _id: 0 } } as const;

function memory(): Memory {
  if (!g.__ghairoMemory) {
    g.__ghairoMemory = {
      miners: new Map(),
      withdrawals: new Map(),
      tasks: new Map(),
      admins: new Map(),
      deposits: new Map(),
      verifications: new Map(),
      history: new Map(),
      settings: {
        _id: "settings",
        welcomeText: DEFAULT_WELCOME,
        welcomeButton: DEFAULT_WELCOME_BUTTON,
      },
    };
  }
  return g.__ghairoMemory;
}

/** Indexes keep every lookup fast as users grow. Safe to run on every start. */
async function ensureIndexes(db: import("mongodb").Db): Promise<void> {
  const make = async (name: string, spec: Record<string, 1 | -1>, unique = false) => {
    try {
      await db.collection(name).createIndex(spec, { unique, background: true });
    } catch (err) {
      console.error(`[ghairo] index ${name} ${JSON.stringify(spec)} failed:`, err instanceof Error ? err.message : err);
    }
  };
  await Promise.all([
    make("miners", { id: 1 }, true),
    make("miners", { telegramId: 1 }),
    make("miners", { refCode: 1 }),
    make("miners", { referredBy: 1 }),
    make("withdrawals", { minerId: 1, createdAt: -1 }),
    make("withdrawals", { status: 1 }),
    make("deposits", { minerId: 1, createdAt: -1 }),
    make("deposits", { status: 1 }),
    make("history", { minerId: 1, createdAt: -1 }),
    make("verifications", { minerId: 1 }),
    make("admins", { telegramId: 1 }),
  ]);
}

async function mongo(): Promise<{
  miners: Collection<Miner>;
  withdrawals: Collection<Withdrawal>;
  tasks: Collection<TaskDef>;
  admins: Collection<AdminRecord>;
  deposits: Collection<Deposit>;
  verifications: Collection<LivenessRecord>;
  history: Collection<HistoryEntry>;
  settings: Collection<AppSettings>;
} | null> {
  const uri = process.env.MONGODB_URI;
  if (!uri) return null;
  if (!g.__ghairoMongo) {
    const client = new MongoClient(uri, { maxPoolSize: 10 });
    await client.connect();
    const db = client.db(process.env.MONGODB_DB || "felvora");
    g.__ghairoMongo = { client, db };
    void ensureIndexes(db);
  }
  const { db } = g.__ghairoMongo;
  return {
    miners: db.collection<Miner>("miners"),
    withdrawals: db.collection<Withdrawal>("withdrawals"),
    tasks: db.collection<TaskDef>("tasks"),
    admins: db.collection<AdminRecord>("admins"),
    deposits: db.collection<Deposit>("deposits"),
    verifications: db.collection<LivenessRecord>("verifications"),
    history: db.collection<HistoryEntry>("history"),
    settings: db.collection<AppSettings>("settings"),
  };
}

export async function getMiner(id: string): Promise<Miner | null> {
  const db = await mongo();
  if (db) return (await db.miners.findOne({ id }, NO_ID)) ?? null;
  return memory().miners.get(id) ?? null;
}

export async function getMinerByTelegram(telegramId: number): Promise<Miner | null> {
  const db = await mongo();
  if (db) return (await db.miners.findOne({ telegramId }, NO_ID)) ?? null;
  for (const miner of memory().miners.values()) {
    if (miner.telegramId === telegramId) return miner;
  }
  return null;
}

export async function getMinerByRef(refCode: string): Promise<Miner | null> {
  const code = refCode.trim().toUpperCase();
  const db = await mongo();
  if (db) return (await db.miners.findOne({ refCode: code }, NO_ID)) ?? null;
  for (const miner of memory().miners.values()) {
    if (miner.refCode === code) return miner;
  }
  return null;
}

export async function saveMiner(miner: Miner): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.miners.updateOne({ id: miner.id }, { $set: miner }, { upsert: true });
    return;
  }
  memory().miners.set(miner.id, miner);
}

export async function listSquad(refCode: string): Promise<Miner[]> {
  const db = await mongo();
  if (db) {
    return db.miners.find({ referredBy: refCode }, NO_ID).limit(50).toArray();
  }
  return [...memory().miners.values()].filter((m) => m.referredBy === refCode);
}

export async function userCounts(): Promise<{ total: number; today: number; week: number }> {
  const now = Date.now();
  const day = 86_400_000;
  const db = await mongo();
  if (db) {
    const [total, today, week] = await Promise.all([
      db.miners.countDocuments({ telegramId: { $exists: true } }),
      db.miners.countDocuments({ telegramId: { $exists: true }, createdAt: { $gte: now - day } }),
      db.miners.countDocuments({ telegramId: { $exists: true }, createdAt: { $gte: now - 7 * day } }),
    ]);
    return { total, today, week };
  }
  const rows = [...memory().miners.values()].filter((m) => m.telegramId);
  return {
    total: rows.length,
    today: rows.filter((m) => now - m.createdAt < day).length,
    week: rows.filter((m) => now - m.createdAt < 7 * day).length,
  };
}

export async function listTelegramMiners(): Promise<Miner[]> {
  const db = await mongo();
  if (db) {
    return db.miners.find({ telegramId: { $gt: 0 } }, NO_ID).toArray();
  }
  return [...memory().miners.values()].filter((m) => m.telegramId);
}

export async function addWithdrawal(row: Withdrawal): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.withdrawals.insertOne({ ...row });
    return;
  }
  memory().withdrawals.set(row.id, row);
}

export async function getWithdrawal(id: string): Promise<Withdrawal | null> {
  const db = await mongo();
  if (db) return (await db.withdrawals.findOne({ id }, NO_ID)) ?? null;
  return memory().withdrawals.get(id) ?? null;
}

export async function saveWithdrawal(row: Withdrawal): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.withdrawals.updateOne({ id: row.id }, { $set: row }, { upsert: true });
    return;
  }
  memory().withdrawals.set(row.id, row);
}

export async function listWithdrawals(minerId: string): Promise<Withdrawal[]> {
  const db = await mongo();
  if (db) {
    return db.withdrawals.find({ minerId }, NO_ID).sort({ createdAt: -1 }).limit(20).toArray();
  }
  return [...memory().withdrawals.values()]
    .filter((row) => row.minerId === minerId)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 20);
}

export async function listPendingWithdrawals(): Promise<Withdrawal[]> {
  const db = await mongo();
  if (db) {
    return db.withdrawals.find({ status: "pending" }, NO_ID).sort({ createdAt: -1 }).limit(50).toArray();
  }
  return [...memory().withdrawals.values()]
    .filter((row) => row.status === "pending")
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 50);
}

export async function countByStatus(
  status: Withdrawal["status"],
): Promise<number> {
  const db = await mongo();
  if (db) return db.withdrawals.countDocuments({ status });
  return [...memory().withdrawals.values()].filter((row) => row.status === status).length;
}

export async function saveTask(task: TaskDef): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.tasks.updateOne({ id: task.id }, { $set: task }, { upsert: true });
    return;
  }
  memory().tasks.set(task.id, task);
}

export async function getTask(id: string): Promise<TaskDef | null> {
  const key = id.trim();
  const db = await mongo();
  if (db) return (await db.tasks.findOne({ id: key }, NO_ID)) ?? null;
  return memory().tasks.get(key) ?? null;
}

export async function deleteTask(id: string): Promise<boolean> {
  const db = await mongo();
  if (db) {
    const res = await db.tasks.deleteOne({ id });
    return res.deletedCount > 0;
  }
  return memory().tasks.delete(id);
}

export async function listTasks(): Promise<TaskDef[]> {
  const db = await mongo();
  const rows = db
    ? await db.tasks.find({}, NO_ID).sort({ category: 1, createdAt: 1 }).toArray()
    : [...memory().tasks.values()].sort((a, b) => a.createdAt - b.createdAt);
  return rows;
}

export async function updateReactLatestLinks(link: string): Promise<number> {
  const now = Date.now();
  const db = await mongo();
  if (db) {
    const res = await db.tasks.updateMany(
      { verification: "react_latest" },
      { $set: { link, updatedAt: now } },
    );
    return res.modifiedCount;
  }
  let n = 0;
  for (const task of memory().tasks.values()) {
    if (task.verification === "react_latest") {
      task.link = link;
      task.updatedAt = now;
      n += 1;
    }
  }
  return n;
}

export async function getAdmin(telegramId: number): Promise<AdminRecord | null> {
  const db = await mongo();
  if (db) return (await db.admins.findOne({ telegramId }, NO_ID)) ?? null;
  return memory().admins.get(telegramId) ?? null;
}

export async function addAdmin(row: AdminRecord): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.admins.updateOne({ telegramId: row.telegramId }, { $set: row }, { upsert: true });
    return;
  }
  memory().admins.set(row.telegramId, row);
}

export async function removeAdmin(telegramId: number): Promise<boolean> {
  const db = await mongo();
  if (db) {
    const res = await db.admins.deleteOne({ telegramId });
    return res.deletedCount > 0;
  }
  return memory().admins.delete(telegramId);
}

export async function listAdmins(): Promise<AdminRecord[]> {
  const db = await mongo();
  if (db) return db.admins.find({}, NO_ID).toArray();
  return [...memory().admins.values()];
}

export async function addDeposit(row: Deposit): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.deposits.insertOne({ ...row });
    return;
  }
  memory().deposits.set(row.id, row);
}

export async function listDeposits(minerId: string): Promise<Deposit[]> {
  const db = await mongo();
  if (db) {
    return db.deposits.find({ minerId }, NO_ID).sort({ createdAt: -1 }).limit(20).toArray();
  }
  return [...memory().deposits.values()]
    .filter((row) => row.minerId === minerId)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 20);
}

export async function getDeposit(id: string): Promise<Deposit | null> {
  const db = await mongo();
  if (db) return (await db.deposits.findOne({ id }, NO_ID)) ?? null;
  return memory().deposits.get(id) ?? null;
}

export async function patchDeposit(id: string, patch: Partial<Deposit>): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.deposits.updateOne({ id }, { $set: patch });
    return;
  }
  const row = memory().deposits.get(id);
  if (row) Object.assign(row, patch);
}

/**
 * Atomically moves a deposit from one of the `from` statuses to a new state.
 * Returns the updated row, or null if it was not in an allowed status (already handled).
 * This is what stops a payment from being credited twice.
 */
export async function transitionDeposit(
  id: string,
  from: DepositStatus[],
  patch: Partial<Deposit>,
): Promise<Deposit | null> {
  const db = await mongo();
  if (db) {
    const res = await db.deposits.findOneAndUpdate(
      { id, status: { $in: from } },
      { $set: patch },
      { returnDocument: "after", projection: { _id: 0 } },
    );
    return res ?? null;
  }
  const row = memory().deposits.get(id);
  if (!row || !row.status || !from.includes(row.status)) return null;
  Object.assign(row, patch);
  return row;
}

export async function listDepositsByStatus(statuses: DepositStatus[]): Promise<Deposit[]> {
  const db = await mongo();
  if (db) {
    return db.deposits
      .find({ status: { $in: statuses } }, NO_ID)
      .sort({ createdAt: -1 })
      .limit(50)
      .toArray();
  }
  return [...memory().deposits.values()]
    .filter((row) => row.status && statuses.includes(row.status))
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 50);
}

/** Atomic add/subtract on the pool so a deposit can never overwrite other balance changes. */
export async function incMinerPool(minerId: string, delta: number): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.miners.updateOne({ id: minerId }, { $inc: { pool: delta } });
    return;
  }
  const miner = memory().miners.get(minerId);
  if (miner) miner.pool += delta;
}

/** Takes `amount` from the balance only if it is all there. False if the balance is too low. */
export async function spendMinerPool(minerId: string, amount: number): Promise<boolean> {
  const db = await mongo();
  if (db) {
    const res = await db.miners.updateOne({ id: minerId, pool: { $gte: amount } }, { $inc: { pool: -amount } });
    return res.modifiedCount === 1;
  }
  const miner = memory().miners.get(minerId);
  if (!miner || miner.pool < amount) return false;
  miner.pool -= amount;
  return true;
}

/** Spends `price` from the balance and adds bird `index`, in one atomic step. False if it cannot be bought. */
export async function buyMinerBird(minerId: string, index: number, price: number): Promise<boolean> {
  const db = await mongo();
  if (db) {
    const res = await db.miners.updateOne(
      { id: minerId, pool: { $gte: price }, birds: { $ne: index } },
      { $inc: { pool: -price }, $push: { birds: index }, $set: { mining: true, lastAccruedAt: Date.now() } },
    );
    return res.modifiedCount === 1;
  }
  const miner = memory().miners.get(minerId);
  if (!miner || miner.pool < price || (miner.birds ?? []).includes(index)) return false;
  miner.pool -= price;
  miner.birds = [...(miner.birds ?? []), index];
  miner.mining = true;
  miner.lastAccruedAt = Date.now();
  return true;
}

/** Atomic increments for referral income, so two payments at once cannot overwrite each other. */
export async function incMinerReferral(
  minerId: string,
  delta: { commissionUnclaimed?: number; squadEarned?: number; squadCount?: number },
): Promise<void> {
  const inc: Record<string, number> = {};
  for (const [key, value] of Object.entries(delta)) if (value) inc[key] = value;
  if (Object.keys(inc).length === 0) return;
  const db = await mongo();
  if (db) {
    await db.miners.updateOne({ id: minerId }, { $inc: inc });
    return;
  }
  const miner = memory().miners.get(minerId);
  if (!miner) return;
  miner.commissionUnclaimed = (miner.commissionUnclaimed ?? 0) + (inc.commissionUnclaimed ?? 0);
  miner.squadEarned += inc.squadEarned ?? 0;
  miner.squadCount += inc.squadCount ?? 0;
}

export async function addVerification(row: LivenessRecord): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.verifications.insertOne({ ...row });
    return;
  }
  memory().verifications.set(row.id, row);
}

export async function getVerification(id: string): Promise<LivenessRecord | null> {
  const db = await mongo();
  if (db) return (await db.verifications.findOne({ id }, NO_ID)) ?? null;
  return memory().verifications.get(id) ?? null;
}

export async function saveVerification(row: LivenessRecord): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.verifications.updateOne({ id: row.id }, { $set: row }, { upsert: true });
    return;
  }
  memory().verifications.set(row.id, row);
}

export async function listPendingVerifications(): Promise<LivenessRecord[]> {
  const db = await mongo();
  if (db) {
    return db.verifications.find({ status: "pending" }, NO_ID).sort({ createdAt: -1 }).limit(50).toArray();
  }
  return [...memory().verifications.values()]
    .filter((row) => row.status === "pending")
    .sort((a, b) => b.createdAt - a.createdAt);
}

export async function countPendingVerifications(): Promise<number> {
  const db = await mongo();
  if (db) return db.verifications.countDocuments({ status: "pending" });
  return [...memory().verifications.values()].filter((row) => row.status === "pending").length;
}

let settingsCache: { value: AppSettings; at: number } | null = null;

export async function getSettings(): Promise<AppSettings> {
  // Settings are read many times per request; keep them in memory for 5 seconds.
  if (settingsCache && Date.now() - settingsCache.at < 5000) return settingsCache.value;
  const value = await readSettings();
  settingsCache = { value, at: Date.now() };
  return value;
}

async function readSettings(): Promise<AppSettings> {
  const fallback: AppSettings = {
    _id: "settings",
    welcomeText: DEFAULT_WELCOME,
    welcomeButton: DEFAULT_WELCOME_BUTTON,
  };
  const db = await mongo();
  if (db) {
    return (await db.settings.findOne({ _id: "settings" })) ?? fallback;
  }
  return memory().settings;
}

export async function saveSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
  const current = await getSettings();
  const next: AppSettings = { ...current, ...patch, _id: "settings" };
  const db = await mongo();
  if (db) {
    await db.settings.updateOne({ _id: "settings" }, { $set: next }, { upsert: true });
    settingsCache = { value: next, at: Date.now() };
    return next;
  }
  memory().settings = next;
  settingsCache = { value: next, at: Date.now() };
  return next;
}

export async function countTasks(): Promise<number> {
  const db = await mongo();
  if (db) return db.tasks.countDocuments();
  return memory().tasks.size;
}

export async function countMining(): Promise<number> {
  const db = await mongo();
  if (db) return db.miners.countDocuments({ mining: true });
  return [...memory().miners.values()].filter((m) => m.mining).length;
  }

export async function addHistory(entry: HistoryEntry): Promise<void> {
  const db = await mongo();
  if (db) {
    await db.history.insertOne({ ...entry });
    return;
  }
  memory().history.set(entry.id, entry);
}

export async function listHistory(
  minerId: string,
  kinds: HistoryKind[],
  limit = 30,
): Promise<HistoryEntry[]> {
  const db = await mongo();
  if (db) {
    return db.history
      .find({ minerId, kind: { $in: kinds } }, NO_ID)
      .sort({ createdAt: -1 })
      .limit(limit)
      .toArray();
  }
  return [...memory().history.values()]
    .filter((row) => row.minerId === minerId && kinds.includes(row.kind))
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, limit);
}

/** Number of NFTs this miner currently holds (sent to the admin wallet, no refund requested). */
export async function countActiveNftHolds(minerId: string): Promise<number> {
  const db = await mongo();
  if (db) {
    return db.deposits.countDocuments({ minerId, token: "nft", status: "completed" });
  }
  return [...memory().deposits.values()].filter(
    (row) =>
      row.minerId === minerId &&
      row.token === "nft" &&
      row.status === "completed",
  ).length;
}

export async function countWithdrawals(
  minerId: string,
  statuses: Withdrawal["status"][],
): Promise<number> {
  const db = await mongo();
  if (db) return db.withdrawals.countDocuments({ minerId, status: { $in: statuses } });
  return [...memory().withdrawals.values()].filter(
    (row) => row.minerId === minerId && statuses.includes(row.status),
  ).length;
}
