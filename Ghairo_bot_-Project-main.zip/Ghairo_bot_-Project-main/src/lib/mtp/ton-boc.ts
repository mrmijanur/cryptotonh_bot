// Minimal TON helpers: address parsing, a tiny cell builder and BOC serialization.
// Only what Ghairo needs to build TonConnect payloads (comment + jetton transfer),
// so we do not have to add @ton/core to the bundle. Pure functions, no I/O.

export function crc16(data: Uint8Array): number {
  let crc = 0;
  for (const byte of data) {
    crc ^= byte << 8;
    for (let i = 0; i < 8; i += 1) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc;
}

function hexToBytes(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i += 1) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

function toHex(bytes: Uint8Array): string {
  let out = "";
  for (const b of bytes) out += b.toString(16).padStart(2, "0");
  return out;
}

export type TonAddr = { wc: number; hash: Uint8Array };

/** Accepts raw "0:<64 hex>" and friendly (EQ.../UQ...) addresses. Returns null if invalid. */
export function parseTonAddress(input: string): TonAddr | null {
  const s = input.trim();
  const raw = /^(-?\d+):([0-9a-fA-F]{64})$/.exec(s);
  if (raw) {
    const wc = Number(raw[1]);
    if (wc !== 0 && wc !== -1) return null;
    return { wc, hash: hexToBytes(raw[2]!) };
  }
  if (!/^[A-Za-z0-9_+/-]{48}$/.test(s)) return null;
  const bytes = Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");
  if (bytes.length !== 36) return null;
  if (crc16(bytes.subarray(0, 34)) !== ((bytes[34]! << 8) | bytes[35]!)) return null;
  const wc = bytes[1] === 0xff ? -1 : bytes[1]!;
  if (wc !== 0 && wc !== -1) return null;
  return { wc, hash: new Uint8Array(bytes.subarray(2, 34)) };
}

/** Canonical form ("0:<hex>") so addresses from different sources can be compared. */
export function normalizeTonAddress(input: string | null | undefined): string | null {
  if (!input) return null;
  const a = parseTonAddress(input);
  return a ? `${a.wc}:${toHex(a.hash)}` : null;
}

export function friendlyTonAddress(a: TonAddr, bounceable = false): string {
  const bytes = new Uint8Array(36);
  bytes[0] = bounceable ? 0x11 : 0x51;
  bytes[1] = a.wc & 0xff;
  bytes.set(a.hash, 2);
  const crc = crc16(bytes.subarray(0, 34));
  bytes[34] = crc >> 8;
  bytes[35] = crc & 0xff;
  return Buffer.from(bytes).toString("base64url");
}

export class CellBuilder {
  readonly bits: number[] = [];
  readonly refs: CellBuilder[] = [];

  get bitLength(): number {
    return this.bits.length;
  }

  uint(value: bigint | number, size: number): this {
    const v = BigInt(value);
    if (v < 0n || v >= 1n << BigInt(size)) throw new Error("uint out of range");
    for (let i = size - 1; i >= 0; i -= 1) this.bits.push(Number((v >> BigInt(i)) & 1n));
    return this;
  }

  bit(value: 0 | 1): this {
    this.bits.push(value);
    return this;
  }

  bytes(data: Uint8Array): this {
    for (const b of data) this.uint(b, 8);
    return this;
  }

  text(value: string): this {
    return this.bytes(new TextEncoder().encode(value));
  }

  /** VarUInteger 16 */
  coins(value: bigint): this {
    if (value < 0n) throw new Error("coins must be >= 0");
    if (value === 0n) return this.uint(0, 4);
    let len = 0;
    for (let t = value; t > 0n; t >>= 8n) len += 1;
    if (len > 15) throw new Error("coins too large");
    return this.uint(len, 4).uint(value, len * 8);
  }

  /** MsgAddress (addr_std, no anycast) */
  address(a: TonAddr): this {
    return this.uint(2, 2).uint(0, 1).uint(a.wc & 0xff, 8).bytes(a.hash);
  }

  ref(cell: CellBuilder): this {
    if (this.refs.length >= 4) throw new Error("too many refs");
    this.refs.push(cell);
    return this;
  }
}

/** Serialize a cell tree (no shared cells) to a base64 BOC. */
export function toBocBase64(root: CellBuilder): string {
  const order: CellBuilder[] = [root];
  for (let i = 0; i < order.length; i += 1) order.push(...order[i]!.refs);
  if (order.length > 255) throw new Error("too many cells");
  const index = new Map<CellBuilder, number>();
  order.forEach((cell, i) => index.set(cell, i));

  const serialized = order.map((cell) => {
    const bl = cell.bitLength;
    if (bl > 1023) throw new Error("cell too large");
    const dataLen = Math.ceil(bl / 8);
    const data = new Uint8Array(dataLen);
    for (let i = 0; i < bl; i += 1) if (cell.bits[i]) data[i >> 3]! |= 0x80 >> (i & 7);
    if (bl % 8 !== 0) data[dataLen - 1]! |= 0x80 >> (bl % 8); // completion tag
    return [cell.refs.length, Math.ceil(bl / 8) + Math.floor(bl / 8), ...data, ...cell.refs.map((r) => index.get(r)!)];
  });

  const total = serialized.reduce((n, c) => n + c.length, 0);
  const offBytes = total < 256 ? 1 : 2;
  const out: number[] = [0xb5, 0xee, 0x9c, 0x72, 0x01, offBytes, order.length, 1, 0];
  if (offBytes === 1) out.push(total);
  else out.push(total >> 8, total & 0xff);
  out.push(0); // root cell index
  for (const c of serialized) out.push(...c);
  return Buffer.from(out).toString("base64");
}

/** Cell holding a plain text comment (op = 0). */
export function commentCell(text: string): CellBuilder {
  return new CellBuilder().uint(0, 32).text(text);
}

export function commentPayloadBase64(text: string): string {
  return toBocBase64(commentCell(text));
}

/** TEP-74 jetton `transfer` body with a text comment as forward payload. */
export function jettonTransferPayloadBase64(opts: {
  jettonAmount: bigint;
  destination: TonAddr;
  responseTo: TonAddr;
  forwardTon: bigint;
  comment: string;
  queryId?: bigint;
}): string {
  const body = new CellBuilder()
    .uint(0x0f8a7ea5, 32)
    .uint(opts.queryId ?? 0n, 64)
    .coins(opts.jettonAmount)
    .address(opts.destination)
    .address(opts.responseTo)
    .bit(0) // no custom payload
    .coins(opts.forwardTon)
    .bit(1) // forward payload stored in a ref
    .ref(commentCell(opts.comment));
  return toBocBase64(body);
}

/** TEP-62 NFT `transfer` body with a text comment as forward payload. */
export function nftTransferPayloadBase64(opts: {
  newOwner: TonAddr;
  responseTo: TonAddr;
  forwardTon: bigint;
  comment: string;
  queryId?: bigint;
}): string {
  const body = new CellBuilder()
    .uint(0x5fcc3d14, 32)
    .uint(opts.queryId ?? 0n, 64)
    .address(opts.newOwner)
    .address(opts.responseTo)
    .bit(0) // no custom payload
    .coins(opts.forwardTon)
    .bit(1) // forward payload stored in a ref
    .ref(commentCell(opts.comment));
  return toBocBase64(body);
      }
