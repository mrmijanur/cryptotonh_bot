import { BIRD_PACKAGES, COIN_USD, DEFAULT_WITHDRAW_NOTICE, DEFAULT_TASK_COOLDOWN_MS, packageDaily, REACT_CLAIM_MS, TOKEN_SYMBOL } from "./config";
import {
  fmtAmount,
  getWithdrawRules,
  loadOrCreateMiner,
  refreshLatestPost,
  resolveLiveness,
  resolveWithdrawal,
  sendWelcome,
  getPackages,
  joinListRaw,
} from "./engine.server";
import { confirmDepositManually, getDepositInfo, getGramUsd, listRefundRequests, resolveRefund } from "./deposit.server";
import { handleKycCallback } from "./kyc.server";
import { shortId, toFriendlyAddress } from "./ids";
import { withdrawUnlockedUser } from "./messages.server";
import { friendlyTonAddress, normalizeTonAddress, parseTonAddress } from "./ton-boc";
import {
  addAdmin,
  addHistory,
  countByStatus,
  countMining,
  countPendingVerifications,
  countTasks,
  deleteTask,
  getAdmin,
  getMinerByTelegram,
  getSettings,
  incMinerPool,
  getTask,
  listAdmins,
  listPendingVerifications,
  listPendingWithdrawals,
  listTasks,
  listTelegramMiners,
  removeAdmin,
  saveSettings,
  saveTask,
  userCounts,
} from "./store.server";
import {
  clearButtons,
  matchesChannel,
  ownerChatId,
  postUrlFromChannel,
  sendTelegram,
  telegramCall,
  checkBotIsAdmin,
  parseChannelLink,
} from "./telegram.server";
import type { TaskCategory, TaskDef, TaskVerification } from "./types";

type Dest = "users" | "channel" | "both";

type Flow =
  | {
      kind: "announce";
      step: "text" | "button" | "btntext" | "btnurl" | "dest" | "confirm";
      text?: string;
      image?: string;
      btnText?: string;
      btnUrl?: string;
      dest?: Dest;
    }
  | {
      kind: "announce_image";
      step: "photo" | "caption" | "button" | "btntext" | "btnurl" | "dest" | "confirm";
      text?: string;
      image?: string;
      btnText?: string;
      btnUrl?: string;
      dest?: Dest;
    }
  | {
      kind: "addtask";
      step: "category" | "title" | "reward" | "link" | "verify" | "channel" | "confirm";
      category?: TaskCategory;
      title?: string;
      detail?: string;
      reward?: number;
      link?: string;
      verification?: TaskVerification;
      channelId?: string;
    }
  | {
      kind: "edittask";
      step: "field" | "value" | "confirm";
      taskId: string;
      field?: "title" | "reward" | "link" | "category" | "verification" | "detail";
      value?: string;
    }
  | {
      kind: "welcome";
      step: "text" | "image" | "button" | "confirm";
      text?: string;
      image?: string;
      button?: string;
    }
  | { kind: "withdraw_hash"; id: string; chatId: number; messageId: number }
  | { kind: "refund_hash"; id: string; chatId: number; messageId: number };

type TgUser = { id: number; first_name?: string; username?: string };
type TgChat = { id: number; username?: string };
type TgMessage = {
  message_id: number;
  text?: string;
  caption?: string;
  from?: TgUser;
  chat: TgChat;
  photo?: Array<{ file_id: string }>;
};
type TgCallback = {
  id: string;
  from: TgUser;
  data?: string;
  message?: { chat: TgChat; message_id: number };
};
type TgUpdate = {
  message?: TgMessage;
  callback_query?: TgCallback;
  channel_post?: { message_id: number; chat: TgChat; text?: string };
};

const g = globalThis as typeof globalThis & { __ghairoFlows?: Map<number, Flow> };

function flows(): Map<number, Flow> {
  if (!g.__ghairoFlows) g.__ghairoFlows = new Map();
  return g.__ghairoFlows;
}

function isOwner(id: number): boolean {
  const owner = ownerChatId();
  return owner !== null && id === owner;
}

async function isAdmin(id: number): Promise<boolean> {
  if (isOwner(id)) return true;
  return Boolean(await getAdmin(id));
}

async function reply(chatId: number, text: string, extra: Record<string, unknown> = {}) {
  await telegramCall("sendMessage", { chat_id: chatId, text, ...extra });
}

async function answer(id: string, text?: string) {
  await telegramCall("answerCallbackQuery", { callback_query_id: id, text, show_alert: Boolean(text && text.length > 40) });
}

const USER_HELP = [
  "Ghairo",
  "",
  "/start — open Ghairo and save your account",
  "",
  "Collect free Ghairo coins, invite friends, top up with Gram or USDT and withdraw in Gram or USDT.",
].join("\n");

const ADMIN_HELP = [
  "Admin commands",
  "",
  "/stats — users, mining, withdrawals",
  "/totalusers — total / today / 7 days",
  "/withdrawals — pending withdrawals",
  "/approvewithdraw <id> [txhash]",
  "/rejectwithdraw <id> — refunds balance",
  "/withdrawsettings — min / max",
  "/withdrawmsg — show the withdraw notice (or set it: /withdrawmsg <text>)",
  "/withdrawmsgon — show the notice, withdrawals paused",
  "/withdrawmsgoff — hide the notice, withdrawals open",
  "/withdrawallow <telegramId> — this account can withdraw even while the notice is ON",
  "/withdrawallowremove <telegramId> — block that account again",
  "/withdrawallowlist — accounts that are allowed",
  "/depositsettings — address / rates",
  "/packages — all 12 packages with their ids",
  "/setpackage <id> <price> <percent per day>",
  "/setpackageprice <id> <price>",
  "/setpackagepercent <id> <percent per day>",
  "/announcement — text broadcast / channel post",
  "/announcementimage — image broadcast / channel post",
  "/setwelcome — edit /start message",
  "/maintainpopupon [message] — show the maintenance page to everyone",
  "/maintainpopupoff — back to the normal app",
  "/channeljoinpopupshow <channel link> — add a channel users must join (use it again to add more)",
  "/channeljoinlist — list the required channels",
  "/channeljoinremove <number> — remove one channel",
  "/noneedchanneljoin — turn the join popup OFF",
  "/cancel — abort the current flow",
  "",
  "Owner only",
  "/addadmin <telegramId>",
  "/removeadmin <telegramId>",
  "/sendcoinuser <telegramId> <amount> — send coins to a user",
  "/admindepositmsgon — admins also get deposit messages",
  "/admindepositmsgoff — only you (owner) get deposit messages",
  "/setminwithdraw <amount>",
  "/setmaxwithdraw <amount> (0 = no limit)",
  "/setcoinvalue <usd> — USD value of 1 coin when withdrawing",
  "/setdepositaddress <address>",
  "/setdepositrate <gram|usdt> <coin per 1>",
  "/setmindeposit <gram|usdt> <amount>",
  "/setmaxdeposit <gram|usdt> <amount> (0 = no limit)",
  "/confirmdeposit <id> — credit manually",
].join("\n");

// Only these commands are active. Anything else typed by an admin is ignored.
const ACTIVE_COMMANDS = new Set([
  "/stats",
  "/totalusers",
  "/withdrawals",
  "/approvewithdraw",
  "/rejectwithdraw",
  "/withdrawsettings",
  "/withdrawmsg",
  "/withdrawmsgon",
  "/withdrawmsgoff",
  "/withdrawallow",
  "/withdrawallowremove",
  "/withdrawallowlist",
  "/depositsettings",
  "/packages",
  "/setpackage",
  "/setpackageprice",
  "/setpackagepercent",
  "/setcoinvalue",
  "/announcement",
  "/announcementimage",
  "/setwelcome",
  "/channeljoinpopupshow",
  "/channeljoinlist",
  "/channeljoinremove",
  "/maintainpopupon",
  "/maintainpopupoff",
  "/maomtainpopupoff",
  "/noneedchanneljoin",
  "/addadmin",
  "/removeadmin",
  "/setminwithdraw",
  "/admindepositmsgon",
  "/admindepositmsgoff",
  "/sendcoinuser",
  "/setdepositaddress",
  "/setdepositrate",
  "/setmindeposit",
  "/setmaxdeposit",
  "/confirmdeposit",
]);

function largestPhoto(message: TgMessage): string | undefined {
  const photos = message.photo;
  if (!photos?.length) return undefined;
  return photos[photos.length - 1]?.file_id;
}

function parseCommand(text: string): { cmd: string; arg: string } {
  const trimmed = text.trim();
  const [raw, ...rest] = trimmed.split(/\s+/);
  const cmd = (raw || "").split("@")[0]!.toLowerCase();
  return { cmd, arg: rest.join(" ").trim() };
}

export async function handleBotUpdate(update: TgUpdate, origin: string): Promise<void> {
  if (update.channel_post) {
    await onChannelPost(update.channel_post);
    return;
  }
  if (update.callback_query) {
    await onCallback(update.callback_query, origin);
    return;
  }
  const message = update.message;
  if (!message?.from) return;
  const text = message.text || "";
  if (text.startsWith("/start")) {
    const payload = text.split(/\s+/)[1];
    await loadOrCreateMiner({
      minerId: `tg_${message.from.id}`,
      telegramId: message.from.id,
      name: message.from.first_name || "Miner",
      username: message.from.username,
      startParam: payload,
    });
    const webAppUrl = process.env.WEBAPP_URL || origin;
    await sendWelcome(message.chat.id, webAppUrl);
    return;
  }

  const admin = await isAdmin(message.from.id);
  if (text.startsWith("/help") || text === "/commands") {
    await reply(message.chat.id, admin ? `${USER_HELP}\n\n${ADMIN_HELP}` : USER_HELP);
    return;
  }
  if (!admin) return;

  if (text.startsWith("/cancel")) {
    flows().delete(message.from.id);
    await reply(message.chat.id, "Cancelled.");
    return;
  }

  const existing = flows().get(message.from.id);
  if (existing && !text.startsWith("/")) {
    await continueFlow(message, existing, origin);
    return;
  }
  if (existing && text.startsWith("/") && !["/announcement", "/announcementimage", "/setwelcome"].includes(parseCommand(text).cmd)) {
    // other commands cancel the flow
    flows().delete(message.from.id);
  }

  await handleAdminCommand(message, origin);
}

async function onChannelPost(post: { message_id: number; chat: { id: number; username?: string } }) {
  if (!matchesChannel(post.chat)) return;
  const url = postUrlFromChannel(post.chat, post.message_id);
  await refreshLatestPost(url);
}

async function onCallback(cb: TgCallback, origin: string) {
  const data = cb.data || "";
  const uid = cb.from.id;
  if (data.startsWith("r:")) {
    await answer(cb.id, "Referral income is collected in the Referrals tab.");
    return;
  }
  if (data.startsWith("w:ok:") || data.startsWith("w:no:") || data.startsWith("w:tx:")) {
    if (!(await isAdmin(uid))) {
      await answer(cb.id, "Not authorized.");
      return;
    }
    const id = data.slice(5);
    if (data.startsWith("w:tx:")) {
      flows().set(uid, {
        kind: "withdraw_hash",
        id,
        chatId: cb.message?.chat.id ?? uid,
        messageId: cb.message?.message_id ?? 0,
      });
      await answer(cb.id);
      await reply(
        cb.message?.chat.id ?? uid,
        `Send the TX hash for ${id}, or type skip to approve without one.\n/cancel to abort.`,
      );
      return;
    }
    const msg = await resolveWithdrawal(id, data.startsWith("w:ok:") ? "approved" : "rejected", uid);
    await answer(cb.id, msg);
    if (cb.message) await clearButtons(cb.message.chat.id, cb.message.message_id);
    return;
  }

  if (data.startsWith("f:ok:") || data.startsWith("f:no:") || data.startsWith("f:tx:")) {
    if (!(await isAdmin(uid))) {
      await answer(cb.id, "Not authorized.");
      return;
    }
    const id = data.slice(5);
    if (data.startsWith("f:tx:")) {
      flows().set(uid, {
        kind: "refund_hash",
        id,
        chatId: cb.message?.chat.id ?? uid,
        messageId: cb.message?.message_id ?? 0,
      });
      await answer(cb.id);
      await reply(
        cb.message?.chat.id ?? uid,
        `Send the TX hash of the refund for ${id}, or type skip to mark it as sent without one.\n/cancel to abort.`,
      );
      return;
    }
    const msg = await resolveRefund(id, data.startsWith("f:ok:") ? "refunded" : "rejected", uid);
    await answer(cb.id, msg);
    if (cb.message) await clearButtons(cb.message.chat.id, cb.message.message_id);
    return;
  }
  // KYC approve/reject ("v:ok:"/"v:no:") arrives on the Verification Bot's own webhook
  // (handleVerifyBotUpdate below), not here, since that is the bot the video was sent from.
  if (data.startsWith("a:")) {
    if (!(await isAdmin(uid))) {
      await answer(cb.id, "Not authorized.");
      return;
    }
    await answer(cb.id);
    await continueFlowCallback(cb, data.slice(2), origin);
  }
}

async function handleAdminCommand(message: TgMessage, origin: string) {
  const from = message.from!;
  const chatId = message.chat.id;
  const { cmd, arg } = parseCommand(message.text || "");
  if (!ACTIVE_COMMANDS.has(cmd)) return;

  if (cmd === "/stats") {
    const [users, mining, pendingW, tasks, pendingV] = await Promise.all([
      userCounts(),
      countMining(),
      countByStatus("pending"),
      countTasks(),
      countPendingVerifications(),
    ]);
    await reply(
      chatId,
      [
        "Ghairo stats",
        `Users: ${users.total}  (today ${users.today}, 7d ${users.week})`,
        `Mining now: ${mining}`,
        `Tasks: ${tasks}`,
        `Pending withdrawals: ${pendingW}`,
        `Pending liveness: ${pendingV}`,
      ].join("\n"),
    );
    return;
  }

  if (cmd === "/totalusers") {
    const users = await userCounts();
    await reply(
      chatId,
      `Total: ${users.total}\nToday: ${users.today}\nLast 7 days: ${users.week}`,
    );
    return;
  }

  if (cmd === "/withdrawals") {
    const rows = await listPendingWithdrawals();
    if (!rows.length) {
      await reply(chatId, "No pending withdrawals.");
      return;
    }
    const lines = rows.slice(0, 20).map(
      (row) =>
        `${row.id}  ${fmtAmount(row.amount)} coin → send ${fmtAmount(row.payout ?? row.gram ?? 0)} ${row.method === "usdt" ? "USDT" : "Gram"} (≈ $${row.usd ?? 0})  ${row.minerId}\n${toFriendlyAddress(row.address)}`,
    );
    await reply(chatId, `Pending withdrawals\n\n${lines.join("\n")}`);
    return;
  }

  if (cmd === "/approvewithdraw") {
    const [wid, ...hashParts] = arg.split(/\s+/);
    if (!wid) {
      await reply(chatId, "Usage: /approvewithdraw <id> [txhash]");
      return;
    }
    const hash = hashParts.join("").trim();
    await reply(chatId, await resolveWithdrawal(wid, "approved", from.id, hash || undefined));
    return;
  }

  if (cmd === "/rejectwithdraw") {
    if (!arg) {
      await reply(chatId, "Usage: /rejectwithdraw <id>");
      return;
    }
    await reply(chatId, await resolveWithdrawal(arg.split(/\s+/)[0]!, "rejected", from.id));
    return;
  }

  if (cmd === "/withdrawsettings") {
    const r = await getWithdrawRules();
    await reply(chatId, withdrawSettingsText(r, (await getSettings()).coinUsd ?? COIN_USD));
    return;
  }

  if (cmd === "/setminwithdraw" || cmd === "/setmaxwithdraw" || cmd === "/setwithdrawfee") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const value = Number(arg.replace(/,/g, ""));
    if (!arg || !Number.isFinite(value) || value < 0) {
      await reply(chatId, `Usage: ${cmd} <amount>  (a number, 0 or more)`);
      return;
    }
    const r = await getWithdrawRules();
    if (cmd === "/setminwithdraw") {
      if (value <= r.fee) {
        await reply(chatId, `Minimum must be more than the fee (${fmtAmount(r.fee)} ${TOKEN_SYMBOL}).`);
        return;
      }
      if (r.max > 0 && value > r.max) {
        await reply(chatId, `Minimum cannot be above the maximum (${fmtAmount(r.max)} ${TOKEN_SYMBOL}).`);
        return;
      }
      r.min = value;
      await saveSettings({ minWithdraw: value });
    } else if (cmd === "/setmaxwithdraw") {
      if (value > 0 && value < r.min) {
        await reply(chatId, `Maximum cannot be below the minimum (${fmtAmount(r.min)} ${TOKEN_SYMBOL}). Use 0 for no limit.`);
        return;
      }
      r.max = value;
      await saveSettings({ maxWithdraw: value });
    } else {
      if (value >= r.min) {
        await reply(chatId, `Fee must be below the minimum withdrawal (${fmtAmount(r.min)} ${TOKEN_SYMBOL}).`);
        return;
      }
      r.fee = value;
      await saveSettings({ withdrawFee: value });
    }
    await reply(chatId, `Saved.\n\n${withdrawSettingsText(r, (await getSettings()).coinUsd ?? COIN_USD)}`);
    return;
  }

  if (cmd === "/addadmin") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const id = Number(arg);
    if (!Number.isFinite(id) || id <= 0) {
      await reply(chatId, "Usage: /addadmin <telegramId>");
      return;
    }
    if (isOwner(id)) {
      await reply(chatId, "The owner is already an admin.");
      return;
    }
    await addAdmin({ telegramId: id, addedBy: from.id, addedAt: Date.now() });
    await reply(chatId, `Admin ${id} added.`);
    return;
  }

  if (cmd === "/removeadmin") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const id = Number(arg);
    if (!Number.isFinite(id)) {
      await reply(chatId, "Usage: /removeadmin <telegramId>");
      return;
    }
    if (isOwner(id)) {
      await reply(chatId, "The owner cannot be removed.");
      return;
    }
    const ok = await removeAdmin(id);
    await reply(chatId, ok ? `Admin ${id} removed.` : "That Telegram ID is not an admin.");
    return;
  }

  if (cmd === "/tasks") {
    const tasks = await listTasks();
    if (!tasks.length) {
      await reply(chatId, "No tasks yet. Use /addtask.");
      return;
    }
    const lines = tasks.map((t) => {
      const cd =
        t.cooldownMs === 0
          ? "one-time"
          : `${((t.cooldownMs ?? DEFAULT_TASK_COOLDOWN_MS) / 3_600_000).toFixed(1)}h cooldown`;
      return `${t.id}  [${t.category}]  ${t.title}  +${t.reward}  ${t.verification}  ${cd}`;
    });
    await reply(chatId, lines.join("\n"));
    return;
  }

  if (cmd === "/settaskcooldown") {
    const [taskId, hoursArg] = arg.split(/\s+/);
    const hours = Number(hoursArg);
    if (!taskId || !Number.isFinite(hours) || hours < 0) {
      await reply(chatId, "Usage: /settaskcooldown <id> <hours>\nUse 0 for one-time only.");
      return;
    }
    const task = await getTask(taskId);
    if (!task) {
      await reply(chatId, "Unknown task id. Use /tasks to see ids.");
      return;
    }
    task.cooldownMs = Math.round(hours * 3_600_000);
    task.updatedAt = Date.now();
    await saveTask(task);
    await reply(
      chatId,
      `Saved. ${task.title}: ${hours === 0 ? "one-time only" : `claimable again every ${hours}h`}.`,
    );
    return;
  }

  if (cmd === "/deletetask") {
    if (!arg) {
      await reply(chatId, "Usage: /deletetask <id>");
      return;
    }
    const ok = await deleteTask(arg);
    await reply(chatId, ok ? `Deleted ${arg}.` : "Task not found.");
    return;
  }

  if (cmd === "/verifications") {
    const rows = await listPendingVerifications();
    if (!rows.length) {
      await reply(chatId, "No pending liveness checks.");
      return;
    }
    const lines = rows.map(
      (row) => `${row.id}  ${row.name}  ${row.username ? `@${row.username}` : row.telegramId ?? row.minerId}`,
    );
    await reply(chatId, `Pending liveness\n\n${lines.join("\n")}`);
    return;
  }

  if (cmd === "/approveverify") {
    if (!arg) {
      await reply(chatId, "Usage: /approveverify <id>");
      return;
    }
    await reply(chatId, await resolveLiveness(arg, "approved", from.id));
    return;
  }

  if (cmd === "/rejectverify") {
    if (!arg) {
      await reply(chatId, "Usage: /rejectverify <id>");
      return;
    }
    await reply(chatId, await resolveLiveness(arg, "rejected", from.id));
    return;
  }

  if (cmd === "/announcement") {
    flows().set(from.id, { kind: "announce", step: "text" });
    await reply(chatId, "Send the announcement text.\n/cancel to abort.");
    return;
  }

  if (cmd === "/announcementimage") {
    flows().set(from.id, { kind: "announce_image", step: "photo" });
    await reply(chatId, "Send the image (as a photo).\n/cancel to abort.");
    return;
  }

  if (cmd === "/addtask") {
    flows().set(from.id, { kind: "addtask", step: "category" });
    await reply(chatId, "Task category?", {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Official Task", callback_data: "a:cat:official" },
            { text: "Partner Task", callback_data: "a:cat:partner" },
          ],
        ],
      },
    });
    return;
  }

  if (cmd === "/edittask") {
    if (!arg) {
      await reply(chatId, "Usage: /edittask <id>");
      return;
    }
    const task = await getTask(arg);
    if (!task) {
      await reply(chatId, "Task not found.");
      return;
    }
    flows().set(from.id, { kind: "edittask", step: "field", taskId: task.id });
    await reply(chatId, `Editing ${task.id} — ${task.title}\nChoose a field.`, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Title", callback_data: "a:ef:title" },
            { text: "Reward", callback_data: "a:ef:reward" },
          ],
          [
            { text: "Link", callback_data: "a:ef:link" },
            { text: "Detail", callback_data: "a:ef:detail" },
          ],
          [
            { text: "Category", callback_data: "a:ef:category" },
            { text: "Verification", callback_data: "a:ef:verification" },
          ],
        ],
      },
    });
    return;
  }

  if (cmd === "/setwelcome") {
    flows().set(from.id, { kind: "welcome", step: "text" });
    await reply(chatId, "Send the new /start text.\n/cancel to abort.");
    return;
  }

  if (cmd === "/nftvalues") {
    const s = await getSettings();
    const entries = Object.entries(s.nftValues ?? {});
    const lines = [
      "NFT hold values",
      `Default: ${s.nftDefaultValue && s.nftDefaultValue > 0 ? `${fmtAmount(s.nftDefaultValue)} ${TOKEN_SYMBOL}` : "not set (NFTs without their own value cannot be held)"}`,
    ];
    for (const [raw, value] of entries) {
      const a = parseTonAddress(raw);
      lines.push("", `${a ? friendlyTonAddress(a, true) : raw}`, `= ${fmtAmount(value)} ${TOKEN_SYMBOL}`);
    }
    if (entries.length === 0) lines.push("", "No per-NFT / per-collection values yet.");
    await reply(chatId, lines.join("\n"));
    return;
  }

  if (cmd === "/setnftvalue") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const [target, valueArg] = arg.split(/\s+/);
    const value = Number((valueArg ?? "").replace(/,/g, ""));
    const key = target === "default" ? "default" : normalizeTonAddress(target);
    if (!target || !key || !Number.isFinite(value) || value < 0) {
      await reply(
        chatId,
        "Usage: /setnftvalue <nft or collection address|default> <Ghairo>\nExample: /setnftvalue default 500\nUse 0 to remove a value.",
      );
      return;
    }
    const current = await getSettings();
    if (key === "default") {
      await saveSettings({ nftDefaultValue: value });
    } else {
      const next = { ...(current.nftValues ?? {}) };
      if (value > 0) next[key] = value;
      else delete next[key];
      await saveSettings({ nftValues: next });
    }
    await reply(chatId, "Saved. Use /nftvalues to see all values.");
    return;
  }

  if (
    cmd === "/channeljoinpopupshow" ||
    cmd === "/channeljoinlist" ||
    cmd === "/channeljoinremove" ||
    cmd === "/noneedchanneljoin"
  ) {
    const cur = await getSettings();
    const list = joinListRaw(cur);
    const listText = () =>
      list.length
        ? list.map((c, i) => `${i + 1}. ${c.title ? `${c.title} — ` : ""}${c.url}`).join("\n")
        : "(no channels yet)";
    const help = [
      "Add a channel:  /channeljoinpopupshow https://t.me/yourchannel",
      "Private channel:  /channeljoinpopupshow https://t.me/+AbCd… -1001234567890",
      "Remove one:  /channeljoinremove <number>",
      "Turn the popup off:  /noneedchanneljoin",
      "The bot must be an admin of every channel.",
    ].join("\n");

    if (cmd === "/noneedchanneljoin") {
      await saveSettings({ joinEnabled: false, joinChannels: list });
      await reply(
        chatId,
        `✅ Channel join popup is OFF. Nobody needs to join to use the app.${list.length ? `\n\n${list.length} channel(s) are saved. Turn it on again with /channeljoinpopupshow.` : ""}`,
      );
      return;
    }

    if (cmd === "/channeljoinremove") {
      const n = Number(arg.trim());
      if (!Number.isInteger(n) || n < 1 || n > list.length) {
        await reply(chatId, `Usage: /channeljoinremove <number>\n\n${listText()}`);
        return;
      }
      const next = list.filter((_, i) => i !== n - 1);
      await saveSettings({ joinChannels: next, joinEnabled: next.length > 0 ? cur.joinEnabled : false });
      await reply(
        chatId,
        `✅ Removed channel ${n}.\n\n${next.length ? `Now required (${next.length}):\n${next.map((c, i) => `${i + 1}. ${c.title ? `${c.title} — ` : ""}${c.url}`).join("\n")}` : "No channels left, so the popup is OFF."}`,
      );
      return;
    }

    const [linkArg, chatArg] = arg.split(/\s+/);
    if (cmd === "/channeljoinlist" || !linkArg) {
      if (cmd === "/channeljoinpopupshow" && list.length && !cur.joinEnabled) {
        await saveSettings({ joinEnabled: true, joinChannels: list }); // no link given: switch the saved list back on
        await reply(chatId, `✅ Channel join popup is ON again.\n\nRequired (${list.length}):\n${listText()}`);
        return;
      }
      await reply(
        chatId,
        `Channel join popup: ${cur.joinEnabled ? "ON" : "OFF"}\n\nRequired (${list.length}):\n${listText()}\n\n${help}`,
      );
      return;
    }

    const parsed = parseChannelLink(linkArg);
    const chat = chatArg && /^-100\d+$/.test(chatArg) ? chatArg : parsed?.chat;
    if (!parsed || !chat) {
      await reply(
        chatId,
        parsed
          ? "That is a private invite link. Add the channel id too:\n/channeljoinpopupshow https://t.me/+AbCd… -1001234567890"
          : "That does not look like a channel link.\nExample: /channeljoinpopupshow https://t.me/yourchannel",
      );
      return;
    }
    if (list.some((c) => c.chatId === chat)) {
      await saveSettings({ joinEnabled: true, joinChannels: list });
      await reply(chatId, `That channel is already in the list.\n\nRequired (${list.length}):\n${listText()}`);
      return;
    }
    if (list.length >= 10) {
      await reply(chatId, "You can require up to 10 channels. Remove one with /channeljoinremove <number>.");
      return;
    }
    const check = await checkBotIsAdmin(chat);
    if (!check.ok) {
      await reply(chatId, `Not added.\n${check.reason ?? "Could not check the channel."}`);
      return;
    }
    const next = [...list, { url: parsed.url, chatId: chat, title: check.title }];
    await saveSettings({ joinEnabled: true, joinChannels: next });
    await reply(
      chatId,
      `✅ Channel added. The popup is ON.\n\nUsers must join all ${next.length}:\n${next.map((c, i) => `${i + 1}. ${c.title ? `${c.title} — ` : ""}${c.url}`).join("\n")}\n\nAdd more with /channeljoinpopupshow <link>.`,
    );
    return;
  }

  if (cmd === "/sendcoinuser") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const [idArg, amountArg] = arg.split(/\s+/);
    const telegramId = Number(idArg);
    const amount = Number((amountArg ?? "").replace(/,/g, ""));
    if (!Number.isInteger(telegramId) || telegramId <= 0 || !Number.isFinite(amount) || amount <= 0 || amount > 1_000_000) {
      await reply(chatId, "Usage: /sendcoinuser <telegramId> <amount>\nExample: /sendcoinuser 7657544184 5");
      return;
    }
    const target = await getMinerByTelegram(telegramId);
    if (!target) {
      await reply(chatId, `No user with Telegram ID ${telegramId}. They need to open the bot with /start first.`);
      return;
    }
    const rounded = Math.round(amount * 1e6) / 1e6;
    await incMinerPool(target.id, rounded);
    await addHistory({
      id: shortId("H"),
      minerId: target.id,
      kind: "admin_credit",
      amount: rounded,
      note: `by ${from.id}`,
      createdAt: Date.now(),
    });
    const after = await getMinerByTelegram(telegramId);
    await sendTelegram("sendMessage", {
      chat_id: telegramId,
      parse_mode: "HTML",
      text: `🎁 <b>You received ${fmtAmount(rounded)} coins!</b>\nThey have been added to your Ghairo balance.`,
    });
    await reply(
      chatId,
      `✅ Sent ${fmtAmount(rounded)} coins to ${target.name} (${telegramId}).\nTheir balance now: ${fmtAmount(after?.pool ?? target.pool + rounded)}`,
    );
    return;
  }

  if (cmd === "/admindepositmsgon" || cmd === "/admindepositmsgoff") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const on = cmd === "/admindepositmsgon";
    await saveSettings({ depositMsgToAdmins: on });
    await reply(
      chatId,
      on
        ? "✅ Deposit messages now go to the owner and all admins."
        : "✅ Deposit messages now go to the owner only. Admins will not get them.",
    );
    return;
  }

  if (cmd === "/withdrawmsg" || cmd === "/withdrawmsgon" || cmd === "/withdrawmsgoff") {
    const cur = await getSettings();
    if (cmd === "/withdrawmsgon" || cmd === "/withdrawmsgoff") {
      const on = cmd === "/withdrawmsgon";
      await saveSettings({ withdrawBlockEnabled: on });
      await reply(
        chatId,
        on
          ? `✅ Withdraw notice is ON. Users see it and cannot withdraw.\n\nMessage:\n${cur.withdrawBlockText || DEFAULT_WITHDRAW_NOTICE}`
          : "✅ Withdraw notice is OFF. Users can withdraw normally.",
      );
      return;
    }
    if (arg.trim()) {
      const text = arg.trim().slice(0, 300);
      await saveSettings({ withdrawBlockText: text });
      await reply(
        chatId,
        `✅ Message saved:\n${text}\n\nStatus: ${cur.withdrawBlockEnabled ? "ON (users see it)" : "OFF (use /withdrawmsgon to show it)"}`,
      );
      return;
    }
    await reply(
      chatId,
      [
        `Withdraw notice: ${cur.withdrawBlockEnabled ? "ON (withdrawals paused)" : "OFF (withdrawals open)"}`,
        `Allowed accounts: ${cur.withdrawAllowIds?.length ?? 0} (see /withdrawallowlist)`,
        "",
        `Message:\n${cur.withdrawBlockText || DEFAULT_WITHDRAW_NOTICE}`,
        "",
        "Change it: /withdrawmsg <new text>",
        "Show to users: /withdrawmsgon",
        "Hide: /withdrawmsgoff",
      ].join("\n"),
    );
    return;
  }

  if (cmd === "/withdrawallow" || cmd === "/withdrawallowremove" || cmd === "/withdrawallowlist") {
    const cur = await getSettings();
    const ids = cur.withdrawAllowIds ?? [];
    const describeId = async (id: number) => {
      const m = await getMinerByTelegram(id);
      return `${id}${m ? ` (${m.name})` : ""}`;
    };
    if (cmd === "/withdrawallowlist") {
      await reply(
        chatId,
        [
          `Withdraw notice: ${cur.withdrawBlockEnabled ? "ON" : "OFF"}`,
          ids.length
            ? `Allowed accounts (${ids.length}), they can withdraw even while it is ON:\n${(await Promise.all(ids.map(describeId))).join("\n")}`
            : "No allowed accounts. While the notice is ON, nobody can withdraw.",
          "",
          "Add: /withdrawallow <telegramId>",
          "Remove: /withdrawallowremove <telegramId>",
        ].join("\n"),
      );
      return;
    }
    const id = Number(arg.trim());
    if (!Number.isInteger(id) || id <= 0) {
      await reply(chatId, `Usage: ${cmd} <telegramId>\nExample: ${cmd} 7657544184`);
      return;
    }
    if (cmd === "/withdrawallow") {
      if (ids.includes(id)) {
        await reply(chatId, `${await describeId(id)} is already allowed.`);
        return;
      }
      if (ids.length >= 200) {
        await reply(chatId, "You can allow up to 200 accounts. Remove some with /withdrawallowremove.");
        return;
      }
      await saveSettings({ withdrawAllowIds: [...ids, id] });
      // Tell the user in their own chat that withdrawals are now open for them.
      const target = await getMinerByTelegram(id);
      const appUrl = (process.env.WEBAPP_URL || "").replace(/\/$/, "");
      const sent = await telegramCall("sendMessage", {
        chat_id: id,
        parse_mode: "HTML",
        text: withdrawUnlockedUser(target?.name ?? "there"),
        ...(appUrl
          ? { reply_markup: { inline_keyboard: [[{ text: "💸 Open Withdraw", web_app: { url: `${appUrl}?tab=withdraw` } }]] } }
          : {}),
      });
      await reply(
        chatId,
        `✅ ${await describeId(id)} can now withdraw. Everyone else still sees the notice${cur.withdrawBlockEnabled ? "" : " once you turn it on with /withdrawmsgon"}.\n${sent.ok ? "📩 The user got an unlock message." : "⚠️ Could not message the user (they may not have started the bot)."}`,
      );
      return;
    }
    if (!ids.includes(id)) {
      await reply(chatId, `${id} is not in the allowed list.`);
      return;
    }
    await saveSettings({ withdrawAllowIds: ids.filter((x) => x !== id) });
    await reply(chatId, `✅ ${await describeId(id)} is blocked again while the notice is ON.`);
    return;
  }

  if (cmd === "/maintainpopupon") {
    const text = arg.trim().slice(0, 200);
    await saveSettings({ maintenanceOn: true, maintenanceText: text });
    await reply(
      chatId,
      `🛠 Maintenance page is ON. Everyone who opens the app sees it.${text ? `\n\nYour message:\n${text}` : ""}\n\nTurn it off with /maintainpopupoff`,
    );
    return;
  }

  if (cmd === "/maintainpopupoff" || cmd === "/maomtainpopupoff") {
    await saveSettings({ maintenanceOn: false });
    await reply(chatId, "✅ Maintenance page is OFF. The app is open again.");
    return;
  }

  if (cmd === "/packages") {
    await reply(chatId, await packagesText());
    return;
  }

  if (cmd === "/setpackage" || cmd === "/setpackageprice" || cmd === "/setpackagepercent") {
    const parts = arg.split(/\s+/).filter(Boolean).map((x) => Number(x.replace(/,/g, "").replace(/%$/, "")));
    const usage =
      cmd === "/setpackage"
        ? "Usage: /setpackage <id> <price> <percent per day>\nExample: /setpackage 3 5 0.6"
        : cmd === "/setpackageprice"
          ? "Usage: /setpackageprice <id> <price>\nExample: /setpackageprice 3 5"
          : "Usage: /setpackagepercent <id> <percent per day>\nExample: /setpackagepercent 3 1";
    const need = cmd === "/setpackage" ? 3 : 2;
    const [id, x, y] = parts;
    if (parts.length !== need || parts.some((n) => !Number.isFinite(n) || n < 0) || !Number.isInteger(id) || id! < 1 || id! > BIRD_PACKAGES.length) {
      await reply(chatId, `${usage}\nPackage ids are 1 to ${BIRD_PACKAGES.length}. See /packages.`);
      return;
    }
    const packs = [...(await getPackages(true))];
    const cur = packs[id! - 1]!;
    const price = cmd === "/setpackagepercent" ? cur.price : x!;
    const percent = cmd === "/setpackage" ? y! : cmd === "/setpackagepercent" ? x! : cur.percent;
    if (!(price > 0)) {
      await reply(chatId, "Price must be more than 0.");
      return;
    }
    packs[id! - 1] = { price, percent };
    await saveSettings({ packages: packs });
    await getPackages(true);
    await reply(chatId, `Saved. Mini app updated.\n\n${await packagesText()}`);
    return;
  }

  if (cmd === "/setcoinvalue") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const value = Number(arg.replace(/,/g, ""));
    if (!arg || !Number.isFinite(value) || value <= 0) {
      await reply(chatId, "Usage: /setcoinvalue <usd>\nExample: /setcoinvalue 0.2  (1 coin = $0.20 when withdrawing)");
      return;
    }
    await saveSettings({ coinUsd: value });
    await reply(chatId, `Saved.\n\n${withdrawSettingsText(await getWithdrawRules(), value)}`);
    return;
  }

  if (cmd === "/depositsettings") {
    await reply(chatId, await depositSettingsText());
    return;
  }

  if (cmd === "/refunds") {
    const rows = await listRefundRequests();
    if (rows.length === 0) {
      await reply(chatId, "No refund requests.");
      return;
    }
    const lines = rows
      .slice(0, 20)
      .map(
        (d) =>
          `${d.id}  ${d.token === "nft" ? `NFT "${d.nftName ?? "NFT"}"` : `${fmtAmount(d.amount)} ${(d.token ?? "").toUpperCase()}`}  ${d.minerId}\n${toFriendlyAddress(d.wallet ?? "—")}`,
      );
    await reply(chatId, ["Refund requests", "", ...lines].join("\n\n"));
    return;
  }

  if (cmd === "/approverefund") {
    const [rid, ...hashParts] = arg.split(/\s+/);
    if (!rid) {
      await reply(chatId, "Usage: /approverefund <id> [txhash]");
      return;
    }
    const hash = hashParts.join("").trim();
    await reply(chatId, await resolveRefund(rid, "refunded", from.id, hash || undefined));
    return;
  }

  if (cmd === "/rejectrefund") {
    const rid = arg.split(/\s+/)[0];
    if (!rid) {
      await reply(chatId, "Usage: /rejectrefund <id>");
      return;
    }
    await reply(chatId, await resolveRefund(rid, "rejected", from.id));
    return;
  }

  if (cmd === "/setdepositaddress") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const addr = parseTonAddress(arg.trim());
    if (!addr) {
      await reply(chatId, "Usage: /setdepositaddress <TON address>\nThat is not a valid TON address.");
      return;
    }
    await saveSettings({ depositAddress: friendlyTonAddress(addr, false) });
    await reply(
      chatId,
      `Saved.\n\n${await depositSettingsText()}\n\nSend a small test deposit (for example 0.1 TON) from the Mini App first, to confirm payments are detected.`,
    );
    return;
  }

  if (cmd === "/setdepositrate") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const [tokenArg, rateArg] = arg.split(/\s+/);
    const rate = Number((rateArg ?? "").replace(/,/g, ""));
    const tk = (tokenArg ?? "").toLowerCase();
    if (!["gram", "ton", "usdt"].includes(tk) || !Number.isFinite(rate) || rate < 0) {
      await reply(
        chatId,
        "Usage: /setdepositrate <gram|usdt> <coins per 1>\nExample: /setdepositrate gram 1.5\nExample: /setdepositrate usdt 1\nUse 0 to close that method.",
      );
      return;
    }
    await saveSettings(tk === "usdt" ? { usdtRate: rate } : { tonRate: rate });
    await reply(chatId, `Saved.\n\n${await depositSettingsText()}`);
    return;
  }

  if (cmd === "/setmindeposit" || cmd === "/setmaxdeposit") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const [tokenArg, amountArg] = arg.split(/\s+/);
    const amount = Number((amountArg ?? "").replace(/,/g, ""));
    const tk = (tokenArg ?? "").toLowerCase();
    if (!["gram", "ton", "usdt"].includes(tk) || !Number.isFinite(amount) || amount < 0) {
      await reply(
        chatId,
        `Usage: ${cmd} <gram|usdt> <amount>` +
          (cmd === "/setmaxdeposit" ? "\nUse 0 for no limit." : ""),
      );
      return;
    }
    const isMax = cmd === "/setmaxdeposit";
    const patch =
      tk === "usdt"
        ? isMax
          ? { maxDepositUsdt: amount }
          : { minDepositUsdt: amount }
        : isMax
          ? { maxDepositTon: amount }
          : { minDepositTon: amount };
    await saveSettings(patch);
    await reply(chatId, `Saved.\n\n${await depositSettingsText()}`);
    return;
  }

  if (cmd === "/confirmdeposit") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const did = arg.split(/\s+/)[0];
    if (!did) {
      await reply(chatId, "Usage: /confirmdeposit <id>\nOnly after you have checked the payment yourself.");
      return;
    }
    await reply(chatId, await confirmDepositManually(did, from.id));
    return;
  }

  if (cmd === "/admins") {
    if (!isOwner(from.id)) {
      await reply(chatId, "Owner only.");
      return;
    }
    const rows = await listAdmins();
    const owner = ownerChatId();
    const lines = [`Owner: ${owner ?? "unset"}`, ...rows.map((r) => `Admin: ${r.telegramId}`)];
    await reply(chatId, lines.join("\n"));
    return;
  }

  void origin;
}

async function depositSettingsText(): Promise<string> {
  const d = await getDepositInfo();
  const gramUsd = await getGramUsd();
  return [
    "Deposit settings",
    `Address: ${d.address || "not set (use /setdepositaddress)"}`,
    `Gram: ${d.tonRate > 0 ? `1 Gram = ${fmtAmount(d.tonRate)} coin` : "closed"}  (min ${fmtAmount(d.minTon)}, max ${d.maxTon > 0 ? fmtAmount(d.maxTon) : "no limit"})`,
    `USDT: ${d.usdtRate > 0 ? `1 USDT = ${fmtAmount(d.usdtRate)} coin` : "closed"}  (min ${fmtAmount(d.minUsdt)}, max ${d.maxUsdt > 0 ? fmtAmount(d.maxUsdt) : "no limit"})`,
    `Gram price now: $${fmtAmount(gramUsd)}`,
    `Status: ${d.enabled ? "open" : "closed"}`,
    `Deposit messages to admins: ${(await getSettings()).depositMsgToAdmins === false ? "OFF (owner only)" : "ON"}`,
  ].join("\n");
}

function withdrawSettingsText(r: { min: number; max: number; fee: number }, coinUsd = COIN_USD): string {
  return [
    "Withdraw settings",
    `Minimum: ${fmtAmount(r.min)} coin`,
    `Maximum: ${r.max > 0 ? `${fmtAmount(r.max)} coin` : "no limit"}`,
    `1 coin = $${fmtAmount(coinUsd)} when withdrawing (change with /setcoinvalue)`,
    "Users pick Gram or USDT. You send the payout, then approve.",
  ].join("\n");
}

async function packagesText(): Promise<string> {
  const packs = await getPackages(true);
  return [
    "Gem packages (id · price · % per day · coin per day · coin per month)",
    "",
    ...packs.map(
      (p, i) =>
        `${i + 1} · ${fmtAmount(p.price)} · ${fmtAmount(p.percent)}% · ${fmtAmount(packageDaily(i, packs))} · ${fmtAmount(packageDaily(i, packs) * 30)}`,
    ),
    "",
    "Edit: /setpackage <id> <price> <percent per day>",
  ].join("\n");
}

async function continueFlow(message: TgMessage, flow: Flow, origin: string) {
  const uid = message.from!.id;
  const chatId = message.chat.id;

  if (flow.kind === "withdraw_hash") {
    const raw = (message.text || "").trim();
    const skip = raw.toLowerCase() === "skip";
    if (!skip && (raw.length < 8 || raw.length > 128 || /\s/.test(raw))) {
      await reply(chatId, "That does not look like a TX hash. Send it again, or type skip.\n/cancel to abort.");
      return;
    }
    flows().delete(uid);
    await reply(chatId, await resolveWithdrawal(flow.id, "approved", uid, skip ? undefined : raw));
    if (flow.messageId) await clearButtons(flow.chatId, flow.messageId);
    return;
  }

  if (flow.kind === "refund_hash") {
    const raw = (message.text || "").trim();
    const skip = raw.toLowerCase() === "skip";
    if (!skip && (raw.length < 8 || raw.length > 128 || /\s/.test(raw))) {
      await reply(chatId, "That does not look like a TX hash. Send it again, or type skip.\n/cancel to abort.");
      return;
    }
    flows().delete(uid);
    await reply(chatId, await resolveRefund(flow.id, "refunded", uid, skip ? undefined : raw));
    if (flow.messageId) await clearButtons(flow.chatId, flow.messageId);
    return;
  }

  if (flow.kind === "announce") {
    if (flow.step === "text") {
      if (!message.text) {
        await reply(chatId, "Send the announcement as text.");
        return;
      }
      flow.text = message.text;
      flow.step = "button";
      flows().set(uid, flow);
      await askButton(chatId);
      return;
    }
    if (flow.step === "btntext") {
      flow.btnText = (message.text || "").slice(0, 64);
      flow.step = "btnurl";
      flows().set(uid, flow);
      await reply(chatId, "Send the button URL.");
      return;
    }
    if (flow.step === "btnurl") {
      flow.btnUrl = (message.text || "").trim();
      flow.step = "dest";
      flows().set(uid, flow);
      await askDest(chatId);
    }
    return;
  }

  if (flow.kind === "announce_image") {
    if (flow.step === "photo") {
      const fileId = largestPhoto(message);
      if (!fileId) {
        await reply(chatId, "Send the image as a photo (not a file).");
        return;
      }
      flow.image = fileId;
      flow.step = "caption";
      flows().set(uid, flow);
      await reply(chatId, "Send a caption, or tap Skip.", {
        reply_markup: { inline_keyboard: [[{ text: "Skip", callback_data: "a:skip" }]] },
      });
      return;
    }
    if (flow.step === "caption") {
      flow.text = message.text || message.caption || "";
      flow.step = "button";
      flows().set(uid, flow);
      await askButton(chatId);
      return;
    }
    if (flow.step === "btntext") {
      flow.btnText = (message.text || "").slice(0, 64);
      flow.step = "btnurl";
      flows().set(uid, flow);
      await reply(chatId, "Send the button URL.");
      return;
    }
    if (flow.step === "btnurl") {
      flow.btnUrl = (message.text || "").trim();
      flow.step = "dest";
      flows().set(uid, flow);
      await askDest(chatId);
    }
    return;
  }

  if (flow.kind === "addtask") {
    if (flow.step === "title") {
      flow.title = (message.text || "").slice(0, 80);
      flow.step = "reward";
      flows().set(uid, flow);
      await reply(chatId, "Reward amount (Ghairo number).");
      return;
    }
    if (flow.step === "reward") {
      const n = Number(message.text);
      if (!Number.isFinite(n) || n <= 0) {
        await reply(chatId, "Send a positive number.");
        return;
      }
      flow.reward = n;
      flow.step = "link";
      flows().set(uid, flow);
      await reply(chatId, "Task link (https:// or t.me/…).");
      return;
    }
    if (flow.step === "link") {
      flow.link = (message.text || "").trim();
      flow.step = "verify";
      flows().set(uid, flow);
      await reply(chatId, "Verification type?", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Join Channel (verified)", callback_data: "a:ver:join_channel" }],
            [{ text: "React to Latest Post (timer)", callback_data: "a:ver:react_latest" }],
            [{ text: "Timer + Claim", callback_data: "a:ver:timer_claim" }],
          ],
        },
      });
      return;
    }
    if (flow.step === "channel") {
      flow.channelId = (message.text || "").trim() || process.env.CHANNEL_ID;
      flow.step = "confirm";
      flows().set(uid, flow);
      await confirmTask(chatId, flow);
    }
    return;
  }

  if (flow.kind === "edittask" && flow.step === "value") {
    flow.value = message.text || "";
    flow.step = "confirm";
    flows().set(uid, flow);
    await reply(chatId, `Set ${flow.field} to:\n${flow.value}\n\nConfirm?`, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Save", callback_data: "a:yes" },
            { text: "Cancel", callback_data: "a:no" },
          ],
        ],
      },
    });
    return;
  }

  if (flow.kind === "welcome") {
    if (flow.step === "text") {
      flow.text = message.text || "";
      flow.step = "image";
      flows().set(uid, flow);
      await reply(chatId, "Send a photo for /start, or tap Skip.", {
        reply_markup: { inline_keyboard: [[{ text: "Skip", callback_data: "a:skip" }]] },
      });
      return;
    }
    if (flow.step === "image") {
      const fileId = largestPhoto(message);
      if (fileId) flow.image = fileId;
      flow.step = "button";
      flows().set(uid, flow);
      await reply(chatId, "Send the Open App button label.");
      return;
    }
    if (flow.step === "button") {
      flow.button = (message.text || "Open Ghairo").slice(0, 32);
      flow.step = "confirm";
      flows().set(uid, flow);
      await reply(chatId, `Save welcome message?\n\n${flow.text}\nButton: ${flow.button}`, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Save", callback_data: "a:yes" },
              { text: "Cancel", callback_data: "a:no" },
            ],
          ],
        },
      });
    }
  }
  void origin;
}

async function continueFlowCallback(cb: TgCallback, data: string, origin: string) {
  const uid = cb.from.id;
  const chatId = cb.message?.chat.id ?? uid;
  const flow = flows().get(uid);
  if (!flow) {
    await reply(chatId, "No active flow. Start again.");
    return;
  }

  if (data === "no") {
    flows().delete(uid);
    await reply(chatId, "Cancelled.");
    return;
  }

  if (flow.kind === "announce" || flow.kind === "announce_image") {
    if (data === "skip" && flow.kind === "announce_image" && flow.step === "caption") {
      flow.step = "button";
      flows().set(uid, flow);
      await askButton(chatId);
      return;
    }
    if (flow.step === "button") {
      if (data === "btn:yes") {
        flow.step = "btntext";
        flows().set(uid, flow);
        await reply(chatId, "Send the button label.");
        return;
      }
      if (data === "btn:no") {
        flow.step = "dest";
        flows().set(uid, flow);
        await askDest(chatId);
        return;
      }
    }
    if (flow.step === "dest" && (data === "d:users" || data === "d:channel" || data === "d:both")) {
      flow.dest = data.slice(2) as Dest;
      flow.step = "confirm";
      flows().set(uid, flow);
      await reply(chatId, previewAnnounce(flow), {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Send now", callback_data: "a:yes" },
              { text: "Cancel", callback_data: "a:no" },
            ],
          ],
        },
      });
      return;
    }
    if (data === "yes" && flow.step === "confirm") {
      flows().delete(uid);
      await reply(chatId, "Sending…");
      void runAnnounce(flow, origin, chatId);
      return;
    }
  }

  if (flow.kind === "addtask") {
    if (data.startsWith("cat:")) {
      flow.category = data.slice(4) as TaskCategory;
      flow.step = "title";
      flows().set(uid, flow);
      await reply(chatId, "Task title?");
      return;
    }
    if (data.startsWith("ver:")) {
      flow.verification = data.slice(4) as TaskVerification;
      if (flow.verification === "join_channel") {
        flow.step = "channel";
        flows().set(uid, flow);
        await reply(
          chatId,
          `Channel ID for getChatMember check?\nSend @username or numeric id, or tap Use default.`,
          {
            reply_markup: {
              inline_keyboard: [[{ text: "Use default CHANNEL_ID", callback_data: "a:chdef" }]],
            },
          },
        );
        return;
      }
      flow.step = "confirm";
      flows().set(uid, flow);
      await confirmTask(chatId, flow);
      return;
    }
    if (data === "chdef") {
      flow.channelId = process.env.CHANNEL_ID;
      flow.step = "confirm";
      flows().set(uid, flow);
      await confirmTask(chatId, flow);
      return;
    }
    if (data === "yes" && flow.step === "confirm") {
      const task = await persistNewTask(flow);
      flows().delete(uid);
      await reply(chatId, `Task ${task.id} created.`);
      return;
    }
  }

  if (flow.kind === "edittask") {
    if (data.startsWith("ef:")) {
      flow.field = data.slice(3) as typeof flow.field;
      flow.step = "value";
      flows().set(uid, flow);
      if (flow.field === "category") {
        await reply(chatId, "Pick a category.", {
          reply_markup: {
            inline_keyboard: [
              [
                { text: "Official", callback_data: "a:ev:official" },
                { text: "Partner", callback_data: "a:ev:partner" },
              ],
            ],
          },
        });
        return;
      }
      if (flow.field === "verification") {
        await reply(chatId, "Pick verification.", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "Join Channel", callback_data: "a:ev:join_channel" }],
              [{ text: "React to Latest Post", callback_data: "a:ev:react_latest" }],
              [{ text: "Timer + Claim", callback_data: "a:ev:timer_claim" }],
            ],
          },
        });
        return;
      }
      await reply(chatId, `Send the new ${flow.field}.`);
      return;
    }
    if (data.startsWith("ev:")) {
      flow.value = data.slice(3);
      flow.step = "confirm";
      flows().set(uid, flow);
      await reply(chatId, `Set ${flow.field} to ${flow.value}?`, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Save", callback_data: "a:yes" },
              { text: "Cancel", callback_data: "a:no" },
            ],
          ],
        },
      });
      return;
    }
    if (data === "yes" && flow.step === "confirm" && flow.field && flow.value !== undefined) {
      const task = await getTask(flow.taskId);
      if (!task) {
        flows().delete(uid);
        await reply(chatId, "Task not found.");
        return;
      }
      if (flow.field === "reward") task.reward = Number(flow.value) || task.reward;
      else if (flow.field === "category") task.category = flow.value as TaskCategory;
      else if (flow.field === "verification") task.verification = flow.value as TaskVerification;
      else if (flow.field === "title") task.title = flow.value;
      else if (flow.field === "link") task.link = flow.value;
      else if (flow.field === "detail") task.detail = flow.value;
      task.updatedAt = Date.now();
      await saveTask(task);
      flows().delete(uid);
      await reply(chatId, `Updated ${task.id}.`);
      return;
    }
  }

  if (flow.kind === "welcome") {
    if (data === "skip" && flow.step === "image") {
      flow.step = "button";
      flows().set(uid, flow);
      await reply(chatId, "Send the Open App button label.");
      return;
    }
    if (data === "yes" && flow.step === "confirm") {
      await saveSettings({
        welcomeText: flow.text || (await getSettings()).welcomeText,
        welcomeImage: flow.image,
        welcomeButton: flow.button || "Open Ghairo",
      });
      flows().delete(uid);
      await reply(chatId, "Welcome message saved. /start will use it immediately.");
    }
  }
}

function askButton(chatId: number) {
  return reply(chatId, "Add an inline button?", {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Yes", callback_data: "a:btn:yes" },
          { text: "No", callback_data: "a:btn:no" },
        ],
      ],
    },
  });
}

function askDest(chatId: number) {
  return reply(chatId, "Where should this go?", {
    reply_markup: {
      inline_keyboard: [
        [{ text: "Send to users", callback_data: "a:d:users" }],
        [{ text: "Post to channel", callback_data: "a:d:channel" }],
        [{ text: "Both", callback_data: "a:d:both" }],
      ],
    },
  });
}

function previewAnnounce(flow: Extract<Flow, { kind: "announce" | "announce_image" }>) {
  return [
    flow.image ? "Image: yes" : "Image: no",
    `Text: ${flow.text || "(none)"}`,
    flow.btnText ? `Button: ${flow.btnText} → ${flow.btnUrl}` : "Button: none",
    `Destination: ${flow.dest}`,
  ].join("\n");
}

function announceMarkup(flow: Extract<Flow, { kind: "announce" | "announce_image" }>) {
  if (flow.btnText && flow.btnUrl) {
    return { inline_keyboard: [[{ text: flow.btnText, url: flow.btnUrl }]] };
  }
  return undefined;
}

async function runAnnounce(
  flow: Extract<Flow, { kind: "announce" | "announce_image" }>,
  _origin: string,
  reportChat: number,
) {
  const dest = flow.dest || "users";
  const markup = announceMarkup(flow);
  let sent = 0;
  let failed = 0;
  if (dest === "channel" || dest === "both") {
    const channel = process.env.CHANNEL_ID;
    if (!channel) {
      await reply(reportChat, "CHANNEL_ID is not set — skipped channel post.");
    } else {
      await sendContent(channel, flow, markup);
      sent += 1;
    }
  }
  if (dest === "users" || dest === "both") {
    const users = await listTelegramMiners();
    for (const miner of users) {
      if (!miner.telegramId) continue;
      try {
        await sendContent(miner.telegramId, flow, markup);
        sent += 1;
        await sleep(40);
      } catch {
        failed += 1;
      }
    }
  }
  await reply(reportChat, `Done. Sent ${sent}. Failed ${failed}.`);
}

async function sendContent(
  chatId: number | string,
  flow: Extract<Flow, { kind: "announce" | "announce_image" }>,
  markup: unknown,
) {
  if (flow.image) {
    await telegramCall("sendPhoto", {
      chat_id: chatId,
      photo: flow.image,
      caption: flow.text || undefined,
      reply_markup: markup,
    });
    return;
  }
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text: flow.text || " ",
    reply_markup: markup,
  });
}

function confirmTask(chatId: number, flow: Extract<Flow, { kind: "addtask" }>) {
  return reply(
    chatId,
    [
      "Create task?",
      `Category: ${flow.category}`,
      `Title: ${flow.title}`,
      `Reward: ${flow.reward} ${TOKEN_SYMBOL}`,
      `Link: ${flow.link}`,
      `Verify: ${flow.verification}`,
      flow.verification === "join_channel" ? `Channel: ${flow.channelId || process.env.CHANNEL_ID || "unset"}` : "",
      flow.verification === "react_latest" ? `Claim wait: ${REACT_CLAIM_MS / 1000}s (not a verified reaction)` : "",
    ]
      .filter(Boolean)
      .join("\n"),
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Create", callback_data: "a:yes" },
            { text: "Cancel", callback_data: "a:no" },
          ],
        ],
      },
    },
  );
}

async function persistNewTask(flow: Extract<Flow, { kind: "addtask" }>): Promise<TaskDef> {
  const now = Date.now();
  const settings = await getSettings();
  let link = flow.link || "";
  if (flow.verification === "react_latest" && settings.latestPostUrl) {
    link = settings.latestPostUrl;
  }
  const task: TaskDef = {
    id: shortId("T", 5),
    category: flow.category || "official",
    title: flow.title || "Task",
    detail:
      flow.verification === "join_channel"
        ? "Verified via Telegram membership"
        : flow.verification === "react_latest"
          ? "Open the latest post, wait 15s, then claim"
          : "Open the link, wait 15s, then claim",
    reward: flow.reward || 0,
    link,
    verification: flow.verification || "timer_claim",
    channelId: flow.channelId,
    createdAt: now,
    updatedAt: now,
  };
  await saveTask(task);
  return task;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function handleVerifyBotUpdate(update: TgUpdate, origin: string): Promise<void> {
  const cb = update.callback_query;
  if (cb && cb.data && (cb.data.startsWith("v:ok:") || cb.data.startsWith("v:no:"))) {
    const token = process.env.VERIFY_BOT_TOKEN;
    if (!(await isAdmin(cb.from.id))) {
      await telegramCall("answerCallbackQuery", { callback_query_id: cb.id, text: "Not authorized." }, token);
      return;
    }
    const id = cb.data.slice(5);
    const msg = await handleKycCallback({
      action: cb.data.startsWith("v:ok:") ? "approved" : "rejected",
      id,
      by: cb.from.id,
      chatId: cb.message?.chat.id,
      messageId: cb.message?.message_id,
    });
    await telegramCall("answerCallbackQuery", { callback_query_id: cb.id, text: msg }, token);
    return;
  }

  const message = update.message;
  if (!message?.from) return;
  const text = message.text || "";
  if (!text.startsWith("/start") && !text.startsWith("/verify")) return;
  const url = `${process.env.WEBAPP_URL || origin}/verification`;
  const token = process.env.VERIFY_BOT_TOKEN;
  await telegramCall(
    "sendMessage",
    {
      chat_id: message.chat.id,
      text: [
        "Ghairo — account verification",
        "",
        "This is a face-scan KYC check used only to confirm you are a real person. It is reviewed by an admin, not stored publicly.",
        "",
        "Tap below, record a short selfie video, and wait for admin review.",
      ].join("\n"),
      reply_markup: {
        inline_keyboard: [[{ text: "Start verification", web_app: { url } }]],
      },
    },
    token,
  );
     }
