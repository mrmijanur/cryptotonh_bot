import { createHmac, randomUUID } from "node:crypto";
import { getCookie, setCookie } from "@tanstack/react-start/server";

const COOKIE = "ghairo_sid";

function secret(): string {
  return process.env.GHAIRO_SESSION_SECRET || process.env.FELVORA_SESSION_SECRET || "ghairo-preview-session-key-do-not-use";
}

function sign(id: string): string {
  const mac = createHmac("sha256", secret()).update(id).digest("hex").slice(0, 24);
  return `${id}.${mac}`;
}

function unsign(value: string | undefined): string | null {
  if (!value) return null;
  const i = value.lastIndexOf(".");
  if (i < 1) return null;
  const id = value.slice(0, i);
  const mac = value.slice(i + 1);
  const expected = createHmac("sha256", secret()).update(id).digest("hex").slice(0, 24);
  if (mac.length !== expected.length) return null;
  let diff = 0;
  for (let n = 0; n < mac.length; n += 1) diff |= mac.charCodeAt(n) ^ expected.charCodeAt(n);
  return diff === 0 ? id : null;
}

export function readMinerId(): string | null {
  return unsign(getCookie(COOKIE));
}

export function writeMinerId(id: string): void {
  setCookie(COOKIE, sign(id), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 400,
    secure: process.env.NODE_ENV === "production",
  });
}

export function newMinerId(telegramId?: number): string {
  if (telegramId) return `tg_${telegramId}`;
  return `web_${randomUUID()}`;
}

export function botTokenEnabled(): boolean {
  return Boolean(process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN);
}
