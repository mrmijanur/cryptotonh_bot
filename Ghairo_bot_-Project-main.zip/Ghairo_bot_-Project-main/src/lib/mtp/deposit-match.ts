// Pure matching of TonAPI account events against a pending deposit.
// Kept free of I/O so it can be unit-tested with sample payloads.
import { normalizeTonAddress } from "./ton-boc";

type Party = { address?: string } | undefined;

export type TonApiAction = {
  type?: string;
  status?: string;
  TonTransfer?: {
    sender?: Party;
    recipient?: Party;
    amount?: number | string;
    comment?: string;
    refund?: unknown;
  };
  NftItemTransfer?: {
    sender?: Party;
    recipient?: Party;
    nft?: string;
    refund?: unknown;
  };
  JettonTransfer?: {
    sender?: Party;
    recipient?: Party;
    amount?: number | string;
    comment?: string;
    jetton?: { address?: string };
    refund?: unknown;
  };
};

export type TonApiEvent = {
  event_id?: string;
  timestamp?: number; // unix seconds
  in_progress?: boolean;
  actions?: TonApiAction[];
};

export type PaymentMatch = { units: bigint; txHash: string };

function toUnits(value: number | string | undefined): bigint {
  try {
    return BigInt(String(value ?? 0));
  } catch {
    return 0n;
  }
}

/**
 * Finds a settled incoming payment to `admin` whose comment equals `comment`,
 * for the given asset, worth at least `minUnits` (TON: nanoTON, USDT: micro-USDT).
 */
export function findMatchingPayment(
  events: TonApiEvent[],
  opts: {
    token: "ton" | "usdt";
    comment: string;
    admin: string; // normalized raw address
    jettonMaster?: string; // normalized raw address (usdt)
    minUnits: bigint;
  },
): PaymentMatch | null {
  const wanted = opts.comment.trim();
  for (const event of events) {
    if (event.in_progress) continue;
    for (const action of event.actions ?? []) {
      if (action.status !== "ok") continue;
      if (opts.token === "ton" && action.type === "TonTransfer" && action.TonTransfer) {
        const t = action.TonTransfer;
        if (t.refund) continue;
        if ((t.comment ?? "").trim() !== wanted) continue;
        if (normalizeTonAddress(t.recipient?.address) !== opts.admin) continue;
        const units = toUnits(t.amount);
        if (units < opts.minUnits) continue;
        return { units, txHash: event.event_id ?? "" };
      }
      if (opts.token === "usdt" && action.type === "JettonTransfer" && action.JettonTransfer) {
        const t = action.JettonTransfer;
        if (t.refund) continue;
        if ((t.comment ?? "").trim() !== wanted) continue;
        if (normalizeTonAddress(t.jetton?.address) !== opts.jettonMaster) continue;
        if (normalizeTonAddress(t.recipient?.address) !== opts.admin) continue;
        const units = toUnits(t.amount);
        if (units < opts.minUnits) continue;
        return { units, txHash: event.event_id ?? "" };
      }
    }
  }
  return null;
}

/**
 * Finds a settled transfer of one specific NFT to `admin`, made after `sinceMs`.
 * The NFT address itself identifies the hold; `sender` is checked only when the API provides it.
 */
export function findMatchingNftTransfer(
  events: TonApiEvent[],
  opts: { nft: string; admin: string; sender?: string | null; sinceMs: number },
): { txHash: string } | null {
  for (const event of events) {
    if (event.in_progress) continue;
    if (event.timestamp && event.timestamp * 1000 < opts.sinceMs) continue;
    for (const action of event.actions ?? []) {
      if (action.status !== "ok" || action.type !== "NftItemTransfer" || !action.NftItemTransfer) continue;
      const t = action.NftItemTransfer;
      if (t.refund) continue;
      if (normalizeTonAddress(t.nft) !== opts.nft) continue;
      if (normalizeTonAddress(t.recipient?.address) !== opts.admin) continue;
      const from = normalizeTonAddress(t.sender?.address);
      if (from && opts.sender && from !== opts.sender) continue;
      return { txHash: event.event_id ?? "" };
    }
  }
  return null;
  }
