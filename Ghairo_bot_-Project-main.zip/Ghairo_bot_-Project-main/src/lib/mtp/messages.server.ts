import { toFriendlyAddress } from "./ids";

/** Telegram HTML needs these three characters escaped. */
export const esc = (s: string | number | undefined | null): string =>
  String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const LINE = "━━━━━━━━━━━━━━━━━━";
const n = (v: number, max = 4) =>
  (Math.round(v * 10 ** max) / 10 ** max).toLocaleString("en-US", { maximumFractionDigits: max });
const when = (t: number) =>
  new Date(t).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

const asset = (w: { method?: string }) => (w.method === "usdt" ? "USDT" : "Gram");
const amt = (w: { payout?: number; gram?: number }) => w.payout ?? w.gram ?? 0;

type W = {
  id: string;
  amount: number;
  gram?: number;
  method?: "gram" | "usdt";
  payout?: number;
  usd?: number;
  address: string;
  txHash?: string;
  createdAt: number;
};

// --------------------------- Withdrawals ---------------------------------

export function withdrawPendingUser(w: W): string {
  const method = asset(w);
  return [
    "💸 <b>Withdrawal request received</b>",
    LINE,
    `🧾 <b>Request</b>  <code>${esc(w.id)}</code>`,
    `🪙 <b>Coins</b>  ${n(w.amount, 2)}`,
    `💵 <b>Worth</b>  $${n(w.usd ?? 0, 2)}`,
    `💎 <b>You get</b>  ${n(amt(w), 6)} ${esc(method)}`,
    `📬 <b>To</b>  <code>${esc(toFriendlyAddress(w.address))}</code>`,
    "🌐 <b>Network</b>  TON",
    `🕒 ${when(w.createdAt)}`,
    LINE,
    "⏳ <b>In review.</b> We will send your payout soon and message you here.",
  ].join("\n");
}

export function withdrawPendingAdmin(w: W, who: { name: string; id: string | number }): string {
  const method = asset(w);
  return [
    "🔔 <b>New withdrawal to pay</b>",
    LINE,
    `👤 ${esc(who.name)}  (<code>${esc(who.id)}</code>)`,
    `🧾 <code>${esc(w.id)}</code>`,
    `🪙 ${n(w.amount, 2)} coins  →  💵 $${n(w.usd ?? 0, 2)}`,
    `💎 <b>SEND ${n(amt(w), 6)} ${esc(method)}</b>  (TON network)`,
    `📬 <code>${esc(toFriendlyAddress(w.address))}</code>`,
    LINE,
    "Send the payout, then press Approve.",
  ].join("\n");
}

export function withdrawDoneUser(w: W): string {
  const method = asset(w);
  return [
    "✅ <b>Your payout is on its way!</b>",
    LINE,
    `🧾 <code>${esc(w.id)}</code>`,
    `💎 <b>Sent</b>  ${n(amt(w), 6)} ${esc(method)}  (≈ $${n(w.usd ?? 0, 2)})`,
    `📬 <code>${esc(toFriendlyAddress(w.address))}</code>`,
    "🌐 <b>Network</b>  TON",
    ...(w.txHash ? [`🔗 <b>TX</b>  <code>${esc(w.txHash)}</code>`] : []),
    LINE,
    "Thank you for using Ghairo 🙏",
  ].join("\n");
}

export function withdrawRejectedUser(w: W): string {
  return [
    "❌ <b>Withdrawal declined</b>",
    LINE,
    `🧾 <code>${esc(w.id)}</code>`,
    `🪙 ${n(w.amount, 2)} coins are back in your balance.`,
    LINE,
    "Please check your address and try again, or contact support.",
  ].join("\n");
}

// ----------------------------- Deposits ----------------------------------

export function depositWaitingUser(d: { id: string; gram: number; usd: number }, method = "Gram"): string {
  return [
    "⏳ <b>Waiting for your payment</b>",
    LINE,
    `🧾 <code>${esc(d.id)}</code>`,
    `💎 ${n(d.gram, 6)} ${esc(method)}  (≈ $${n(d.usd, 2)})`,
    "🌐 Network: TON only",
    LINE,
    "We are waiting for the network to confirm. You will get a message the moment it arrives.",
  ].join("\n");
}

export function depositDoneUser(d: { id: string; gram: number; usd: number; coins: number }, method = "Gram"): string {
  return [
    "🎉 <b>Deposit received!</b>",
    LINE,
    `🧾 <code>${esc(d.id)}</code>`,
    `💎 <b>Paid</b>  ${n(d.gram, 6)} ${esc(method)}  (≈ $${n(d.usd, 2)})`,
    "🌐 <b>Network</b>  TON",
    `🪙 <b>Added</b>  +${n(d.coins, 2)} coins`,
    LINE,
    "Your balance is updated. Open Ghairo to unlock your next gem 💎",
  ].join("\n");
}

export function depositDoneAdmin(
  d: { id: string; gram: number; usd: number; coins: number; tx?: string },
  who: { name: string; id: string | number },
  method = "Gram",
): string {
  return [
    "💰 <b>New deposit</b>",
    LINE,
    `👤 ${esc(who.name)}  (<code>${esc(who.id)}</code>)`,
    `🧾 <code>${esc(d.id)}</code>`,
    `💎 ${n(d.gram, 6)} ${esc(method)}  (≈ $${n(d.usd, 2)})`,
    `🪙 Credited ${n(d.coins, 2)} coins`,
    ...(d.tx ? [`🔗 <code>${esc(d.tx)}</code>`] : []),
  ].join("\n");
}

// ----------------------- Withdraw unlocked ---------------------------------

export const withdrawUnlockedUser = (name: string) =>
  [
    "🔓 <b>Withdrawals unlocked for you!</b>",
    LINE,
    `Hey ${esc(name)},`,
    "Good news: your account can now withdraw. 🎉",
    "Open the app, go to <b>Withdraw</b>, choose Gram or USDT and request your payout.",
    "🌐 Network: TON",
    LINE,
    "Tap the button below to open the app 👇",
  ].join("\n");
