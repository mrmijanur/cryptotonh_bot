export type WithdrawalStatus = "pending" | "approved" | "rejected";

export type Withdrawal = {
  id: string;
  minerId: string;
  amount: number;
  address: string;
  status: WithdrawalStatus;
  createdAt: number;
  settledAt?: number;
  resolvedBy?: number;
  /** Fee kept by the platform (older rows have none = 0). */
  fee?: number;
  /** Amount the user actually receives = amount - fee (older rows: = amount). */
  net?: number;
  /** What the admin must send, in Gram, locked in when the request is made. */
  gram?: number;
  /** "gram" or "usdt" (older rows: gram). */
  method?: "gram" | "usdt";
  /** Amount to send in the chosen asset (Gram or USDT). */
  payout?: number;
  /** USD value of the payout when requested. */
  usd?: number;
  /** Admin-provided transaction hash, set when the withdrawal is completed. */
  txHash?: string;
};

export type TaskCategory = "official" | "partner";
export type TaskVerification = "join_channel" | "react_latest" | "timer_claim";

export type TaskDef = {
  id: string;
  category: TaskCategory;
  title: string;
  detail: string;
  reward: number;
  link: string;
  verification: TaskVerification;
  channelId?: string;
  createdAt: number;
  updatedAt: number;
  /** Milliseconds before this task can be claimed again. 0 = one-time only. Missing = DEFAULT_TASK_COOLDOWN_MS. */
  cooldownMs?: number;
};

export type AdminRecord = {
  telegramId: number;
  addedBy: number;
  addedAt: number;
};

export type DepositToken = "ton" | "usdt" | "nft";
export type DepositStatus =
  | "pending"
  | "expired"
  | "completed"
  | "refund_requested"
  | "refunded";

export type Deposit = {
  id: string;
  minerId: string;
  /** Token units (TON / USDT). Expected amount while pending, amount received once completed. */
  amount: number;
  /** On-chain event id, empty until the payment is found. */
  txHash: string;
  /** Wallet the payment is made from (used as the refund destination). */
  wallet?: string;
  createdAt: number;
  /** Older manually-reported deposits have no token/status. */
  token?: DepositToken;
  status?: DepositStatus;
  /** Unique memo the payment must carry, e.g. "FLV-DAB12CD34". */
  comment?: string;
  expiresAt?: number;
  /** Ghairo credited per 1 token, locked in when the deposit is created. */
  rate?: number;
  /** Ghairo added to the pool when completed. */
  mtp?: number;
  /** Ghairo taken back from the pool while a refund is requested. */
  deducted?: number;
  submittedAt?: number;
  /** NFT holds only: the NFT that was sent to the admin wallet. */
  nftAddress?: string;
  nftName?: string;
  nftImage?: string;
  paidAt?: number;
  refundRequestedAt?: number;
  refundRejectedAt?: number;
  refundedAt?: number;
  refundTx?: string;
  resolvedBy?: number;
};

/** An NFT in the user's wallet, with the pool credit the admin set for it. */
export type NftItemView = {
  address: string; // raw "0:<hex>"
  name: string;
  image?: string;
  collection?: string; // raw address
  value: number; // Ghairo added to the pool when held (0 = not holdable yet)
};

export type HistoryKind = "referral_bonus" | "squad_commission" | "admin_credit";

export type HistoryEntry = {
  id: string;
  minerId: string;
  kind: HistoryKind;
  amount: number;
  /** Squad deposit this income came from, in Ghairo (0 for the invite bonus). */
  deposit?: number;
  note?: string;
  createdAt: number;
};

export type DepositInfo = {
  enabled: boolean;
  address: string;
  tonRate: number;
  usdtRate: number; // 0 = USDT deposits closed
  minTon: number;
  minUsdt: number;
  maxTon: number; // 0 = no limit
  maxUsdt: number; // 0 = no limit
};

export type PreparedDeposit = {
  id: string;
  validUntil: number;
  messages: { address: string; amount: string; payload: string }[];
};

export type OpenedDeposit = {
  id: string;
  token: "ton" | "usdt";
  address: string;
  amount: number; // in the chosen asset (Gram or USDT)
  memo: string;
  /** USDT jetton master, for the payment link. */
  jetton?: string;
  expiresAt: number;
  usd: number;
  coins: number;
};

export type LivenessStatus = "none" | "pending" | "approved" | "rejected";

/** A KYC video submission, reviewed by an admin in the Verification Bot chat. */
export type LivenessRecord = {
  id: string;
  minerId: string;
  telegramId?: number;
  name: string;
  username?: string;
  /** Telegram file_id of the uploaded video, so an admin can re-open it later. */
  videoFileId?: string;
  durationMs: number;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
  resolvedAt?: number;
  resolvedBy?: number;
};

export type JoinChannel = { url: string; chatId: string; title?: string };
/** What the app shows for each required channel. */
export type JoinChannelView = { url: string; title: string; joined: boolean };

export type AppSettings = {
  _id: "settings";
  welcomeText: string;
  welcomeImage?: string;
  welcomeButton: string;
  /** Channel-join popup, controlled with /channeljoinpopupshow and /noneedchanneljoin. */
  /** Do admins (not only the owner) get deposit messages? Default yes. */
  depositMsgToAdmins?: boolean;
  /** Withdraw notice: when on, users see this message and cannot withdraw. */
  withdrawBlockEnabled?: boolean;
  withdrawBlockText?: string;
  /** Telegram IDs that are NOT blocked while the withdraw notice is on (/withdrawallow). */
  withdrawAllowIds?: number[];
  /** Maintenance page: when on, everyone who opens the app sees it. */
  maintenanceOn?: boolean;
  maintenanceText?: string;
  /** Channels the user must join (one or many). Managed with /channeljoinpopupshow, /channeljoinremove. */
  joinChannels?: JoinChannel[];
  joinEnabled?: boolean;
  joinUrl?: string;
  /** What the bot checks membership against: "@username" or a "-100…" chat id. */
  joinChatId?: string;
  latestPostUrl?: string;
  latestPostAt?: number;
  tasksRefreshedAt?: number;
  /** Bird packages edited from the bot (/setpackage). Missing = defaults from config. */
  packages?: { price: number; percent: number }[];
  /** USD value of 1 coin when withdrawing. */
  coinUsd?: number;
  /** Withdraw rules, editable by the owner from the bot. */
  minWithdraw?: number;
  maxWithdraw?: number; // 0 / undefined = no limit
  withdrawFee?: number;
  /** Deposits: receiving wallet + Ghairo credited per 1 token (owner sets via bot). */
  depositAddress?: string;
  tonRate?: number;
  usdtRate?: number;
  /** Per-token deposit limits, editable by the owner from the bot (0/undefined max = no limit). */
  minDepositTon?: number;
  maxDepositTon?: number;
  minDepositUsdt?: number;
  maxDepositUsdt?: number;
  /** NFT hold values in Ghairo, keyed by raw NFT or collection address. */
  nftValues?: Record<string, number>;
  nftDefaultValue?: number;
};

export type SquadMember = {
  id: string;
  name: string;
  mining: boolean;
  /** Referral reward for this member is qualified but not yet claimed by the parent. */
  pendingClaim: boolean;
  /** True once this member has started mining at least once (permanent, unlike "mining"). */
  qualified: boolean;
};

export type Miner = {
  id: string;
  telegramId?: number;
  name: string;
  username?: string;
  wallet?: string;
  walletProvider?: string;
  pool: number;
  /** Indexes of owned BIRD_PACKAGES (the free starter bird is implicit). */
  birds?: number[];
  /** Where the user wants withdrawals sent (a TON address). */
  payoutAddress?: string; // Gram (TON) address
  /** USDT (TON network) address. */
  payoutAddressUsdt?: string;
  holding: number;
  unclaimed: number;
  lastAccruedAt: number;
  mining: boolean;
  refCode: string;
  referredBy?: string;
  referralPaid: boolean;
  referralPending?: boolean;
  referralNotified?: boolean;
  /** 10% squad commission credited from this miner's referrals, not yet moved to pool. */
  commissionUnclaimed?: number;
  squadCount: number;
  squadEarned: number;
  /** Task ids ever claimed at least once (history; does not gate repeat claims). */
  completedTasks: string[];
  taskStarts?: Record<string, number>;
  /** Last claim time per task id, used with TaskDef.cooldownMs to gate repeat claims. */
  taskClaims?: Record<string, number>;
  lastDailyAt?: number;
  dailyStreak?: number;
  dailyBest?: number;
  verified: boolean;
  livenessStatus?: LivenessStatus;
  earningsByDay?: Record<string, number>;
  createdAt: number;
  claimedTotal: number;
  withdrawnTotal: number;
};

export type EarningsPoint = { day: string; amount: number };

export type MinerView = {
  miner: Miner;
  unclaimed: number;
  ratePerSecond: number;
  /** Live bird packages (admin can change price and percent from the bot). */
  packages: { price: number; percent: number }[];
  /** USD per 1 Gram right now. */
  gramUsd: number;
  /** USD value of 1 coin when withdrawing. */
  coinUsd: number;
  /** Message shown at the top of the Withdraw tab. Empty = withdrawals are open. */
  withdrawNotice: string;
  /** Set while the owner/admin has turned the maintenance page on. */
  maintenance: { text: string } | null;
  usdPrice: number;
  minWithdraw: number;
  maxWithdraw: number; // 0 = no limit
  withdrawFee: number;
  deposit: DepositInfo;
  nftHolds: number;
  /** Squad commission credited but not yet moved to the withdrawable pool. */
  commissionUnclaimed: number;
  /** Net Ghairo earned today (same value as the last point in earningsSeries). */
  todayEarnings: number;
  /** Face-verified OR currently holding an NFT (shown as the Verified badge). */
  verifiedBadge: boolean;
  /** True when the next withdrawal is blocked until the account is verified. */
  verifyRequired: boolean;
  referralHistory: HistoryEntry[];
  squad: SquadMember[];
  withdrawals: Withdrawal[];
  deposits: Deposit[];
  tasks: TaskDef[];
  invitePath: string;
  inviteLink: string;
  channelMember: boolean;
  channelUrl: string;
  /** Every required channel, with whether this user has joined it. Empty = no popup. */
  channels: JoinChannelView[];
  verifyBotLink: string | null;
  dailyReady: boolean;
  earningsSeries: EarningsPoint[];
};

export type BootResult =
  | { access: "telegram_required" }
  | { access: "ok"; view: MinerView };
