import { creditDepositCommission } from "./referral.server";
import { depositDoneAdmin, depositDoneUser, depositWaitingUser } from "./messages.server";
import { randomInt } from "node:crypto";
import {
  DEPOSIT_TON_RATE,
  DEPOSIT_TTL_MS,
  DEPOSIT_USDT_RATE,
  GRAM_USD_FALLBACK,
  MIN_DEPOSIT_TON,
  MIN_DEPOSIT_USDT,
  TOKEN_SYMBOL,
  USDT_JETTON_MASTER,
} from "./config";
import { findMatchingNftTransfer, findMatchingPayment, type TonApiEvent } from "./deposit-match";
import { toFriendlyAddress } from "./ids";
import {
  addDeposit,
  getDeposit,
  getMiner,
  getSettings,
  incMinerPool,
  listAdmins,
  listDeposits,
  listDepositsByStatus,
  patchDeposit,
  transitionDeposit,
} from "./store.server";
import { ownerChatId, sendTelegram } from "./telegram.server";
import {
  commentPayloadBase64,
  friendlyTonAddress,
  jettonTransferPayloadBase64,
  nftTransferPayloadBase64,
  normalizeTonAddress,
  parseTonAddress,
} from "./ton-boc";
import type {
  AppSettings,
  Deposit,
  DepositInfo,
  DepositStatus,
  DepositToken,
  NftItemView,
  OpenedDeposit,
  PreparedDeposit,
} from "./types";

type CoinToken = "ton" | "usdt";
const DECIMALS: Record<DepositToken, number> = { ton: 9, usdt: 6, nft: 0 };
const LABEL: Record<DepositToken, string> = { ton: "Gram", usdt: "USDT", nft: "NFT" };

/** "1 TON", "2 USDT" or `NFT "name"` for messages. */
function describe(dep: Deposit): string {
  if (dep.token === "nft") return `NFT "${dep.nftName || "NFT"}"`;
  return `${fmt(dep.amount)} ${LABEL[dep.token ?? "ton"]}`;
}
const JETTON_GAS_NANO = 50_000_000n; // 0.05 TON attached to a jetton transfer (excess is returned)
const TON_FEE_RESERVE_NANO = 20_000_000n; // 0.02 TON kept back for the network fee
const MAX_OPEN_DEPOSITS = 3;

/** A problem the user can fix (not enough balance, closed, ...). Shown as-is in the app. */
class DepositUserError extends Error {}

export function fmt(n: number): string {
  return String(Math.round(n * 1e6) / 1e6);
}

// ---------------------------------------------------------------------------
// TonAPI
// ---------------------------------------------------------------------------

class TonApiError extends Error {
  status: number;
  constructor(status: number) {
    super(`TonAPI ${status}`);
    this.status = status;
  }
}

async function tonapi<T>(path: string): Promise<T> {
  const base = (process.env.TONAPI_URL || "https://tonapi.io").replace(/\/$/, "");
  const headers: Record<string, string> = { accept: "application/json" };
  const key = process.env.TONAPI_KEY;
  if (key) headers.authorization = `Bearer ${key}`;
  const res = await fetch(`${base}${path}`, { headers, signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new TonApiError(res.status);
  return (await res.json()) as T;
}

function acct(addr: { wc: number; hash: Uint8Array }): string {
  return friendlyTonAddress(addr, false);
}

async function tonBalance(addr: { wc: number; hash: Uint8Array }): Promise<bigint> {
  try {
    const info = await tonapi<{ balance?: number | string }>(`/v2/accounts/${acct(addr)}`);
    return BigInt(String(info.balance ?? 0));
  } catch (err) {
    if (err instanceof TonApiError && err.status === 404) return 0n; // never-used wallet
    throw err;
  }
}

async function usdtWallet(
  owner: { wc: number; hash: Uint8Array },
): Promise<{ balance: bigint; wallet: string } | null> {
  try {
    const info = await tonapi<{ balance?: string; wallet_address?: { address?: string } }>(
      `/v2/accounts/${acct(owner)}/jettons/${USDT_JETTON_MASTER}`,
    );
    const wallet = info.wallet_address?.address;
    if (!wallet) return null;
    return { balance: BigInt(String(info.balance ?? 0)), wallet };
  } catch (err) {
    if (err instanceof TonApiError && err.status === 404) return null; // owns no USDT
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Settings / notifications
// ---------------------------------------------------------------------------

export async function getDepositInfo(): Promise<DepositInfo> {
  const s = await getSettings();
  const address = s.depositAddress ? toFriendlyAddress(s.depositAddress) : "";
  const tonRate = s.tonRate ?? DEPOSIT_TON_RATE;
  const usdtRate = s.usdtRate ?? DEPOSIT_USDT_RATE;
  return {
    enabled: Boolean(address) && (tonRate > 0 || usdtRate > 0),
    address,
    tonRate,
    usdtRate,
    minTon: s.minDepositTon ?? MIN_DEPOSIT_TON,
    minUsdt: s.minDepositUsdt ?? MIN_DEPOSIT_USDT,
    maxTon: s.maxDepositTon ?? 0,
    maxUsdt: s.maxDepositUsdt ?? 0,
  };
}

/** Live USD price of 1 Gram (the TON coin), cached for a minute. */
let gramPriceCache: { usd: number; at: number } | null = null;
export async function getGramUsd(): Promise<number> {
  if (gramPriceCache && Date.now() - gramPriceCache.at < 60_000) return gramPriceCache.usd;
  try {
    const data = await tonapi<{ rates?: Record<string, { prices?: { USD?: number } }> }>(
      "/v2/rates?tokens=ton&currencies=usd",
    );
    const usd = data.rates?.TON?.prices?.USD;
    if (usd && usd > 0) {
      gramPriceCache = { usd, at: Date.now() };
      return usd;
    }
  } catch (err) {
    console.error("[ghairo] gram price fetch failed:", err instanceof Error ? err.message : err);
  }
  return gramPriceCache?.usd ?? GRAM_USD_FALLBACK;
}

/**
 * Opens a deposit the user pays by hand: send Gram or USDT (TON network) to the admin address
 * with the memo. No wallet connection is needed; the payment is matched on-chain by the memo.
 */
export async function openDeposit(minerId: string, token: "ton" | "usdt", amount: number): Promise<OpenedDeposit> {
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  const settings = await getSettings();
  const admin = settings.depositAddress ? parseTonAddress(settings.depositAddress) : null;
  if (!admin) throw new Error("Deposits are not open yet.");
  const rate = token === "ton" ? (settings.tonRate ?? DEPOSIT_TON_RATE) : (settings.usdtRate ?? DEPOSIT_USDT_RATE);
  if (!(rate > 0)) throw new Error("Deposits are not open yet.");
  const name = LABEL[token];
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount.");
  const min = token === "ton" ? (settings.minDepositTon ?? MIN_DEPOSIT_TON) : (settings.minDepositUsdt ?? MIN_DEPOSIT_USDT);
  // 1% slack: the Gram price can move between the app screen and this request.
  if (amount < min * 0.99) throw new Error(`Minimum ${fmt(min)}`);
  const max = token === "ton" ? (settings.maxDepositTon ?? 0) : (settings.maxDepositUsdt ?? 0);
  if (max > 0 && amount > max) throw new Error(`Maximum deposit is ${fmt(max)} ${name}.`);

  const now = Date.now();
  const recent = await listDeposits(miner.id);
  const open = recent.filter((d) => d.status === "pending" && (d.expiresAt ?? 0) > now);
  // Reuse a waiting deposit of the same amount instead of piling up new ones.
  const same = open.find((d) => d.token === token && Math.abs(d.amount - amount) < 1e-9);
  const id = same?.id ?? newDepositId();
  const comment = same?.comment ?? `FLV-${id}`;
  if (!same) {
    if (open.length >= MAX_OPEN_DEPOSITS) {
      throw new Error("You already have deposits waiting for payment. Finish or check them first.");
    }
    await addDeposit({
      id,
      minerId: miner.id,
      amount,
      txHash: "",
      createdAt: now,
      token,
      status: "pending",
      comment,
      expiresAt: now + DEPOSIT_TTL_MS,
      rate,
    });
  }
  const unitUsd = token === "ton" ? await getGramUsd() : 1;
  return {
    id,
    token,
    address: friendlyTonAddress(admin, false),
    amount,
    memo: comment,
    jetton: token === "usdt" ? USDT_JETTON_MASTER : undefined,
    expiresAt: same?.expiresAt ?? now + DEPOSIT_TTL_MS,
    usd: Math.round(amount * unitUsd * 100) / 100,
    coins: Math.round(amount * rate * 1e6) / 1e6,
  };
}

async function notifyAdmins(body: Record<string, unknown>): Promise<void> {
  const ids = new Set<number>();
  const owner = ownerChatId();
  if (owner) ids.add(owner);
  // The owner can turn off deposit messages for admins with /admindepositmsgoff.
  if ((await getSettings()).depositMsgToAdmins !== false) {
    for (const admin of await listAdmins()) ids.add(admin.telegramId);
  }
  await Promise.all(
    [...ids].map((chatId) => sendTelegram("sendMessage", { chat_id: chatId, ...body })),
  );
}

function newDepositId(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "D";
  for (let i = 0; i < 8; i += 1) out += alphabet[randomInt(alphabet.length)];
  return out;
}

// ---------------------------------------------------------------------------
// Create a deposit (server builds the exact wallet request)
// ---------------------------------------------------------------------------

export async function prepareDeposit(
  minerId: string,
  token: CoinToken,
  amount: number,
  opts: { skipMinimum?: boolean } = {},
): Promise<PreparedDeposit> {
  const label = LABEL[token];
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  if (!miner.wallet) throw new Error("Connect a TON wallet first.");

  const settings = await getSettings();
  const admin = settings.depositAddress ? parseTonAddress(settings.depositAddress) : null;
  if (!admin) throw new Error("Deposits are not open yet.");
  const rate = token === "ton" ? (settings.tonRate ?? DEPOSIT_TON_RATE) : (settings.usdtRate ?? 0);
  if (!(rate > 0)) throw new Error(`${label} deposits are not open yet.`);

  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount.");
  const min = token === "ton" ? (settings.minDepositTon ?? MIN_DEPOSIT_TON) : (settings.minDepositUsdt ?? MIN_DEPOSIT_USDT);
  if (!opts.skipMinimum && amount < min) {
    throw new Error(`Minimum deposit is ${fmt(min)} ${label}.`);
  }
  const max = token === "ton" ? (settings.maxDepositTon ?? 0) : (settings.maxDepositUsdt ?? 0);
  if (max > 0 && amount > max) {
    throw new Error(`Maximum deposit is ${fmt(max)} ${label}.`);
  }
  const units = BigInt(Math.round(amount * 10 ** DECIMALS[token]));
  const user = parseTonAddress(miner.wallet);
  if (!user) throw new Error("Your wallet address is not valid. Reconnect your wallet.");

  const now = Date.now();
  const recent = await listDeposits(miner.id);
  const open = recent.filter((d) => d.status === "pending" && (d.expiresAt ?? 0) > now);
  if (open.length >= MAX_OPEN_DEPOSITS) {
    throw new Error("You already have deposits waiting for payment. Finish or check them first.");
  }

  // Balance check happens BEFORE the wallet opens, so the user gets a clear message.
  let jettonWallet: string | null = null;
  try {
    const ton = await tonBalance(user);
    if (token === "ton") {
      if (ton < units + TON_FEE_RESERVE_NANO) {
        throw new DepositUserError(
          `Not enough TON in your wallet. You need ${fmt(amount)} TON plus a small network fee, but your wallet has ${fmt(Number(ton) / 1e9)} TON.`,
        );
      }
    } else {
      const usdt = await usdtWallet(user);
      if (!usdt || usdt.balance < units) {
        throw new DepositUserError(
          `Not enough USDT in your wallet. You need ${fmt(amount)} USDT but your wallet has ${fmt(Number(usdt?.balance ?? 0n) / 1e6)} USDT.`,
        );
      }
      if (ton < JETTON_GAS_NANO + TON_FEE_RESERVE_NANO) {
        throw new DepositUserError(
          "Keep at least 0.07 TON in your wallet to pay the network fee for a USDT transfer.",
        );
      }
      jettonWallet = usdt.wallet;
    }
  } catch (err) {
    if (err instanceof DepositUserError) throw new Error(err.message);
    // TonAPI unreachable: plain TON can still go ahead (the wallet checks funds itself),
    // but a USDT transfer needs the sender's jetton wallet address.
    console.error("[ghairo] deposit balance check failed:", err instanceof Error ? err.message : err);
    if (token === "usdt") {
      throw new Error("Could not reach the TON network right now. Please try again in a minute.");
    }
  }

  const id = newDepositId();
  const comment = `FLV-${id}`;
  const row: Deposit = {
    id,
    minerId: miner.id,
    amount,
    txHash: "",
    wallet: miner.wallet,
    createdAt: now,
    token,
    status: "pending",
    comment,
    expiresAt: now + DEPOSIT_TTL_MS,
    rate,
  };
  await addDeposit(row);

  const messages: PreparedDeposit["messages"] =
    token === "ton"
      ? [
          {
            address: friendlyTonAddress(admin, false),
            amount: units.toString(),
            payload: commentPayloadBase64(comment),
          },
        ]
      : [
          {
            address: friendlyTonAddress(parseTonAddress(jettonWallet!)!, true),
            amount: JETTON_GAS_NANO.toString(),
            payload: jettonTransferPayloadBase64({
              jettonAmount: units,
              destination: admin,
              responseTo: user,
              forwardTon: 1n,
              comment,
            }),
          },
        ];
  return { id, validUntil: Math.floor(now / 1000) + 600, messages };
}

// ---------------------------------------------------------------------------
// Verify payment on-chain and credit the pool
// ---------------------------------------------------------------------------

async function findPayment(dep: Deposit): Promise<{ tokens: number; txHash: string } | null> {
  if (!dep.token || !dep.comment) return null;
  const settings = await getSettings();
  const adminAddr = settings.depositAddress ? parseTonAddress(settings.depositAddress) : null;
  const admin = adminAddr ? normalizeTonAddress(settings.depositAddress) : null;
  if (!adminAddr || !admin) return null;
  const data = await tonapi<{ events?: TonApiEvent[] }>(
    `/v2/accounts/${acct(adminAddr)}/events?limit=100`,
  );
  if (dep.token === "nft") {
    const nft = normalizeTonAddress(dep.nftAddress);
    if (!nft) return null;
    const hit = findMatchingNftTransfer(data.events ?? [], {
      nft,
      admin,
      sender: normalizeTonAddress(dep.wallet),
      sinceMs: dep.createdAt - 120_000,
    });
    return hit ? { tokens: 1, txHash: hit.txHash } : null;
  }
  const decimals = DECIMALS[dep.token];
  const match = findMatchingPayment(data.events ?? [], {
    token: dep.token,
    comment: dep.comment,
    admin,
    jettonMaster: normalizeTonAddress(USDT_JETTON_MASTER) ?? undefined,
    minUnits: BigInt(
      Math.round(
        Math.min(
          dep.amount,
          dep.token === "ton" ? (settings.minDepositTon ?? MIN_DEPOSIT_TON) : (settings.minDepositUsdt ?? MIN_DEPOSIT_USDT),
        ) *
          10 ** decimals,
      ),
    ),
  });
  if (!match) return null;
  return { tokens: Number(match.units) / 10 ** decimals, txHash: match.txHash };
}

async function completeDeposit(
  dep: Deposit,
  paid: { tokens: number; txHash: string },
): Promise<boolean> {
  const rate = dep.rate ?? 0;
  const mtp =
    dep.token === "nft" ? (dep.mtp ?? 0) : Math.round(paid.tokens * rate * 1e6) / 1e6;
  // Atomic status change first: only ONE caller can win, so the pool is credited once.
  const done = await transitionDeposit(dep.id, ["pending", "expired"], {
    status: "completed",
    amount: paid.tokens,
    txHash: paid.txHash,
    paidAt: Date.now(),
    mtp,
  });
  if (!done) return false;
  await incMinerPool(dep.minerId, mtp);
  if (dep.token !== "nft") await creditDepositCommission(dep.minerId, mtp);
  const miner = await getMiner(dep.minerId);
  const unitUsd = dep.token === "usdt" ? 1 : await getGramUsd();
  const view = { id: dep.id, gram: paid.tokens, usd: paid.tokens * unitUsd, coins: mtp };
  if (miner?.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      parse_mode: "HTML",
      text: depositDoneUser(view, LABEL[dep.token ?? "ton"]),
    });
  }
  await notifyAdmins({
    parse_mode: "HTML",
    text: depositDoneAdmin(
      { ...view, tx: paid.txHash || undefined },
      { name: miner?.name ?? dep.minerId, id: miner?.telegramId ?? dep.minerId },
      LABEL[dep.token ?? "ton"],
    ),
  });
  return true;
}

export async function checkDeposit(
  minerId: string,
  id: string,
  sent = false,
): Promise<DepositStatus> {
  const dep = await getDeposit(id);
  if (!dep || dep.minerId !== minerId || !dep.token) throw new Error("Deposit not found.");
  const now = Date.now();

  if (sent && !dep.submittedAt && dep.status === "pending") {
    await patchDeposit(dep.id, { submittedAt: now });
    const miner = await getMiner(minerId);
    if (miner?.telegramId) {
      await sendTelegram("sendMessage", {
        chat_id: miner.telegramId,
        parse_mode: "HTML",
        text: depositWaitingUser(
          { id: dep.id, gram: dep.amount, usd: dep.amount * (dep.token === "usdt" ? 1 : await getGramUsd()) },
          LABEL[dep.token ?? "ton"],
        ),
      });
    }
  }

  // Late payments are still accepted for expired deposits.
  if (dep.status === "pending" || dep.status === "expired") {
    let paid: { tokens: number; txHash: string } | null = null;
    try {
      paid = await findPayment(dep);
    } catch (err) {
      console.error("[ghairo] deposit check failed:", err instanceof Error ? err.message : err);
    }
    if (paid) await completeDeposit(dep, paid);
    else if (dep.status === "pending" && now > (dep.expiresAt ?? 0)) {
      await transitionDeposit(dep.id, ["pending"], { status: "expired" });
    }
  }
  return (await getDeposit(id))?.status ?? dep.status ?? "pending";
}

/** Owner tool: credit a deposit after checking the payment yourself (e.g. TonAPI was down). */
export async function confirmDepositManually(id: string, by: number): Promise<string> {
  const dep = await getDeposit(id);
  if (!dep || !dep.token) return "Deposit not found.";
  if (dep.status !== "pending" && dep.status !== "expired") return `Already ${dep.status}.`;
  const ok = await completeDeposit(dep, { tokens: dep.amount, txHash: `manual:${by}` });
  const credit = dep.token === "nft" ? (dep.mtp ?? 0) : dep.amount * (dep.rate ?? 0);
  return ok
    ? `Deposit ${dep.id} credited: ${describe(dep)} → ${fmt(credit)} ${TOKEN_SYMBOL}.`
    : "Already handled.";
}

// ---------------------------------------------------------------------------
// Refunds
// ---------------------------------------------------------------------------

export async function requestRefund(minerId: string, id: string): Promise<void> {
  const dep = await getDeposit(id);
  if (!dep || dep.minerId !== minerId || !dep.token) throw new Error("Deposit not found.");
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  const deduct = Math.min(dep.mtp ?? 0, Math.max(0, miner.pool));
  const changed = await transitionDeposit(dep.id, ["completed"], {
    status: "refund_requested",
    refundRequestedAt: Date.now(),
    deducted: deduct,
  });
  if (!changed) throw new Error("This deposit cannot be refunded right now.");
  if (deduct > 0) await incMinerPool(minerId, -deduct);

  if (miner.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      text: [
        `Refund ${dep.id} — Requested ⏳`,
        "",
        `${describe(dep)} will be sent back to your wallet after review.`,
        `${fmt(deduct)} ${TOKEN_SYMBOL} was removed from your pool.`,
      ].join("\n"),
    });
  }
  await notifyAdmins({
    text: [
      "Refund request",
      `ID: ${dep.id}`,
      `Miner: ${miner.name} (${miner.telegramId ?? miner.id})`,
      `SEND BACK: ${describe(dep)}`,
      ...(dep.token === "nft" && dep.nftAddress
        ? [`NFT address: ${friendlyTonAddress(parseTonAddress(dep.nftAddress)!, true)}`]
        : []),
      `To: ${toFriendlyAddress(dep.wallet ?? miner.wallet ?? "—")}`,
      `Pool removed: ${fmt(deduct)} ${TOKEN_SYMBOL}`,
    ].join("\n"),
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Refunded + TX hash", callback_data: `f:tx:${dep.id}` },
          { text: "Refunded", callback_data: `f:ok:${dep.id}` },
        ],
        [{ text: "Reject", callback_data: `f:no:${dep.id}` }],
      ],
    },
  });
}

export async function resolveRefund(
  id: string,
  action: "refunded" | "rejected",
  by: number,
  txHash?: string,
): Promise<string> {
  const dep = await getDeposit(id);
  if (!dep || !dep.token) return "Deposit not found.";
  if (dep.status !== "refund_requested") return `Not waiting for a refund (status: ${dep.status}).`;
  const miner = await getMiner(dep.minerId);
  const hash = txHash?.trim().slice(0, 128);

  if (action === "refunded") {
    const done = await transitionDeposit(dep.id, ["refund_requested"], {
      status: "refunded",
      refundedAt: Date.now(),
      resolvedBy: by,
      ...(hash ? { refundTx: hash } : {}),
    });
    if (!done) return "Already handled.";
    if (miner?.telegramId) {
      await sendTelegram("sendMessage", {
        chat_id: miner.telegramId,
        text: [
          `Refund ${dep.id} — Completed ✅`,
          "",
          `Sent back: ${describe(dep)}`,
          `Wallet: ${toFriendlyAddress(dep.wallet ?? miner.wallet ?? "—")}`,
          ...(hash ? [`TX: ${hash}`] : []),
        ].join("\n"),
      });
    }
    return `Refund ${dep.id} marked as sent${hash ? " with TX hash" : ""}.`;
  }

  const done = await transitionDeposit(dep.id, ["refund_requested"], {
    status: "completed",
    refundRejectedAt: Date.now(),
    resolvedBy: by,
  });
  if (!done) return "Already handled.";
  if ((dep.deducted ?? 0) > 0) await incMinerPool(dep.minerId, dep.deducted!);
  if (miner?.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      text: [
        `Refund ${dep.id} — Rejected ❌`,
        "",
        `${fmt(dep.deducted ?? 0)} ${TOKEN_SYMBOL} was returned to your pool.`,
        "Contact the admin from the Mini App if you have questions.",
      ].join("\n"),
    });
  }
  return `Refund ${dep.id} rejected; pool restored.`;
}

export async function listRefundRequests(): Promise<Deposit[]> {
  return listDepositsByStatus(["refund_requested"]);
}

// ---------------------------------------------------------------------------
// NFT hold: the user sends any NFT they choose to the admin wallet; its pool credit
// value is whatever the owner set with /setnftvalue.
// ---------------------------------------------------------------------------

type TonNft = {
  address?: string;
  index?: number;
  collection?: { address?: string; name?: string };
  metadata?: { name?: string; image?: string };
  previews?: { resolution?: string; url?: string }[];
  trust?: string;
};

type RawNft = Omit<NftItemView, "value">;

const nftCache = new Map<string, { at: number; items: RawNft[] }>();
const NFT_CACHE_MS = 60_000; // normal refreshes reuse the list for a minute
const NFT_MIN_REFETCH_MS = 5_000; // even a forced refresh waits at least 5s (API rate limit)

function nftImage(item: TonNft): string | undefined {
  const previews = item.previews ?? [];
  const pick =
    previews.find((p) => p.resolution === "500x500") ?? previews[previews.length - 1] ?? previews[0];
  let url = pick?.url ?? item.metadata?.image;
  if (!url) return undefined;
  if (url.startsWith("ipfs://")) url = `https://ipfs.io/ipfs/${url.slice(7)}`;
  return /^https?:\/\//.test(url) ? url : undefined;
}

async function fetchOwnerNfts(
  ownerRaw: string,
  owner: { wc: number; hash: Uint8Array },
  force: boolean,
): Promise<RawNft[]> {
  const cached = nftCache.get(ownerRaw);
  const age = cached ? Date.now() - cached.at : Infinity;
  if (cached && (age < NFT_MIN_REFETCH_MS || (!force && age < NFT_CACHE_MS))) return cached.items;
  const data = await tonapi<{ nft_items?: TonNft[] }>(
    `/v2/accounts/${acct(owner)}/nfts?limit=100&indirect_ownership=false`,
  );
  const items: RawNft[] = [];
  for (const item of data.nft_items ?? []) {
    const address = normalizeTonAddress(item.address);
    if (!address || item.trust === "blacklist") continue; // hide flagged spam / scam NFTs
    const name =
      item.metadata?.name?.trim() ||
      (item.collection?.name ? `${item.collection.name} #${item.index ?? ""}`.trim() : "NFT");
    items.push({
      address,
      name: name.slice(0, 60),
      image: nftImage(item),
      collection: normalizeTonAddress(item.collection?.address) ?? undefined,
    });
  }
  nftCache.set(ownerRaw, { at: Date.now(), items });
  return items;
}

/** Pool credit for an NFT: its own value, else its collection's, else the default (0 = not holdable). */
export function nftValueFor(settings: AppSettings, nft: string, collection?: string): number {
  const map = settings.nftValues ?? {};
  const own = map[nft];
  if (typeof own === "number" && own > 0) return own;
  if (collection) {
    const col = map[collection];
    if (typeof col === "number" && col > 0) return col;
  }
  const fallback = settings.nftDefaultValue;
  return typeof fallback === "number" && fallback > 0 ? fallback : 0;
}

export async function listNfts(minerId: string, force = false): Promise<NftItemView[]> {
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  if (!miner.wallet) throw new Error("Connect a TON wallet first.");
  const owner = parseTonAddress(miner.wallet);
  const ownerRaw = normalizeTonAddress(miner.wallet);
  if (!owner || !ownerRaw) throw new Error("Your wallet address is not valid. Reconnect your wallet.");
  let items: RawNft[];
  try {
    items = await fetchOwnerNfts(ownerRaw, owner, force);
  } catch (err) {
    console.error("[ghairo] NFT list failed:", err instanceof Error ? err.message : err);
    throw new Error("Could not load your NFTs right now. Tap Refresh in a minute.");
  }
  const settings = await getSettings();
  return items.map((item) => ({ ...item, value: nftValueFor(settings, item.address, item.collection) }));
}

export async function prepareNftHold(minerId: string, nftInput: string): Promise<PreparedDeposit> {
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  if (!miner.wallet) throw new Error("Connect a TON wallet first.");
  const settings = await getSettings();
  const admin = settings.depositAddress ? parseTonAddress(settings.depositAddress) : null;
  if (!admin) throw new Error("NFT holding is not open yet.");
  const user = parseTonAddress(miner.wallet);
  if (!user) throw new Error("Your wallet address is not valid. Reconnect your wallet.");
  const nftRaw = normalizeTonAddress(nftInput);
  const nft = nftRaw ? parseTonAddress(nftRaw) : null;
  if (!nftRaw || !nft) throw new Error("That NFT address is not valid.");

  // The NFT must really be in the user's wallet, and have a pool value.
  const owned = await listNfts(minerId, false);
  const item = owned.find((row) => row.address === nftRaw);
  if (!item) throw new Error("This NFT is not in your wallet. Tap Refresh and try again.");
  if (item.value <= 0) throw new Error("This NFT has no pool value yet.");

  const now = Date.now();
  const recent = await listDeposits(miner.id);
  const open = recent.filter((d) => d.status === "pending" && (d.expiresAt ?? 0) > now);
  if (open.some((d) => d.token === "nft" && d.nftAddress === nftRaw)) {
    throw new Error("This NFT already has a hold waiting for payment. Check it in your deposits.");
  }
  if (open.length >= MAX_OPEN_DEPOSITS) {
    throw new Error("You already have deposits waiting for payment. Finish or check them first.");
  }

  try {
    const ton = await tonBalance(user);
    if (ton < JETTON_GAS_NANO + TON_FEE_RESERVE_NANO) {
      throw new DepositUserError(
        "Keep at least 0.07 TON in your wallet to pay the network fee for sending an NFT.",
      );
    }
  } catch (err) {
    if (err instanceof DepositUserError) throw new Error(err.message);
    console.error("[ghairo] NFT balance check failed:", err instanceof Error ? err.message : err);
  }

  const id = newDepositId();
  const comment = `FLV-${id}`;
  const row: Deposit = {
    id,
    minerId: miner.id,
    amount: 1,
    txHash: "",
    wallet: miner.wallet,
    createdAt: now,
    token: "nft",
    status: "pending",
    comment,
    expiresAt: now + DEPOSIT_TTL_MS,
    mtp: item.value, // pool credit locked in now
    nftAddress: nftRaw,
    nftName: item.name,
    nftImage: item.image,
  };
  await addDeposit(row);
  return {
    id,
    validUntil: Math.floor(now / 1000) + 600,
    messages: [
      {
        address: friendlyTonAddress(nft, true),
        amount: JETTON_GAS_NANO.toString(),
        payload: nftTransferPayloadBase64({
          newOwner: admin,
          responseTo: user,
          forwardTon: 1n,
          comment,
        }),
      },
    ],
  };
}
