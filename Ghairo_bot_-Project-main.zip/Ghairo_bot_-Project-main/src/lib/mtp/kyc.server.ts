import { resolveLiveness } from "./engine.server";
import { shortId } from "./ids";
import { addVerification, getMinerByTelegram, listAdmins, saveMiner } from "./store.server";
import { clearButtons, ownerChatId, sendTelegram, telegramSendVideo } from "./telegram.server";
import type { LivenessRecord } from "./types";

/** Telegram bots can upload files up to 50 MB; stay well under that. */
export const MAX_KYC_VIDEO_BYTES = 20 * 1024 * 1024;
export const KYC_MAX_SECONDS = 8;

function verifyToken(): string | undefined {
  return process.env.VERIFY_BOT_TOKEN;
}

async function verifyRecipients(): Promise<number[]> {
  const ids = new Set<number>();
  const owner = ownerChatId();
  if (owner) ids.add(owner);
  for (const admin of await listAdmins()) ids.add(admin.telegramId);
  return [...ids];
}

/**
 * Called from the /api/kyc-submit route once a recorded selfie video has been uploaded.
 * Sends the video to every admin (via the Verification Bot) with Approve/Reject buttons,
 * and lets the user know their check is pending (via the main bot).
 */
export async function submitKycVideo(opts: {
  telegramId: number;
  name: string;
  username?: string;
  video: Buffer;
  mimeType: string;
  durationMs: number;
  webAppUrl: string;
}): Promise<void> {
  const miner = await getMinerByTelegram(opts.telegramId);
  if (!miner) {
    throw new Error("Open Ghairo once from the app before verifying.");
  }
  if (miner.verified) {
    throw new Error("Your account is already verified.");
  }
  if (miner.livenessStatus === "pending") {
    throw new Error("A verification is already pending review.");
  }
  if (opts.video.byteLength === 0) {
    throw new Error("No video was received. Please try again.");
  }
  if (opts.video.byteLength > MAX_KYC_VIDEO_BYTES) {
    throw new Error("The video is too large. Please try again.");
  }

  const row: LivenessRecord = {
    id: shortId("V"),
    minerId: miner.id,
    telegramId: miner.telegramId,
    name: opts.name,
    username: opts.username,
    durationMs: opts.durationMs,
    status: "pending",
    createdAt: Date.now(),
  };
  miner.livenessStatus = "pending";
  await addVerification(row);
  await saveMiner(miner);

  const caption = [
    "🛡️ New KYC submission",
    "",
    `👤 Name: ${opts.name}`,
    `🔗 Username: ${opts.username ? `@${opts.username}` : "—"}`,
    `🆔 Telegram ID: ${opts.telegramId}`,
    `⏱️ Clip: ${Math.round(opts.durationMs / 1000)}s`,
    "",
    `Reference: ${row.id}`,
  ].join("\n");
  const filename = `kyc-${row.id}.webm`;
  const recipients = await verifyRecipients();
  let sentFileId: string | undefined;
  for (const chatId of recipients) {
    const result = await telegramSendVideo(
      chatId,
      opts.video,
      filename,
      opts.mimeType || "video/webm",
      {
        caption,
        reply_markup: JSON.stringify({
          inline_keyboard: [
            [
              { text: "✅ Approve", callback_data: `v:ok:${row.id}` },
              { text: "❌ Reject", callback_data: `v:no:${row.id}` },
            ],
          ],
        }),
      },
      verifyToken(),
    );
    const video = (result.result as { video?: { file_id?: string } } | undefined)?.video;
    if (video?.file_id) sentFileId = video.file_id;
  }
  if (sentFileId) {
    row.videoFileId = sentFileId;
    await addVerification(row); // harmless duplicate write with the file_id filled in
  }

  await sendTelegram("sendMessage", {
    chat_id: opts.telegramId,
    text: [
      "⏳ KYC Verification Request Received! 🛡️",
      "",
      `Hey 👋 ${opts.name},`,
      "",
      "Your face scan KYC verification request has been successfully submitted and is currently Pending Approval by our admin team.",
      "",
      "Our team is reviewing your verification. You will receive an instant notification here as soon as your account is verified!",
    ].join("\n"),
    reply_markup: {
      inline_keyboard: [[{ text: "Open App", web_app: { url: opts.webAppUrl } }]],
    },
  });
}

/**
 * Called when an admin taps Approve/Reject on a KYC video, from the Verification Bot's
 * own webhook. Resolves the record via resolveLiveness (engine.server) and then removes
 * the buttons from the admin's message so it cannot be actioned twice.
 */
export async function handleKycCallback(opts: {
  action: "approved" | "rejected";
  id: string;
  by: number;
  chatId?: number;
  messageId?: number;
}): Promise<string> {
  const message = await resolveLiveness(opts.id, opts.action, opts.by);
  if (opts.chatId && opts.messageId) {
    await clearButtons(opts.chatId, opts.messageId, verifyToken());
  }
  return message;
}
