import {
  makeRefCode,
  MIN_CLAIM,
  MIN_WITHDRAW,
  BIRD_PACKAGES,
  COIN_USD,
  DEFAULT_WITHDRAW_NOTICE,
  dailyRate,
  type BirdPackage,
  SIGNUP_BONUS,
  TOKEN_USD,
  ratePerSecond,
  TOKEN_SYMBOL,
  WITHDRAW_FEE,
} from "./config";
import { registerInvite } from "./referral.server";
import { getDepositInfo, getGramUsd } from "./deposit.server";
import { withdrawDoneUser, withdrawPendingAdmin, withdrawPendingUser, withdrawRejectedUser } from "./messages.server";
import { friendlyTonAddress, parseTonAddress } from "./ton-boc";
import { dayKey, isTonAddress, shortId, toFriendlyAddress } from "./ids";
import {
  addHistory,
  addVerification,
  addWithdrawal,
  countActiveNftHolds,
  countWithdrawals,
  getMiner,
  getMinerByRef,
  getMinerByTelegram,
  getSettings,
  buyMinerBird,
  incMinerPool,
  incMinerReferral,
  getVerification,
  getWithdrawal,
  listAdmins,
  listDeposits,
  listHistory,
  listSquad,
  listTasks,
  listWithdrawals,
  saveMiner,
  saveSettings,
  saveVerification,
  saveWithdrawal,
  spendMinerPool,
  updateReactLatestLinks,
} from "./store.server";
import {
  botUsername,
  isInJoinChannel,
  ownerChatId,
  sendTelegram,
  telegramCall,
  verifyBotLink,
} from "./telegram.server";
import type {
  AppSettings,
  JoinChannel,
  JoinChannelView,
  BootResult,
  LivenessRecord,
  Miner,
  MinerView,
  SquadMember,
} from "./types";

// Safety net: drop any Mongo `_id` (ObjectId) before data goes to the client.
// ObjectId cannot be serialized by TanStack Start server functions.
function plain<T>(row: T): T {
  if (!row || typeof row !== "object") return row;
  const { _id, ...rest } = row as Record<string, unknown>;
  void _id;
  return rest as T;
}

/** Trim float noise: 430.0000001 -> 430, 12.5 -> 12.5 */
export function fmtAmount(n: number): string {
  return String(Math.round(n * 1e6) / 1e6);
}

/** Current withdraw rules. Owner can change them from the bot (/setminwithdraw etc). */
export async function getWithdrawRules(): Promise<{ min: number; max: number; fee: number }> {
  const s = await getSettings();
  return {
    min: s.minWithdraw ?? MIN_WITHDRAW,
    max: s.maxWithdraw ?? 0,
    fee: s.withdrawFee ?? WITHDRAW_FEE,
  };
}

let packsCache: { list: BirdPackage[]; at: number } = { list: BIRD_PACKAGES, at: 0 };

/** Live packages: defaults, overridden by whatever the admin set from the bot. Cached for 5 seconds. */
export async function getPackages(force = false): Promise<BirdPackage[]> {
  if (!force && Date.now() - packsCache.at < 5000) return packsCache.list;
  const s = await getSettings();
  const list = BIRD_PACKAGES.map((d, i) => {
    const o = s.packages?.[i];
    return o && o.price > 0 && o.percent >= 0 ? { price: o.price, percent: o.percent } : d;
  });
  packsCache = { list, at: Date.now() };
  return list;
}

function accrue(miner: Miner, now = Date.now()): Miner {
  if (!miner.mining) {
    miner.lastAccruedAt = now;
    return miner;
  }
  const days = Math.max(0, now - miner.lastAccruedAt) / 86_400_000;
  miner.unclaimed += days * dailyRate(miner.birds, packsCache.list);
  miner.lastAccruedAt = now;
  return miner;
}

function bumpEarnings(miner: Miner, amount: number) {
  if (amount <= 0) return;
  const key = dayKey();
  miner.earningsByDay = { ...miner.earningsByDay, [key]: (miner.earningsByDay?.[key] ?? 0) + amount };
}

function newMiner(id: string, name: string, extra: Partial<Miner> = {}): Miner {
  const now = Date.now();
  return {
    id,
    name: name.slice(0, 24) || "Miner",
    pool: 0,
    holding: 0,
    unclaimed: 0,
    lastAccruedAt: now,
    mining: false,
    refCode: makeRefCode(),
    referralPaid: false,
    squadCount: 0,
    squadEarned: 0,
    completedTasks: [],
    taskStarts: {},
    verified: false,
    livenessStatus: "none",
    dailyStreak: 0,
    dailyBest: 0,
    earningsByDay: {},
    createdAt: now,
    claimedTotal: 0,
    withdrawnTotal: 0,
    ...extra,
  };
}

function earningsSeries(miner: Miner) {
  const out: { day: string; amount: number }[] = [];
  for (let i = 6; i >= 0; i -= 1) {
    const key = dayKey(Date.now() - i * 86_400_000);
    out.push({ day: key.slice(5), amount: miner.earningsByDay?.[key] ?? 0 });
  }
  return out;
}

export async function notifyStaff(body: Record<string, unknown>): Promise<void> {
  const ids = new Set<number>();
  const owner = ownerChatId();
  if (owner) ids.add(owner);
  for (const admin of await listAdmins()) ids.add(admin.telegramId);
  await Promise.all(
    [...ids].map((chatId) => sendTelegram("sendMessage", { chat_id: chatId, ...body })),
  );
}

export async function loadOrCreateMiner(opts: {
  minerId: string;
  telegramId?: number;
  name?: string;
  username?: string;
  startParam?: string;
}): Promise<Miner> {
  await getPackages();
  let miner: Miner | null = null;
  if (opts.telegramId) miner = await getMinerByTelegram(opts.telegramId);
  if (!miner) miner = await getMiner(opts.minerId);
  if (!miner) {
    miner = newMiner(opts.minerId, opts.name || "Miner", {
      telegramId: opts.telegramId,
      username: opts.username,
      pool: SIGNUP_BONUS,
    });
    const raw = (opts.startParam || "").replace(/^ref_/i, "").trim();
    // New codes start with GHR_. Codes issued before the rename start with FLV_ and keep working.
    const upper = raw.toUpperCase();
    const candidates = /^(GHR|FLV)_/.test(upper) ? [upper] : upper ? [`GHR_${upper}`, `FLV_${upper}`] : [];
    for (const code of candidates) {
      if (code === miner.refCode) continue;
      const parent = await getMinerByRef(code);
      if (parent && parent.id !== miner.id) {
        miner.referredBy = parent.refCode;
        break;
      }
    }
    await saveMiner(miner);
  } else {
    if (opts.telegramId && miner.telegramId !== opts.telegramId) {
      miner.telegramId = opts.telegramId;
    }
    if (opts.name) miner.name = opts.name.slice(0, 24);
    if (opts.username) miner.username = opts.username;
    accrue(miner);
    await saveMiner(miner);
  }
  return miner;
}

/** Moves the referral income (25% of their partners' deposits) into the withdrawable balance. */
export async function claimSquadCommission(minerId: string): Promise<MinerView> {
  const parent = await mustMiner(minerId);
  const amount = parent.commissionUnclaimed ?? 0;
  if (amount <= 0) throw new Error("No referral income to collect yet.");
  // Atomic: move the exact amount we read, so income that arrives meanwhile is kept.
  await incMinerReferral(parent.id, { commissionUnclaimed: -amount });
  await incMinerPool(parent.id, amount);
  const fresh = await mustMiner(minerId);
  bumpEarnings(fresh, amount);
  await saveMiner(fresh);
  return toView(fresh);
}

async function toView(miner: Miner): Promise<MinerView> {
  const packs = await getPackages();
  const gramUsd = await getGramUsd();
  const settingsNow = await getSettings();
  accrue(miner);
  const squad: SquadMember[] = []; // the squad list is not shown anymore, so it is not loaded
  const now = Date.now();
  const [
    withdrawals,
    deposits,
    uname,
    rules,
    depositInfo,
    history,
  ] = await Promise.all([
    listWithdrawals(miner.id),
    listDeposits(miner.id),
    botUsername(),
    getWithdrawRules(),
    getDepositInfo(),
    listHistory(miner.id, ["referral_bonus", "squad_commission"], 50),
  ]);
  const nftHolds = 0; // NFT holds are not part of the app anymore
  // NFT Holders count as verified while they hold, and have no maximum withdrawal.
  const isHolder = nftHolds > 0;
  const verifiedBadge = miner.verified || isHolder;
  // Only relevant when a Verification Bot is configured.
  const verifyRequired =
    Boolean(process.env.VERIFY_BOT_TOKEN) &&
    !verifiedBadge &&
    (await countWithdrawals(miner.id, ["pending", "approved"])) > 0;
  const required = joinList(settingsNow);
  const channels: JoinChannelView[] = await Promise.all(
    required.map(async (ch) => ({
      url: ch.url,
      title: ch.title || ch.url.replace("https://t.me/", "@"),
      joined: miner.telegramId ? await isInJoinChannel(miner.telegramId, ch.chatId) : false,
    })),
  );
  const channelMember = channels.every((c) => c.joined);
  const chUrl = (channels.find((c) => !c.joined) ?? channels[0])?.url ?? "";
  const refShort = miner.refCode.replace(/^(GHR|FLV)_/, "");
  const inviteLink = uname
    ? `https://t.me/${uname}?start=ref_${refShort}`
    : miner.refCode;
  return {
    miner: plain(miner),
    unclaimed: miner.unclaimed,
    ratePerSecond: ratePerSecond(miner.birds, packs),
    packages: packs,
    gramUsd,
    coinUsd: settingsNow.coinUsd ?? COIN_USD,
    maintenance: settingsNow.maintenanceOn ? { text: settingsNow.maintenanceText ?? "" } : null,
    withdrawNotice: settingsNow.withdrawBlockEnabled && !(miner.telegramId && settingsNow.withdrawAllowIds?.includes(miner.telegramId)) ? settingsNow.withdrawBlockText || DEFAULT_WITHDRAW_NOTICE : "",
    usdPrice: TOKEN_USD,
    minWithdraw: rules.min,
    maxWithdraw: isHolder ? 0 : rules.max,
    withdrawFee: rules.fee,
    deposit: depositInfo,
    nftHolds,
    commissionUnclaimed: miner.commissionUnclaimed ?? 0,
    todayEarnings: miner.earningsByDay?.[dayKey()] ?? 0,
    verifiedBadge,
    verifyRequired,
    referralHistory: history.map((row) => plain(row)),
    squad,
    withdrawals: withdrawals.map((row) => plain(row)),
    deposits: deposits.map((row) => plain(row)),
    tasks: [],
    invitePath: `?startapp=ref_${refShort}`,
    inviteLink,
    channelMember,
    channelUrl: chUrl,
    channels,
    verifyBotLink: verifyBotLink(),
    dailyReady: !miner.lastDailyAt || now - miner.lastDailyAt >= 86_400_000,
    earningsSeries: earningsSeries(miner),
  };
}

export async function getView(minerId: string): Promise<MinerView | null> {
  const miner = await getMiner(minerId);
  if (!miner) return null;
  return toView(miner);
}

export async function connectWallet(
  minerId: string,
  provider: string,
  address: string,
): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  if (!isTonAddress(address)) throw new Error("That is not a TON wallet address.");
  miner.wallet = address.trim();
  miner.walletProvider = provider.slice(0, 48);
  await saveMiner(miner);
  return toView(miner);
}

export async function disconnectWallet(minerId: string): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  miner.wallet = undefined;
  miner.walletProvider = undefined;
  await saveMiner(miner);
  return toView(miner);
}

/** Buys the next bird package. Packages must be bought in order, one each. */
export async function buyBird(minerId: string, index: number): Promise<MinerView> {
  const pack = (await getPackages(true))[index];
  if (!pack) throw new Error("Unknown package.");
  const miner = await mustMiner(minerId);
  await requireChannelMember(miner);
  const owned = miner.birds ?? [];
  if (owned.includes(index)) throw new Error("You already own this gem.");
  if (index > 0 && !owned.includes(index - 1)) throw new Error("Buy the previous gem first.");
  // Settle what the old birds earned up to now, so the new rate only applies from this moment.
  accrue(miner);
  await saveMiner(miner);
  const ok = await buyMinerBird(minerId, index, pack.price);
  if (!ok) throw new Error("Not enough balance.");
  const fresh = await mustMiner(minerId);
  await registerInvite(fresh); // the invite is counted when a partner buys their first gem
  return toView(await mustMiner(minerId));
}

export async function startMining(minerId: string): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  await requireChannelMember(miner);
  if (!miner.mining) {
    miner.mining = true;
    miner.lastAccruedAt = Date.now();
    await saveMiner(miner);
  }
  await registerInvite(miner);
  return toView(await mustMiner(minerId));
}

export async function claim(minerId: string): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  await requireChannelMember(miner);
  accrue(miner);
  const amount = miner.unclaimed;
  if (amount < MIN_CLAIM) throw new Error(`Minimum ${MIN_CLAIM}`);
  miner.pool += amount;
  miner.claimedTotal += amount;
  miner.unclaimed = 0;
  miner.lastAccruedAt = Date.now();
  bumpEarnings(miner, amount);
  await saveMiner(miner);
  return toView(miner);
}

/** Saves the TON address the user wants withdrawals sent to. */
export async function setPayoutAddress(minerId: string, input: string, method: "gram" | "usdt" = "gram"): Promise<MinerView> {
  const parsed = parseTonAddress(input.trim());
  if (!parsed) throw new Error(`That is not a valid ${method === "usdt" ? "USDT (TON)" : "Gram (TON)"} address.`);
  const miner = await mustMiner(minerId);
  if (method === "usdt") miner.payoutAddressUsdt = friendlyTonAddress(parsed, false);
  else miner.payoutAddress = friendlyTonAddress(parsed, false);
  await saveMiner(miner);
  return toView(miner);
}

export async function withdraw(minerId: string, amount: number, method: "gram" | "usdt" = "gram"): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  const blockSettings = await getSettings();
  if (blockSettings.withdrawBlockEnabled && !(miner.telegramId && blockSettings.withdrawAllowIds?.includes(miner.telegramId))) {
    throw new Error(blockSettings.withdrawBlockText || DEFAULT_WITHDRAW_NOTICE);
  }
  await requireChannelMember(miner);
  accrue(miner);
  const payoutAddress = method === "usdt" ? miner.payoutAddressUsdt : miner.payoutAddress;
  if (!payoutAddress) throw new Error("Set your payout address first.");
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount.");
  const rules = await getWithdrawRules();
  const holder = (await countActiveNftHolds(miner.id)) > 0; // NFT Holders: no maximum, no verification
  if (amount < rules.min) {
    throw new Error(`Minimum withdrawal is ${fmtAmount(rules.min)} ${TOKEN_SYMBOL}.`);
  }
  if (!holder && rules.max > 0 && amount > rules.max) {
    throw new Error(`Maximum withdrawal is ${fmtAmount(rules.max)} ${TOKEN_SYMBOL}.`);
  }
  if (amount <= rules.fee) {
    throw new Error(
      `Amount must be more than the ${fmtAmount(rules.fee)} ${TOKEN_SYMBOL} withdrawal fee.`,
    );
  }
  // The first withdrawal needs no verification. After that the account must be verified
  // (rejected withdrawals do not count). NFT Holders skip this.
  // Only enforced when a Verification Bot is configured.
  const needsVerification = Boolean(process.env.VERIFY_BOT_TOKEN) && !miner.verified && !holder;
  if (
    needsVerification &&
    (await countWithdrawals(miner.id, ["pending", "approved"])) > 0
  ) {
    throw new Error(
      "Verify your account with the Verification Bot before your next withdrawal. Your first withdrawal needed no verification.",
    );
  }
  if (amount > miner.pool + 1e-9) throw new Error("Not enough balance.");
  const fee = rules.fee;
  const net = Math.round((amount - fee) * 1e6) / 1e6;
  const settingsNow = await getSettings();
  const usd = Math.round(net * (settingsNow.coinUsd ?? COIN_USD) * 100) / 100;
  const payout = method === "usdt" ? Math.round(usd * 1e6) / 1e6 : Math.round((usd / (await getGramUsd())) * 1e6) / 1e6;
  const row = {
    id: shortId("W"),
    minerId: miner.id,
    amount,
    fee,
    net,
    address: payoutAddress,
    method,
    payout,
    usd,
    status: "pending" as const,
    createdAt: Date.now(),
  };
  await addWithdrawal(row);
  if (needsVerification && (await countWithdrawals(miner.id, ["pending", "approved"])) > 1) {
    // Two "first" withdrawals arrived at the same moment: cancel this one. The balance is
    // only deducted after this check, so nothing is taken.
    await saveWithdrawal({ ...row, status: "rejected", settledAt: Date.now() });
    throw new Error(
      "Verify your account with the Verification Bot before your next withdrawal.",
    );
  }
  // Atomic: the balance is only taken if it is all still there (no double withdrawal).
  if (!(await spendMinerPool(miner.id, amount))) {
    await saveWithdrawal({ ...row, status: "rejected", settledAt: Date.now() });
    throw new Error("Not enough balance.");
  }
  const after = await mustMiner(miner.id);
  after.withdrawnTotal += amount;
  await saveMiner(after);
  const wallet = toFriendlyAddress(payoutAddress);
  if (miner.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      parse_mode: "HTML",
      text: withdrawPendingUser(row),
    });
  }
  await notifyStaff({
    parse_mode: "HTML",
    text: withdrawPendingAdmin(row, { name: miner.name, id: miner.telegramId ?? miner.id }),
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Approve + TX hash", callback_data: `w:tx:${row.id}` },
          { text: "Approve", callback_data: `w:ok:${row.id}` },
        ],
        [{ text: "Reject", callback_data: `w:no:${row.id}` }],
      ],
    },
  });
  return toView(miner);
}

export async function resolveWithdrawal(
  id: string,
  action: "approved" | "rejected",
  by: number,
  txHash?: string,
): Promise<string> {
  const row = await getWithdrawal(id);
  if (!row) return "Withdrawal not found.";
  if (row.status !== "pending") return `Already ${row.status}.`;
  const miner = await getMiner(row.minerId);
  if (!miner) return "Miner not found.";
  row.status = action;
  row.settledAt = Date.now();
  row.resolvedBy = by;
  const hash = txHash?.trim();
  if (action === "approved" && hash) row.txHash = hash.slice(0, 128);
  if (action === "rejected") {
    accrue(miner);
    miner.pool += row.amount;
    miner.withdrawnTotal = Math.max(0, miner.withdrawnTotal - row.amount);
    await saveMiner(miner);
  }
  await saveWithdrawal(row);
  if (miner.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      parse_mode: "HTML",
      text: action === "approved" ? withdrawDoneUser(row) : withdrawRejectedUser(row),
    });
  }
  return action === "approved"
    ? `Approved ${row.id}${row.txHash ? " with TX hash" : ""}.`
    : `Rejected ${row.id} and refunded.`;
}

export async function resolveLiveness(
  id: string,
  action: "approved" | "rejected",
  by: number,
): Promise<string> {
  const row = await getVerification(id);
  if (!row) return "Verification not found.";
  if (row.status !== "pending") return `Already ${row.status}.`;
  const miner = await getMiner(row.minerId);
  if (!miner) return "Miner not found.";
  row.status = action;
  row.resolvedAt = Date.now();
  row.resolvedBy = by;
  miner.livenessStatus = action;
  miner.verified = action === "approved";
  await saveVerification(row);
  await saveMiner(miner);
  if (miner.telegramId) {
    const webAppUrl = process.env.WEBAPP_URL || "";
    await sendTelegram("sendMessage", {
      chat_id: miner.telegramId,
      text:
        action === "approved"
          ? ["✅ KYC Verified! 🎉", "", `Hey 👋 ${miner.name},`, "", "Your account is now fully verified. Withdrawals no longer need extra review."].join("\n")
          : ["❌ KYC Rejected", "", `Hey ${miner.name}, your verification was rejected. Please try again with better lighting and a clear face view.`].join("\n"),
      ...(webAppUrl ? { reply_markup: { inline_keyboard: [[{ text: "Open App", web_app: { url: webAppUrl } }]] } } : {}),
    });
  }
  return action === "approved" ? `Approved ${row.id}.` : `Rejected ${row.id}.`;
}

export async function checkChannel(minerId: string): Promise<MinerView> {
  const miner = await mustMiner(minerId);
  return toView(miner);
}

export async function refreshLatestPost(url: string): Promise<number> {
  const n = await updateReactLatestLinks(url);
  await saveSettings({ latestPostUrl: url, latestPostAt: Date.now() });
  return n;
}

export async function welcomePayload(webAppUrl: string) {
  const settings = await getSettings();
  return {
    text: settings.welcomeText,
    image: settings.welcomeImage,
    button: settings.welcomeButton || "🚀 Open Ghairo",
    webAppUrl,
  };
}

export async function sendWelcome(chatId: number, webAppUrl: string): Promise<void> {
  const w = await welcomePayload(webAppUrl);
  const tab = (name: string) => ({ url: `${webAppUrl}${webAppUrl.includes("?") ? "&" : "?"}tab=${name}` });
  const markup = {
    inline_keyboard: [
      [{ text: w.button, web_app: { url: webAppUrl } }],
      [
        { text: "💳 Deposit", web_app: tab("deposit") },
        { text: "💸 Withdraw", web_app: tab("withdraw") },
      ],
      [{ text: "👥 Invite friends", web_app: tab("referrals") }],
    ],
  };
  if (w.image) {
    await telegramCall("sendPhoto", {
      chat_id: chatId,
      photo: w.image,
      caption: w.text,
      reply_markup: markup,
    });
    return;
  }
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text: w.text,
    reply_markup: markup,
  });
}

export type AccessOk = Extract<BootResult, { access: "ok" }>;

/** Required channels, ignoring the on/off switch. Older single-channel settings still work. */
export function joinListRaw(s: AppSettings): JoinChannel[] {
  if (s.joinChannels) return s.joinChannels;
  return s.joinUrl && s.joinChatId ? [{ url: s.joinUrl, chatId: s.joinChatId }] : [];
}

/** Channels the user must join right now (empty when the popup is off). */
export function joinList(s: AppSettings): JoinChannel[] {
  return s.joinEnabled ? joinListRaw(s) : [];
}

async function missingChannels(telegramId: number | undefined, list: JoinChannel[]): Promise<number> {
  if (!telegramId) return list.length;
  const results = await Promise.all(list.map((ch) => isInJoinChannel(telegramId, ch.chatId)));
  return results.filter((ok) => !ok).length;
}

/** When the join popup is on, the main actions also refuse non-members (not only the screen). */
async function requireChannelMember(miner: Miner): Promise<void> {
  const list = joinList(await getSettings());
  if (list.length && (await missingChannels(miner.telegramId, list)) > 0) {
    throw new Error("Join all the required channels first.");
  }
}

async function mustMiner(minerId: string): Promise<Miner> {
  await getPackages();
  const miner = await getMiner(minerId);
  if (!miner) throw new Error("Miner not found.");
  accrue(miner);
  return miner
    }
