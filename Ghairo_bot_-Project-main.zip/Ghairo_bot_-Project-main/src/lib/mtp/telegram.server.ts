import { createHmac, timingSafeEqual } from "node:crypto";
import { DEFAULT_WELCOME, DEFAULT_WELCOME_BUTTON } from "./config";

export type TelegramUser = {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
};

type TelegramResult = { ok: boolean; result?: unknown; description?: string };

/** How long a Mini App launch (initData) stays valid. An older one is treated as stolen/replayed. */
const INIT_DATA_MAX_AGE_SECONDS = 24 * 60 * 60;

function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

/**
 * Webhook protection. Set the env var and register the webhook with the same value as
 * `secret_token`; Telegram then sends it in a header on every update. Without the env var
 * (older setups) the check is skipped, so set it as soon as you can.
 */
export function webhookAllowed(request: Request, envName: "WEBHOOK_SECRET" | "VERIFY_WEBHOOK_SECRET"): boolean {
  const expected = process.env[envName];
  if (!expected) return true;
  const got = request.headers.get("x-telegram-bot-api-secret-token") ?? "";
  return safeEqual(got, expected);
}

export function parseInitData(initData: string, tokenOverride?: string): TelegramUser | null {
  if (!initData) return null;
  const params = new URLSearchParams(initData);
  const userRaw = params.get("user");
  if (!userRaw) return null;
  const token =
    tokenOverride || process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
  if (token) {
    const hash = params.get("hash");
    if (!hash) return null;
    const entries: string[] = [];
    params.forEach((value, key) => {
      if (key !== "hash") entries.push(`${key}=${value}`);
    });
    entries.sort();
    const dataCheck = entries.join("\n");
    const secret = createHmac("sha256", "WebAppData").update(token).digest();
    const check = createHmac("sha256", secret).update(dataCheck).digest("hex");
    if (!safeEqual(check, hash)) return null;
    const authDate = Number(params.get("auth_date"));
    if (!Number.isFinite(authDate) || Date.now() / 1000 - authDate > INIT_DATA_MAX_AGE_SECONDS) return null;
  }
  try {
    const user = JSON.parse(userRaw) as TelegramUser;
    if (!user?.id) return null;
    return user;
  } catch {
    return null;
  }
}

export async function telegramCall(
  method: string,
  body: unknown,
  tokenOverride?: string,
): Promise<TelegramResult> {
  const token =
    tokenOverride || process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error(`[ghairo] telegram ${method} skipped: BOT_TOKEN missing`);
    return { ok: false, description: "BOT_TOKEN missing" };
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = (await res.json()) as TelegramResult;
    if (!json.ok) {
      // Never log the token. Telegram's description says why (bad token, invalid button URL, ...).
      console.error(`[ghairo] telegram ${method} failed: ${json.description ?? res.status}`);
    }
    return json;
  } catch (err) {
    const description = (err instanceof Error ? err.message : "telegram fetch failed").replaceAll(
      token,
      "<token>",
    );
    console.error(`[ghairo] telegram ${method} error: ${description}`);
    return { ok: false, description };
  }
}

export async function sendTelegram(
  method: string,
  body: unknown,
  tokenOverride?: string,
): Promise<void> {
  await telegramCall(method, body, tokenOverride);
}

export function ownerChatId(): number | null {
  const raw = process.env.ADMIN_CHAT_ID;
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

export function channelId(): string | null {
  const raw = process.env.CHANNEL_ID?.trim();
  return raw || null;
}

export async function isChannelMember(
  userId: number,
  chatId?: string | null,
): Promise<boolean> {
  const chat = chatId || channelId();
  if (!chat) return true;
  const res = await telegramCall("getChatMember", { chat_id: chat, user_id: userId });
  const result = res.result as { status?: string; is_member?: boolean } | undefined;
  if (!result?.status) return false;
  if (["creator", "administrator", "member"].includes(result.status)) return true;
  if (result.status === "restricted" && result.is_member) return true;
  return false;
}

export type ParsedChannel = { url: string; chat: string | null };

/** Accepts https://t.me/name, t.me/name, @name or name. Private invite links return chat = null. */
export function parseChannelLink(input: string): ParsedChannel | null {
  const raw = input.trim();
  if (!raw) return null;
  const cleaned = raw
    .replace(/^https?:\/\//i, "")
    .replace(/^(www\.)?(t|telegram)\.me\//i, "")
    .replace(/^@/, "")
    .split(/[?#]/)[0]!
    .replace(/\/+$/, "");
  if (!cleaned) return null;
  if (cleaned.startsWith("+") || cleaned.toLowerCase().startsWith("joinchat")) {
    return { url: `https://t.me/${cleaned}`, chat: null };
  }
  const name = cleaned.split("/")[0]!;
  if (!/^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(name)) return null;
  return { url: `https://t.me/${name}`, chat: `@${name}` };
}

/**
 * Is this user in the join-gate channel? When the bot cannot check at all (not an admin there, wrong
 * chat) we let the user through, so a bad setup never locks everyone out of the app.
 */
const memberCache = new Map<string, number>();
const notMemberCache = new Map<string, number>(); // short, so a user who just joined is noticed quickly
export async function isInJoinChannel(userId: number, chat: string): Promise<boolean> {
  const key = `${chat}:${userId}`;
  const hit = memberCache.get(key);
  if (hit && Date.now() - hit < 60_000) return true;
  const missed = notMemberCache.get(key);
  if (missed && Date.now() - missed < 6_000) return false;
  const res = await telegramCall("getChatMember", { chat_id: chat, user_id: userId });
  if (!res.ok) {
    console.error("[ghairo] join check unavailable:", res.description);
    return true;
  }
  const r = res.result as { status?: string; is_member?: boolean } | undefined;
  const ok =
    ["creator", "administrator", "member"].includes(r?.status ?? "") ||
    (r?.status === "restricted" && Boolean(r.is_member));
  if (ok) {
    memberCache.set(key, Date.now());
    notMemberCache.delete(key);
  } else {
    notMemberCache.set(key, Date.now());
  }
  return ok;
}

/** Used by the admin command: is the bot an admin of this chat (so it can read the member list)? */
export async function checkBotIsAdmin(chat: string): Promise<{ ok: boolean; reason?: string; title?: string }> {
  const chatRes = await telegramCall("getChat", { chat_id: chat });
  if (!chatRes.ok) return { ok: false, reason: "Channel not found. Check the link." };
  const title = (chatRes.result as { title?: string } | undefined)?.title;
  const me = await telegramCall("getMe", {});
  const botId = (me.result as { id?: number } | undefined)?.id;
  if (!botId) return { ok: false, reason: "Could not read the bot account.", title };
  const member = await telegramCall("getChatMember", { chat_id: chat, user_id: botId });
  const status = (member.result as { status?: string } | undefined)?.status;
  if (status === "administrator" || status === "creator") return { ok: true, title };
  return { ok: false, reason: "The bot is not an admin of that channel. Add it as an admin first.", title };
}

const g = globalThis as typeof globalThis & {
  __ghairoBotUsername?: string;
  __ghairoChannelUrl?: string;
};

export const DEFAULT_BOT_USERNAME = "Ghairo_bot";

export async function botUsername(tokenOverride?: string): Promise<string | null> {
  // The main bot's username is known (BOT_USERNAME env, default Ghairo_bot), so no network call is needed.
  if (!tokenOverride) return process.env.BOT_USERNAME || DEFAULT_BOT_USERNAME;
  const res = await telegramCall("getMe", {}, tokenOverride);
  return (res.result as { username?: string } | undefined)?.username ?? null;
}

export async function channelUrl(): Promise<string> {
  if (g.__ghairoChannelUrl) return g.__ghairoChannelUrl;
  const id = channelId();
  if (!id) return "";
  if (id.startsWith("@")) {
    g.__ghairoChannelUrl = `https://t.me/${id.slice(1)}`;
    return g.__ghairoChannelUrl;
  }
  const res = await telegramCall("getChat", { chat_id: id });
  const chat = res.result as { username?: string; invite_link?: string } | undefined;
  if (chat?.username) {
    g.__ghairoChannelUrl = `https://t.me/${chat.username}`;
    return g.__ghairoChannelUrl;
  }
  if (chat?.invite_link) {
    g.__ghairoChannelUrl = chat.invite_link;
    return g.__ghairoChannelUrl;
  }
  if (/^-100\d+$/.test(id)) return `https://t.me/c/${id.slice(4)}`;
  return `https://t.me/${id.replace(/^@/, "")}`;
}

export function verifyBotLink(): string | null {
  const raw = process.env.VERIFY_BOT_USERNAME?.trim();
  if (!raw) return null;
  const username = raw.replace(/^@/, "");
  return `https://t.me/${username}/KYC`;
}

/** Removes the inline keyboard from a sent message (e.g. after Approve/Reject is handled). */
export async function clearButtons(
  chatId: number,
  messageId: number,
  tokenOverride?: string,
): Promise<void> {
  await telegramCall(
    "editMessageReplyMarkup",
    { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: [] } },
    tokenOverride,
  );
}

/** Uploads a video file (KYC clips, etc.) to a chat, using multipart/form-data. */
export async function telegramSendVideo(
  chatId: number,
  video: Buffer,
  filename: string,
  mimeType: string,
  extra: Record<string, unknown> = {},
  tokenOverride?: string,
): Promise<TelegramResult> {
  const token = tokenOverride || process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error("[ghairo] telegram sendVideo skipped: bot token missing");
    return { ok: false, description: "bot token missing" };
  }
  try {
    const form = new FormData();
    form.set("chat_id", String(chatId));
    for (const [key, value] of Object.entries(extra)) {
      form.set(key, typeof value === "string" ? value : JSON.stringify(value));
    }
    form.set("video", new Blob([new Uint8Array(video)], { type: mimeType }), filename);
    const res = await fetch(`https://api.telegram.org/bot${token}/sendVideo`, {
      method: "POST",
      body: form,
    });
    const json = (await res.json()) as TelegramResult;
    if (!json.ok) {
      console.error(`[ghairo] telegram sendVideo failed: ${json.description ?? res.status}`);
    }
    return json;
  } catch (err) {
    const description = (err instanceof Error ? err.message : "telegram upload failed").replaceAll(
      token,
      "<token>",
    );
    console.error(`[ghairo] telegram sendVideo error: ${description}`);
    return { ok: false, description };
  }
}

export function defaultWelcome(): { text: string; button: string; image?: string } {
  return { text: DEFAULT_WELCOME, button: DEFAULT_WELCOME_BUTTON };
}

export function postUrlFromChannel(
  chat: { id: number; username?: string },
  messageId: number,
): string {
  if (chat.username) return `https://t.me/${chat.username}/${messageId}`;
  const id = String(chat.id);
  const inner = id.startsWith("-100") ? id.slice(4) : id.replace("-", "");
  return `https://t.me/c/${inner}/${messageId}`;
}

export function matchesChannel(chat: { id: number; username?: string }): boolean {
  const id = channelId();
  if (!id) return false;
  if (id.startsWith("@")) {
    return chat.username?.toLowerCase() === id.slice(1).toLowerCase();
  }
  return String(chat.id) === id;
}

export function requestOrigin(request: Request): string {
  const url = new URL(request.url);
  const host = request.headers.get("x-forwarded-host") || url.host;
  const proto = request.headers.get("x-forwarded-proto") || url.protocol.replace(":", "");
  return `${proto}://${host}`;
}

export function inlineUrlButton(text: string, url: string) {
  return { inline_keyboard: [[{ text, url }]] };
}

export function webAppButton(text: string, url: string) {
  return { inline_keyboard: [[{ text, web_app: { url } }]] };
}
