import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  checkChannel,
  claim,
  claimSquadCommission,
  connectWallet,
  disconnectWallet,
  getView,
  loadOrCreateMiner,
  buyBird,
  setPayoutAddress,
  startMining,
  withdraw,
} from "./engine.server";
import {
  checkDeposit,
  openDeposit,
  prepareDeposit,
  requestRefund,
} from "./deposit.server";
import { getSettings } from "./store.server";
import { botTokenEnabled, newMinerId, readMinerId, writeMinerId } from "./session.server";
import { parseInitData } from "./telegram.server";
import type {
  BootResult,
  DepositStatus,
  MinerView,
  OpenedDeposit,
  NftItemView,
  PreparedDeposit,
} from "./types";

const bootSchema = z.object({
  initData: z.string().optional(),
  startParam: z.string().optional(),
  name: z.string().optional(),
});

/** Like requireId, but refuses while the maintenance page is on (balances stay safe and untouched). */
async function requireOpenId(): Promise<string> {
  if ((await getSettings()).maintenanceOn) {
    throw new Error("Ghairo is under maintenance. Please try again soon.");
  }
  return requireId();
}

async function requireId(): Promise<string> {
  const id = readMinerId();
  if (!id) throw new Error("Session missing. Reload the Mini App.");
  return id;
}

async function currentView(): Promise<MinerView> {
  const view = await getView(await requireId());
  if (!view) throw new Error("Miner not found.");
  return view;
}

function parseUser(initData: string | undefined, token?: string) {
  if (!initData) return null;
  return parseInitData(initData, token);
}

export const bootstrapMiner = createServerFn({ method: "POST" })
  .validator(bootSchema)
  .handler(async ({ data }): Promise<BootResult> => {
    const token = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
    const tg = parseUser(data.initData, token || undefined);
    if (token && !tg) return { access: "telegram_required" };
    const existing = readMinerId();
    const minerId = tg ? newMinerId(tg.id) : existing || newMinerId();
    writeMinerId(minerId);
    const name =
      tg?.first_name || data.name || (tg?.username ? `@${tg.username}` : "Miner");
    await loadOrCreateMiner({
      minerId,
      telegramId: tg?.id,
      name,
      username: tg?.username,
      startParam: data.startParam,
    });
    const view = await getView(minerId);
    if (!view) throw new Error("Could not open miner.");
    return { access: "ok", view };
  });

export const bootstrapVerify = createServerFn({ method: "POST" })
  .validator(bootSchema)
  .handler(async ({ data }): Promise<BootResult> => {
    const verifyToken = process.env.VERIFY_BOT_TOKEN;
    const mainToken = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
    const tg =
      parseUser(data.initData, verifyToken) || parseUser(data.initData, mainToken);
    if ((verifyToken || mainToken) && !tg) return { access: "telegram_required" };
    const existing = readMinerId();
    const minerId = tg ? newMinerId(tg.id) : existing || newMinerId();
    writeMinerId(minerId);
    await loadOrCreateMiner({
      minerId,
      telegramId: tg?.id,
      name: tg?.first_name || data.name || "Miner",
      username: tg?.username,
      startParam: data.startParam,
    });
    const view = await getView(minerId);
    if (!view) throw new Error("Could not open miner.");
    return { access: "ok", view };
  });

export const getMinerState = createServerFn({ method: "GET" }).handler(
  async (): Promise<BootResult> => {
    if (botTokenEnabled() && !readMinerId()) return { access: "telegram_required" };
    try {
      return { access: "ok", view: await currentView() };
    } catch {
      if (botTokenEnabled()) return { access: "telegram_required" };
      throw new Error("Session missing. Reload the Mini App.");
    }
  },
);

export const connectWalletFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      provider: z.string().min(1).max(48),
      address: z.string().min(8).max(128),
    }),
  )
  .handler(async ({ data }): Promise<MinerView> => {
    return connectWallet(await requireId(), data.provider, data.address);
  });

export const disconnectWalletFn = createServerFn({ method: "POST" }).handler(
  async (): Promise<MinerView> => disconnectWallet(await requireId()),
);

export const startMiningFn = createServerFn({ method: "POST" }).handler(
  async (): Promise<MinerView> => startMining(await requireOpenId()),
);

export const buyBirdFn = createServerFn({ method: "POST" })
  .validator(z.object({ index: z.number().int().min(0).max(50) }))
  .handler(async ({ data }): Promise<MinerView> => buyBird(await requireOpenId(), data.index));

export const claimFn = createServerFn({ method: "POST" }).handler(
  async (): Promise<MinerView> => claim(await requireOpenId()),
);

export const withdrawFn = createServerFn({ method: "POST" })
  .validator(z.object({ amount: z.number().positive(), method: z.enum(["gram", "usdt"]).default("gram") }))
  .handler(async ({ data }): Promise<MinerView> => withdraw(await requireOpenId(), data.amount, data.method));

export const setPayoutAddressFn = createServerFn({ method: "POST" })
  .validator(z.object({ address: z.string().min(8).max(128), method: z.enum(["gram", "usdt"]).default("gram") }))
  .handler(async ({ data }): Promise<MinerView> => setPayoutAddress(await requireOpenId(), data.address, data.method));

export const openDepositFn = createServerFn({ method: "POST" })
  .validator(z.object({ token: z.enum(["ton", "usdt"]), amount: z.number().positive().max(1_000_000) }))
  .handler(async ({ data }): Promise<OpenedDeposit> => openDeposit(await requireOpenId(), data.token, data.amount));

export const prepareDepositFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.enum(["ton", "usdt"]),
      amount: z.number().positive().max(1_000_000),
    }),
  )
  .handler(
    async ({ data }): Promise<PreparedDeposit> =>
      prepareDeposit(await requireId(), data.token, data.amount),
  );

export const checkDepositFn = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(3).max(40), sent: z.boolean().optional() }))
  .handler(async ({ data }): Promise<{ status: DepositStatus; view: MinerView }> => {
    const minerId = await requireId();
    const status = await checkDeposit(minerId, data.id, data.sent ?? false);
    const view = await getView(minerId);
    if (!view) throw new Error("Miner not found.");
    return { status, view };
  });

export const requestRefundFn = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(3).max(40) }))
  .handler(async ({ data }): Promise<MinerView> => {
    await requestRefund(await requireId(), data.id);
    return currentView();
  });

export const claimSquadCommissionFn = createServerFn({ method: "POST" }).handler(
  async (): Promise<MinerView> => claimSquadCommission(await requireId()),
);

export const checkChannelFn = createServerFn({ method: "POST" }).handler(
  async (): Promise<MinerView> => checkChannel(await requireId()),
);
