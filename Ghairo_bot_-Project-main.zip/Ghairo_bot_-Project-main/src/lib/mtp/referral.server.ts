import { REFERRAL_DEPOSIT_PERCENT, TOKEN_SYMBOL } from "./config";
import { shortId } from "./ids";
import { addHistory, getMiner, getMinerByRef, incMinerReferral, saveMiner } from "./store.server";
import { sendTelegram } from "./telegram.server";
import type { Miner } from "./types";

const round6 = (n: number) => Math.round(n * 1e6) / 1e6;

async function parentOf(miner: Miner): Promise<Miner | null> {
  if (!miner.referredBy) return null;
  const parent = await getMinerByRef(miner.referredBy);
  return parent && parent.id !== miner.id ? parent : null;
}

/** Counts the invited partner once, when they first start mining. No coin bonus is paid for an invite. */
export async function registerInvite(child: Miner): Promise<void> {
  if (child.referralPaid || !child.referredBy) return;
  const parent = await parentOf(child);
  if (!parent) return;
  child.referralPaid = true;
  child.referralNotified = true;
  await saveMiner(child);
  await incMinerReferral(parent.id, { squadCount: 1 });
  if (parent.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: parent.telegramId,
      text: `✅ ${child.name} joined with your link.\nYou earn ${REFERRAL_DEPOSIT_PERCENT * 100}% of every top-up they make.`,
    });
  }
}

/** The inviter gets REFERRAL_DEPOSIT_PERCENT of every completed deposit of the invited partner. */
export async function creditDepositCommission(minerId: string, depositMtp: number): Promise<void> {
  if (!(depositMtp > 0)) return;
  const child = await getMiner(minerId);
  if (!child) return;
  const parent = await parentOf(child);
  if (!parent) return;
  const cut = round6(depositMtp * REFERRAL_DEPOSIT_PERCENT);
  await incMinerReferral(parent.id, { commissionUnclaimed: cut, squadEarned: cut });
  await addHistory({
    id: shortId("H"),
    minerId: parent.id,
    kind: "squad_commission",
    amount: cut,
    deposit: round6(depositMtp),
    note: child.name,
    createdAt: Date.now(),
  });
  if (parent.telegramId) {
    await sendTelegram("sendMessage", {
      chat_id: parent.telegramId,
      text: `💰 ${child.name} topped up.\n+${cut} ${TOKEN_SYMBOL} added to your referral income.`,
    });
  }
}
