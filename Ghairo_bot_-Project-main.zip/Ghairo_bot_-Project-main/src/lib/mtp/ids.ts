const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function shortId(prefix: string, len = 6): string {
  let out = "";
  for (let i = 0; i < len; i += 1) {
    out += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  }
  return `${prefix}${out}`;
}

export function dayKey(at = Date.now()): string {
  return new Date(at).toISOString().slice(0, 10);
}

export function isTonAddress(value: string): boolean {
  const v = value.trim();
  if (/^[EU]Q[A-Za-z0-9_-]{46}$/.test(v)) return true;
  if (/^-?\d+:[a-fA-F0-9]{64}$/.test(v)) return true;
  return false;
}

function crc16(data: Uint8Array): number {
  let crc = 0;
  for (const byte of data) {
    crc ^= byte << 8;
    for (let i = 0; i < 8; i += 1) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc;
}

/** Raw "0:<64 hex>" -> friendly non-bounceable "UQ...". Anything else is returned unchanged. */
export function toFriendlyAddress(raw: string): string {
  const m = /^(-?\d+):([0-9a-fA-F]{64})$/.exec(raw.trim());
  if (!m) return raw;
  const workchain = Number(m[1]);
  if (workchain !== 0 && workchain !== -1) return raw;
  const bytes = new Uint8Array(36);
  bytes[0] = 0x51;
  bytes[1] = workchain & 0xff;
  for (let i = 0; i < 32; i += 1) {
    bytes[2 + i] = parseInt(m[2]!.slice(i * 2, i * 2 + 2), 16);
  }
  const crc = crc16(bytes.subarray(0, 34));
  bytes[34] = crc >> 8;
  bytes[35] = crc & 0xff;
  return Buffer.from(bytes).toString("base64url");
}
