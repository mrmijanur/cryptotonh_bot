import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatMtp(value: number, digits = 4): string {
  if (!Number.isFinite(value)) return "0";
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 10_000) return `${(value / 1_000).toFixed(2)}K`;
  const abs = Math.abs(value);
  const places = abs >= 100 ? 2 : abs >= 1 ? 3 : digits;
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: places,
  });
}

export function formatThs(value: number): string {
  if (value >= 1000) return `${(value / 1000).toFixed(2)} PH/s`;
  if (value >= 1) return `${value.toFixed(2)} TH/s`;
  return `${(value * 1000).toFixed(0)} GH/s`;
}

export function formatUsd(mtp: number, price: number): string {
  const usd = mtp * price;
  if (usd < 0.01) return `$${usd.toFixed(4)}`;
  return `$${usd.toFixed(2)}`;
}

export function shortAddress(addr: string): string {
  if (addr.length < 12) return addr;
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}
