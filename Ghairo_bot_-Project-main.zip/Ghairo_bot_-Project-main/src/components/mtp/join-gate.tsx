import { BadgeCheck, CheckCircle2, Loader2, Megaphone, Send } from "lucide-react";
import { useState } from "react";
import type { JoinChannelView } from "@/lib/mtp/types";
import { openExternal } from "./telegram";

export function JoinGate({
  channels,
  busy,
  onCheck,
}: {
  channels: JoinChannelView[];
  busy: boolean;
  /** Resolves true when the user is now a member of every channel. */
  onCheck: () => Promise<boolean>;
}) {
  const [checking, setChecking] = useState(false);
  const [missed, setMissed] = useState(0); // bumps on every failed check, to replay the shake
  const [opened, setOpened] = useState<Record<string, boolean>>({});

  const joined = channels.filter((c) => c.joined).length;
  const left = channels.length - joined;

  async function verify() {
    setChecking(true);
    try {
      if (!(await onCheck())) setMissed((n) => n + 1);
    } finally {
      setChecking(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#03040a]/80 p-4 backdrop-blur-sm">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="join-title"
        className="gate-pop paper-card relative flex max-h-[92svh] w-full max-w-[380px] flex-col rounded-2xl px-5 pb-5 pt-14 text-center"
      >
        <div className="gate-float absolute -top-9 left-1/2 -translate-x-1/2">
          <div className="gate-ring flex size-[76px] items-center justify-center rounded-full bg-gradient-to-b from-[#f1d9a0] via-[#d8b46a] to-[#a07f3a] shadow-[0_10px_30px_rgba(216,180,106,0.35)]">
            <div className="flex size-[62px] items-center justify-center rounded-full bg-[#0d1018]">
              <Megaphone className="size-8 text-[#f1d9a0]" strokeWidth={2.2} />
            </div>
          </div>
        </div>

        <p className="text-[11px] font-black uppercase tracking-[0.28em] text-gold">One quick step</p>
        <h2 id="join-title" className="mt-1 font-display text-[24px] font-black leading-tight text-ink">
          {channels.length > 1 ? "Join our channels" : "Join our channel"}
        </h2>
        <p className="mt-2 text-[14px] font-semibold leading-snug text-muted">
          {channels.length > 1
            ? `Join all ${channels.length} channels to unlock the app. It takes a few seconds.`
            : "Join the official Ghairo channel to unlock the app. It takes five seconds."}
        </p>

        {channels.length > 1 ? (
          <div className="mt-3 flex items-center justify-center gap-2">
            <div className="h-2 w-32 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#f1d9a0] to-[#c9a257] transition-all"
                style={{ width: `${(joined / channels.length) * 100}%` }}
              />
            </div>
            <span className="text-[12px] font-extrabold text-ink">
              {joined} of {channels.length} joined
            </span>
          </div>
        ) : null}

        <ul className="mt-4 min-h-0 flex-1 space-y-2 overflow-y-auto text-left">
          {channels.map((ch) => (
            <li key={ch.url} className="slot-cell flex items-center gap-3 rounded-lg px-3 py-2.5">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#0d1018]">
                {ch.joined ? <CheckCircle2 className="size-5 text-[#7dd69a]" /> : <Send className="size-4 text-[#f1d9a0]" />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[14px] font-extrabold text-ink">{ch.title}</span>
                <span className={`block text-[11px] font-bold ${ch.joined ? "text-mint" : "text-muted"}`}>
                  {ch.joined ? "Joined ✓" : "Not joined yet"}
                </span>
              </span>
              {ch.joined ? null : (
                <button
                  type="button"
                  onClick={() => {
                    openExternal(ch.url);
                    setOpened((o) => ({ ...o, [ch.url]: true }));
                  }}
                  className="btn-collect h-9 shrink-0 rounded-lg px-4 font-display text-[13px] font-black uppercase tracking-wide"
                >
                  Join
                </button>
              )}
            </li>
          ))}
        </ul>

        <div className="mt-4">
          <button
            type="button"
            disabled={busy || checking}
            onClick={() => void verify()}
            className="btn-collect gate-shine relative h-12 w-full overflow-hidden rounded-xl font-display text-[15px] font-black uppercase tracking-[0.06em] disabled:opacity-60"
          >
            <span className="relative z-10 inline-flex items-center justify-center gap-2">
              {checking ? <Loader2 className="size-4 animate-spin" /> : <BadgeCheck className="size-[18px]" />}
              {checking ? "Checking…" : channels.length > 1 ? "I joined all, verify" : "I joined, verify"}
            </span>
          </button>
        </div>

        {missed > 0 ? (
          <p key={missed} className="gate-shake mt-3 rounded-lg bg-danger/12 px-3 py-2 text-[13px] font-extrabold text-danger">
            {left > 1 ? `You have not joined ${left} channels yet.` : "You have not joined the channel yet."} Join, then tap verify.
          </p>
        ) : Object.keys(opened).length > 0 ? (
          <p className="mt-3 text-[12px] font-bold text-muted">Come back here after joining and tap verify.</p>
        ) : null}
      </div>
    </div>
  );
}
