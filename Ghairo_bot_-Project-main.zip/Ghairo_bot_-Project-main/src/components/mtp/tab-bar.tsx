import { ArrowDownToLine, ArrowUpFromLine, Gem, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n, type Msg } from "./i18n";

export const TABS = [
  { id: "game", label: "game", Icon: Gem },
  { id: "deposit", label: "deposit", Icon: ArrowDownToLine },
  { id: "withdraw", label: "withdraw", Icon: ArrowUpFromLine },
  { id: "referrals", label: "referrals", Icon: Users },
] as const;

export type TabId = (typeof TABS)[number]["id"];

export function TabBar({
  value,
  onChange,
}: {
  value: TabId;
  onChange: (id: TabId) => void;
}) {
  const { t } = useI18n();
  return (
    <nav
      className="sticky bottom-0 z-30 grid grid-cols-4 border-t border-[#82aaff]/[0.12] bg-[#090e1b]/90 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5 backdrop-blur-xl"
      aria-label="Mini app"
    >
      {TABS.map(({ id, label, Icon }) => {
        const active = id === value;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={cn(
              "relative flex flex-col items-center gap-1 rounded-2xl py-1.5 text-[11px] font-semibold tracking-wide transition-colors duration-200",
              active ? "text-[#7db6ff]" : "text-[#6c7b99] hover:text-[#a9b8d4]",
            )}
          >
            {active ? (
              <span className="absolute -top-1.5 h-[3px] w-8 rounded-full bg-gradient-to-r from-[#4f9cff] to-[#38d6ff]" />
            ) : null}
            <span
              className={cn(
                "flex h-8 w-12 items-center justify-center rounded-full transition-colors duration-200",
                active ? "bg-[#4f9cff]/15" : "bg-transparent",
              )}
            >
              <Icon className="size-[19px]" strokeWidth={active ? 2.3 : 1.9} />
            </span>
            {t(label as Msg)}
          </button>
        );
      })}
    </nav>
  );
}
