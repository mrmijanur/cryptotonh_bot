import { useEffect, useState } from "react";
import { cn, formatMtp } from "@/lib/utils";

export function LiveAmount({
  base,
  rate,
  since,
  active,
  className,
  digits = 4,
}: {
  base: number;
  rate: number;
  since: number;
  active: boolean;
  className?: string;
  digits?: number;
}) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [active]);
  const extra = active ? Math.max(0, (now - since) / 1000) * rate : 0;
  return <span className={cn("tabular-nums", className)}>{formatMtp(base + extra, digits)}</span>;
}
