import { createContext, useContext, useMemo, type ReactNode } from "react";

export type Locale = "en" | "bn";

const STRINGS = {
  en: {
    yourBalance: "Your balance",
    assistant: "Assistant",
    bangladesh: "Bangladesh",
    game: "Mine",
    deposit: "Deposit",
    withdraw: "Withdraw",
    referrals: "Referrals",
    accrued: "Accrued",
    hour: "HOUR",
    day: "DAY",
    month: "MONTH",
    collect: "COLLECT",
    replenishment: "Balance replenishment",
    withdrawFunds: "Withdraw funds",
    minimum: "Minimum:",
    totalIncome: "Total income:",
    referralsLabel: "Referrals:",
    copy: "Copy",
    fromReplenish: "Of every top-up your partners make",
    date: "Date",
    user: "User",
    income: "Income",
    connect: "Connect wallet",
    opening: "Opening miner…",
    joinTitle: "Join the official channel",
    joinBody: "Membership is required before you can mine, claim tasks, or open the rest of the app.",
    joinCta: "Join channel",
    joined: "I joined — continue",
    telegramOnly: "Please open this from Telegram. Ghairo only runs inside the official Mini App.",
    tasks: "Tasks",
    boost: "Boost",
    back: "Back",
    nftHold: "NFT Hold",
    ton: "TON",
    usdt: "USDT",
    checkPayment: "Check payment",
    requestRefund: "Request refund",
    confirmRefund: "Tap again to confirm refund",
    history: "History",
    noWithdrawals: "No withdrawals yet.",
    noDeposits: "No deposits yet.",
    noSquad: "No partners yet. Share your link and earn on every top-up they make.",
    verifyNow: "Verify now",
    requestWithdrawal: "Request withdrawal",
    amount: "Amount",
    connectFirst: "Connect your wallet first.",
    depositsClosed: "Deposits are not open yet.",
    copied: "Copied",
    language: "EN",
    languageBn: "বাংলা",
    more: "More",
    play: "Game",
  },
  bn: {
    yourBalance: "আপনার ব্যালেন্স",
    assistant: "অ্যাসিস্ট্যান্ট",
    bangladesh: "বাংলাদেশ",
    game: "গেম",
    deposit: "ডিপোজিট",
    withdraw: "উইথড্র",
    referrals: "রেফারেল",
    accrued: "অর্জিত",
    hour: "ঘণ্টা",
    day: "দিন",
    month: "মাস",
    collect: "সংগ্রহ",
    replenishment: "ব্যালেন্স রিচার্জ",
    withdrawFunds: "উইথড্র",
    minimum: "সর্বনিম্ন:",
    totalIncome: "মোট আয়:",
    referralsLabel: "রেফারেল:",
    copy: "কপি",
    fromReplenish: "ব্যালেন্স রিপ্লেনিশমেন্ট থেকে",
    date: "তারিখ",
    user: "ইউজার",
    income: "আয়",
    connect: "ওয়ালেট কানেক্ট",
    opening: "মাইনার খোলা হচ্ছে…",
    joinTitle: "অফিসিয়াল চ্যানেলে যোগ দিন",
    joinBody: "মাইনিং, টাস্ক বা অ্যাপ খোলার আগে চ্যানেল মেম্বার হতে হবে।",
    joinCta: "চ্যানেলে যোগ দিন",
    joined: "যোগ দিয়েছি — চালিয়ে যান",
    telegramOnly: "টেলিগ্রাম থেকে ওপেন করুন। Ghairo শুধু অফিসিয়াল মিনি অ্যাপে চলে।",
    tasks: "টাস্ক",
    boost: "বুস্ট",
    back: "ফিরে যান",
    nftHold: "NFT হোল্ড",
    ton: "TON",
    usdt: "USDT",
    checkPayment: "পেমেন্ট চেক",
    requestRefund: "রিফান্ড চান",
    confirmRefund: "কনফার্ম করতে আবার ট্যাপ করুন",
    history: "হিস্ট্রি",
    noWithdrawals: "এখনো কোনো উইথড্র নেই।",
    noDeposits: "এখনো কোনো ডিপোজিট নেই।",
    noSquad: "এখনো কোনো পার্টনার নেই। লিংক শেয়ার করুন — তারা মাইনিং শুরু করলে যোগ্য হবে।",
    verifyNow: "ভেরিফাই করুন",
    requestWithdrawal: "উইথড্র রিকোয়েস্ট",
    amount: "পরিমাণ",
    connectFirst: "আগে ওয়ালেট কানেক্ট করুন।",
    depositsClosed: "ডিপোজিট এখনো খোলা হয়নি।",
    copied: "কপি হয়েছে",
    language: "EN",
    languageBn: "বাংলা",
    more: "আরও",
    play: "গেম",
  },
} as const;

export type Msg = keyof typeof STRINGS.en;

type Ctx = {
  locale: Locale;
  setLocale: (l: Locale) => void;
  t: (key: Msg) => string;
};

const LocaleCtx = createContext<Ctx | null>(null);

export function LocaleProvider({ children }: { children: ReactNode }) {
  // English only.
  const locale: Locale = "en";
  const setLocale = (_l: Locale) => undefined;
  const t = useMemo(() => {
    const table = STRINGS[locale];
    return (key: Msg) => table[key];
  }, [locale]);
  return <LocaleCtx.Provider value={{ locale, setLocale, t }}>{children}</LocaleCtx.Provider>;
}

export function useI18n() {
  const ctx = useContext(LocaleCtx);
  if (!ctx) throw new Error("useI18n outside provider");
  return ctx;
}
