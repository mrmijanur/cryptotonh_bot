import type { TonConnectUI } from "@tonconnect/ui";

let instance: Promise<TonConnectUI> | null = null;

/** One shared TonConnect instance for the whole app (wallet button + deposits). */
export function getTonUi(): Promise<TonConnectUI> {
  if (!instance) {
    const created = import("@tonconnect/ui").then(
      (mod) =>
        new mod.TonConnectUI({
          manifestUrl: `${window.location.origin}/tonconnect-manifest.json`,
        }),
    );
    created.catch(() => {
      instance = null;
    });
    instance = created;
  }
  return instance;
}
