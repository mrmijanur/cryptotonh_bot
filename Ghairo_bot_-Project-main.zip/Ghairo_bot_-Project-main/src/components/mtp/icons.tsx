import { useId } from "react";
import { cn } from "@/lib/utils";

export function GoldCoin({ className }: { className?: string }) {
  return (
    <img
      src="/mtp/coin.png"
      alt=""
      width={28}
      height={28}
      className={cn("inline-block shrink-0 object-contain", className)}
    />
  );
}

/** A faceted gem drawn in SVG. Pass any base colour; the facets are derived from it. */
export function GemIcon({ color = "#d8b46a", className, glow = false }: { color?: string; className?: string; glow?: boolean }) {
  const uid = useId().replace(/:/g, "");
  return (
    <svg
      viewBox="0 0 120 120"
      className={cn("shrink-0", className)}
      aria-hidden="true"
      style={glow ? { filter: `drop-shadow(0 6px 14px ${color}88)` } : undefined}
    >
      <defs>
        <linearGradient id={`top-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="1" stopColor={color} />
        </linearGradient>
        <linearGradient id={`left-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={color} />
          <stop offset="1" stopColor="#000000" stopOpacity="0.55" />
        </linearGradient>
        <linearGradient id={`right-${uid}`} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity="0.9" />
          <stop offset="1" stopColor="#000000" stopOpacity="0.7" />
        </linearGradient>
      </defs>
      <path d="M36 22h48l24 28-48 52L12 50z" fill={`url(#left-${uid})`} />
      <path d="M36 22h48l24 28H12z" fill={`url(#top-${uid})`} />
      <path d="M12 50h96L60 102z" fill={`url(#right-${uid})`} />
      <path d="M36 22l-6 28 30 52M84 22l6 28-30 52M60 22v28" stroke="#ffffff" strokeOpacity="0.35" strokeWidth="1.4" fill="none" />
      <path d="M12 50h96" stroke="#ffffff" strokeOpacity="0.5" strokeWidth="1.2" />
    </svg>
  );
}

/** Brand mark used on the loading screen. */
export function BrandGem({ className }: { className?: string }) {
  return <GemIcon color="#d8b46a" glow className={className} />;
}

export function TonMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("size-9", className)} aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#0098ea" />
      <path
        fill="#fff"
        d="M24.2 10.5c.5 0 .9.2 1.2.6l11.4 17.2c.7 1-.1 2.4-1.3 2.4h-4.4c-.5 0-1-.3-1.3-.7L24.2 20l-5.6 9.9c-.3.5-.8.7-1.3.7h-4.4c-1.2 0-2-1.4-1.3-2.4L23 11.1c.3-.4.7-.6 1.2-.6Z"
      />
    </svg>
  );
}

export function UsdtMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={cn("size-9", className)} aria-hidden="true">
      <circle cx="24" cy="24" r="24" fill="#26a17b" />
      <path
        fill="#fff"
        d="M26.6 21.6v-3.3h7.2v-4.2H14.2v4.2h7.2v3.3c-5.9.3-10.3 1.5-10.3 3 0 1.6 4.4 2.8 10.3 3.1v11.1h5.2V27.7c5.8-.3 10.2-1.5 10.2-3.1 0-1.5-4.4-2.7-10.2-3Zm0 4.8v.1c-.2 0-.5.1-.8.1h-.1c-4.9-.1-8.5-1-8.5-2.1s3.6-2 8.5-2.1h.1c.3 0 .6 0 .8.1v5.9c4.8-.2 8.3-1.1 8.3-2.1 0-1-3.5-1.9-8.3-2.1Z"
      />
    </svg>
  );
}

export function FlagGB({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 30" className={cn("h-3.5 w-[22px] rounded-[2px]", className)} aria-hidden="true">
      <rect width="60" height="30" fill="#012169" />
      <path d="M0 0 L60 30 M60 0 L0 30" stroke="#fff" strokeWidth="6" />
      <path d="M0 0 L60 30 M60 0 L0 30" stroke="#C8102E" strokeWidth="3.6" />
      <path d="M30 0 V30 M0 15 H60" stroke="#fff" strokeWidth="10" />
      <path d="M30 0 V30 M0 15 H60" stroke="#C8102E" strokeWidth="6" />
    </svg>
  );
}

export function FlagBD({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 36" className={cn("h-3.5 w-[22px] rounded-[2px]", className)} aria-hidden="true">
      <rect width="60" height="36" fill="#006a4e" />
      <circle cx="26" cy="18" r="10" fill="#f42a41" />
    </svg>
  );
}

export function LinkMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("size-9", className)} aria-hidden="true">
      <rect width="40" height="40" rx="8" fill="#d8b46a" />
      <path
        d="M17 23a5 5 0 0 0 7 0l4-4a5 5 0 0 0-7-7l-1.5 1.5M23 17a5 5 0 0 0-7 0l-4 4a5 5 0 0 0 7 7l1.5-1.5"
        fill="none"
        stroke="#fff"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
