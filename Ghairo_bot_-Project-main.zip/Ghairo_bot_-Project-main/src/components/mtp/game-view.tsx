import { Check, Lock } from "lucide-react";
import { MIN_CLAIM, packageDaily } from "@/lib/mtp/config";
import type { MinerView } from "@/lib/mtp/types";
import { cn, formatMtp } from "@/lib/utils";
import { useI18n } from "./i18n";
import { GemIcon, GoldCoin } from "./icons";
import { LiveAmount } from "./live-amount";

/** One look per package: 12 gem grades, from raw quartz up to a mythic diamond. */
const TIERS = [
  { name: "Quartz", color: "#c8b79a" },
  { name: "Citrine", color: "#e3b341" },
  { name: "Jade", color: "#3ecf9a" },
  { name: "Topaz", color: "#f08a3c" },
  { name: "Aquamarine", color: "#3cc4e0" },
  { name: "Sapphire", color: "#4a7dff" },
  { name: "Amethyst", color: "#9b6bff" },
  { name: "Ruby", color: "#f0506a" },
  { name: "Emerald", color: "#1fb36b" },
  { name: "Onyx", color: "#8a93a8" },
  { name: "Obsidian", color: "#9fb1d1" },
  { name: "Diamond", color: "#9be8ff" },
] as const;

const fmt = (v: number) => formatMtp(v, v > 0 && v < 1 ? 3 : 2);

export function GameView({
  view,
  busy,
  onStart,
  onClaim,
  onMinClaim,
  onBuy,
}: {
  view: MinerView;
  busy: boolean;
  onStart: () => void;
  onClaim: () => void;
  onMinClaim: () => void;
  onBuy: (index: number) => void;
}) {
  const { t } = useI18n();
  const { miner } = view;
  const packs = view.packages;
  const owned = miner.birds ?? [];
  const nextIndex = packs.findIndex((_, i) => !owned.includes(i));
  const hour = view.ratePerSecond * 3600;
  const day = view.ratePerSecond * 86_400;
  const month = day * 30;
  const best = owned.length ? Math.max(...owned) : -1;
  const heroColor = best >= 0 ? TIERS[best % TIERS.length]!.color : "#6c7b99";
  const progress = packs.length ? Math.round((owned.length / packs.length) * 100) : 0;

  return (
    <section className="relative z-10 flex flex-col gap-4 px-3 pb-6 pt-1">
      {/* Hero: the best gem inside a light ring, the live amount, and the main action. */}
      <div className="paper-card gem-sheen px-4 pb-5 pt-4 text-center">
        <div className="flex items-center justify-between">
          <span
            className={cn(
              "inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-semibold",
              miner.mining ? "bg-[#34d399]/12 text-[#5eead4]" : "bg-white/[0.06] text-muted",
            )}
          >
            <span className={cn("size-2 rounded-full", miner.mining ? "live-dot bg-[#34d399]" : "bg-[#6c7b99]")} />
            {miner.mining ? "Mining live" : "Mining paused"}
          </span>
          <span className="text-[11px] font-semibold text-muted">
            Vault {owned.length}/{packs.length}
          </span>
        </div>

        <div className="relative mx-auto mt-4 flex size-[150px] items-center justify-center">
          <div
            className="orb-glow absolute inset-2 rounded-full"
            style={{ background: `radial-gradient(circle, ${heroColor}55 0%, ${heroColor}12 55%, transparent 72%)` }}
          />
          <div className={cn("orb-ring absolute inset-0 rounded-full", miner.mining && "is-live")} />
          <div className="absolute inset-[7px] rounded-full ring-1 ring-white/10" />
          <GemIcon color={heroColor} glow className={cn("relative size-[84px]", miner.mining && "gem-idle")} />
        </div>

        <p className="mt-3 text-[11px] font-semibold uppercase tracking-[0.28em] text-muted">{t("accrued")}</p>
        <p className="mt-1 flex items-center justify-center gap-2 font-display text-[32px] font-bold tabular-nums gold-text">
          <GoldCoin className="size-8" />
          <LiveAmount
            base={view.unclaimed}
            rate={view.ratePerSecond}
            since={miner.lastAccruedAt}
            active={miner.mining}
            digits={6}
          />
        </p>

        <div className="mt-4 grid grid-cols-3 gap-2.5">
          <RateCard label={t("hour")} value={hour} />
          <RateCard label={t("day")} value={day} />
          <RateCard label={t("month")} value={month} />
        </div>

        <button
          type="button"
          disabled={busy}
          onClick={() => {
            const live = view.unclaimed + (miner.mining ? view.ratePerSecond * ((Date.now() - miner.lastAccruedAt) / 1000) : 0);
            if (!miner.mining) onStart();
            else if (live < MIN_CLAIM) onMinClaim();
            else onClaim();
          }}
          className="btn-collect mt-4 h-12 w-full rounded-2xl font-display text-[14px] font-bold uppercase tracking-[0.18em] disabled:opacity-60"
        >
          {t("collect")}
        </button>
      </div>

      {/* Vault: one small slot per gem. */}
      <div className="paper-card p-4">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-muted">Your vault</p>
          <p className="text-[11px] font-semibold text-[#7db6ff]">{progress}%</p>
        </div>
        <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#4f9cff] to-[#38d6ff] transition-[width] duration-700"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="grid grid-cols-6 gap-2">
          {Array.from({ length: packs.length }, (_, i) => {
            const has = owned.includes(i);
            const tier = TIERS[i % TIERS.length]!;
            return (
              <div
                key={i}
                className="slot-cell relative flex aspect-square items-center justify-center overflow-hidden rounded-xl"
                style={has ? { background: `radial-gradient(circle at 50% 55%, ${tier.color}30 0%, transparent 75%), rgba(130,170,255,0.05)` } : undefined}
              >
                {has ? (
                  <GemIcon color={tier.color} glow className="size-[68%]" />
                ) : (
                  <GemIcon color="#ffffff" className="size-[44%] opacity-[0.08]" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Shop: one row per gem, in the order they must be bought. */}
      <div>
        <div className="mb-2.5 flex items-center justify-between px-1">
          <p className="font-display text-[13px] font-semibold uppercase tracking-[0.28em] text-[#7db6ff]">Gem shop</p>
          <p className="text-[11px] font-medium text-muted">Unlock in order</p>
        </div>
        <div className="flex flex-col gap-2.5">
          {packs.map((pack, i) => {
            const tier = TIERS[i % TIERS.length]!;
            const done = owned.includes(i);
            const next = i === nextIndex;
            const locked = !done && !next;
            const affordable = miner.pool >= pack.price;
            return (
              <div
                key={i}
                className={cn("paper-card flex items-center gap-3 p-3 transition-opacity", locked && "opacity-60")}
                style={next ? { boxShadow: `0 0 0 1px ${tier.color}66, 0 14px 34px -16px ${tier.color}88` } : undefined}
              >
                <div
                  className="flex size-[62px] shrink-0 items-center justify-center rounded-2xl"
                  style={{ background: `radial-gradient(circle, ${tier.color}38 0%, ${tier.color}0f 62%, transparent 78%)`, boxShadow: `inset 0 0 0 1px ${tier.color}30` }}
                >
                  <GemIcon color={tier.color} glow={!locked} className={cn("size-[42px]", locked && "grayscale-[50%]")} />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <p className="font-display text-[15px] font-semibold text-ink">{tier.name}</p>
                    <span
                      className="rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wide"
                      style={{ color: tier.color, background: `${tier.color}1c` }}
                    >
                      {pack.percent}% / day
                    </span>
                  </div>
                  <p className="mt-1 flex items-center gap-1 text-[12px] font-medium tabular-nums text-muted">
                    <GoldCoin className="size-3.5" />
                    {fmt(packageDaily(i, packs))} / day
                  </p>
                  <p className="text-[12px] font-semibold tabular-nums text-withdraw">
                    {formatMtp(packageDaily(i, packs) * 30, 2)} / month
                  </p>
                </div>

                {done ? (
                  <span className="flex h-10 shrink-0 items-center gap-1 rounded-full bg-[#34d399]/12 px-3 text-[12px] font-bold text-[#5eead4]">
                    <Check className="size-4" strokeWidth={3} />
                    Owned
                  </span>
                ) : (
                  <button
                    type="button"
                    disabled={busy || !next || !affordable}
                    onClick={() => onBuy(i)}
                    className={cn(
                      "flex h-10 shrink-0 items-center gap-1.5 rounded-full px-4 font-display text-[14px] font-bold tabular-nums disabled:opacity-100",
                      next && affordable ? "btn-collect" : "bg-white/[0.07] text-muted",
                    )}
                  >
                    {locked ? <Lock className="size-3.5" strokeWidth={2.6} /> : null}
                    <GoldCoin className="size-4" />
                    {pack.price}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function RateCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="slot-cell px-2 py-2.5 text-center">
      <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted">{label}</p>
      <p className="mt-1 flex items-center justify-center gap-1 text-[14px] font-bold tabular-nums text-ink">
        <GoldCoin className="size-4" />
        {value.toFixed(2)}
      </p>
    </div>
  );
}
