import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { FlagBD, FlagGB } from "./icons";
import { useI18n } from "./i18n";

export function LangSwitch() {
  const { locale, setLocale } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <div className="relative z-20">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex min-h-9 items-center gap-1.5 rounded-md bg-white/10 px-2 py-1 text-[12px] font-semibold text-ink shadow-border"
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        {locale === "bn" ? <FlagBD /> : <FlagGB />}
        {locale === "bn" ? "BN" : "EN"}
        <ChevronDown className="size-3.5 text-muted" />
      </button>
      {open ? (
        <ul
          role="listbox"
          className="absolute bottom-full left-0 mb-1 min-w-full overflow-hidden rounded-md bg-[#171b27] shadow-border"
        >
          <li>
            <button
              type="button"
              className="flex w-full items-center gap-1.5 px-2 py-2 text-left text-[12px] font-semibold text-ink hover:bg-elevated"
              onClick={() => {
                setLocale("en");
                setOpen(false);
              }}
            >
              <FlagGB /> EN
            </button>
          </li>
          <li>
            <button
              type="button"
              className="flex w-full items-center gap-1.5 px-2 py-2 text-left text-[12px] font-semibold text-ink hover:bg-elevated"
              onClick={() => {
                setLocale("bn");
                setOpen(false);
              }}
            >
              <FlagBD /> BN
            </button>
          </li>
        </ul>
      ) : null}
    </div>
  );
}
