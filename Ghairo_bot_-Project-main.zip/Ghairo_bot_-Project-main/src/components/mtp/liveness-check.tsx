import { useEffect, useRef, useState } from "react";
import { Camera, ShieldCheck, ShieldX } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { LivenessStatus } from "@/lib/mtp/types";

type Scores = {
  motionScore: number;
  blinkScore: number;
  headScore: number;
  frames: number;
  durationMs: number;
};

export function LivenessCheck({
  status,
  busy,
  onSubmit,
}: {
  status?: LivenessStatus;
  busy: boolean;
  onSubmit: (scores: Scores) => Promise<void>;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [phase, setPhase] = useState<"idle" | "running" | "error">("idle");
  const [hint, setHint] = useState("Look at the camera, blink, and turn your head.");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    return () => stopStream();
  }, []);

  function stopStream() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }

  async function start() {
    setError(null);
    setPhase("running");
    setHint("Hold still in frame, then blink and turn your head.");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 320 }, height: { ideal: 240 } },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) throw new Error("Camera view missing.");
      video.srcObject = stream;
      await video.play();
      const scores = await analyze(video);
      stopStream();
      setPhase("idle");
      await onSubmit(scores);
    } catch (err) {
      stopStream();
      setPhase("error");
      setError(err instanceof Error ? err.message : "Camera check failed.");
    }
  }

  if (status === "approved") {
    return (
      <div className="rounded-2xl bg-surface p-4 shadow-border">
        <p className="flex items-center gap-2 text-sm font-medium text-mint">
          <ShieldCheck className="size-4" />
          Liveness approved
        </p>
        <p className="mt-1 text-xs text-muted">Anti-bot check complete. This is not identity verification.</p>
      </div>
    );
  }

  if (status === "pending") {
    return (
      <div className="rounded-2xl bg-surface p-4 shadow-border">
        <p className="text-sm font-medium">Submitted — pending review</p>
        <p className="mt-1 text-xs text-muted">
          An admin will approve or reject this check. You will get a Telegram message either way.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-surface p-4 shadow-border">
      <p className="text-sm font-medium">Live camera check</p>
      <p className="mt-1 text-xs text-muted">
        Anti-bot only. A static photo or a screen held up to the camera will be rejected. This does not
        confirm your real-world identity.
      </p>
      <div className="relative mx-auto mt-4 h-52 w-full max-w-[240px] overflow-hidden rounded-2xl bg-elevated">
        <video
          ref={videoRef}
          className="absolute inset-0 size-full -scale-x-100 object-cover"
          playsInline
          muted
        />
        <div className="pointer-events-none absolute inset-6 rounded-full border border-line-strong" />
      </div>
      <p className="mt-3 text-center text-xs text-muted">{hint}</p>
      {error ? (
        <p className="mt-2 flex items-center justify-center gap-1 text-xs text-danger">
          <ShieldX className="size-3.5" />
          {error}
        </p>
      ) : null}
      {status === "rejected" ? (
        <p className="mt-2 text-center text-xs text-warn">Previous check rejected. Try again.</p>
      ) : null}
      <Button className="mt-3 w-full" disabled={busy || phase === "running"} onClick={() => void start()}>
        <Camera className="size-4" />
        {phase === "running" ? "Checking…" : "Start live check"}
      </Button>
    </div>
  );
}

async function analyze(video: HTMLVideoElement): Promise<Scores> {
  const w = 160;
  const h = 120;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Could not read camera frames.");
  const durationMs = 4200;
  const started = performance.now();
  let prev: Uint8ClampedArray | null = null;
  let frames = 0;
  let madSum = 0;
  let upperMax = 0;
  let cx = 0;
  let cy = 0;
  let prevCx = 0;
  let prevCy = 0;
  let travel = 0;

  while (performance.now() - started < durationMs) {
    ctx.drawImage(video, 0, 0, w, h);
    const { data } = ctx.getImageData(0, 0, w, h);
    const gray = new Uint8ClampedArray(w * h);
    for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
      gray[p] = (data[i]! * 0.3 + data[i + 1]! * 0.59 + data[i + 2]! * 0.11) | 0;
    }
    if (prev) {
      let mad = 0;
      let upper = 0;
      let upperN = 0;
      let sumX = 0;
      let sumY = 0;
      let moving = 0;
      const cutoff = (h * 0.42) | 0;
      for (let y = 0; y < h; y += 1) {
        for (let x = 0; x < w; x += 1) {
          const i = y * w + x;
          const d = Math.abs(gray[i]! - prev[i]!);
          mad += d;
          if (y < cutoff) {
            upper += d;
            upperN += 1;
          }
          if (d > 18) {
            sumX += x;
            sumY += y;
            moving += 1;
          }
        }
      }
      const mean = mad / gray.length;
      madSum += mean;
      const uMean = upperN ? upper / upperN : 0;
      if (uMean > upperMax) upperMax = uMean;
      if (moving > 12) {
        cx = sumX / moving;
        cy = sumY / moving;
        if (frames > 2) travel += Math.hypot(cx - prevCx, cy - prevCy);
        prevCx = cx;
        prevCy = cy;
      }
      frames += 1;
    }
    prev = gray;
    await new Promise((r) => window.setTimeout(r, 70));
  }

  if (frames < 18) throw new Error("Not enough live frames. Keep the camera uncovered.");
  const motionScore = clamp01(madSum / frames / 28);
  const blinkScore = clamp01(upperMax / 36);
  const headScore = clamp01(travel / 90);
  if (motionScore < 0.12) {
    throw new Error("That looked static. Use a live camera, blink, and turn your head.");
  }
  return {
    motionScore,
    blinkScore,
    headScore,
    frames,
    durationMs: performance.now() - started,
  };
}

function clamp01(n: number) {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}
