import { useState } from "react";
import { toast } from "sonner";
import { setPayoutAddressFn } from "@/lib/mtp/functions";
import type { MinerView } from "@/lib/mtp/types";
import { formatMtp, shortAddress } from "@/lib/utils";
import { GoldCoin, TonMark, UsdtMark } from "./icons";
import { NetworkBadge, NetworkWarning } from "./network-note";

const FIELD = "field-box flex h-11 w-full items-center px-3 text-[15px] font-semibold tabular-nums text-ink outline-none";
const usd = (n: number) => n.toFixed(2);

export function WithdrawView({
  view,
  busy,
  onView,
  onWithdraw,
  onNotice,
  onBlocked,
}: {
  view: MinerView;
  busy: boolean;
  onView: (view: MinerView) => void;
  onWithdraw: (amount: number, method: "gram" | "usdt") => void;
  onNotice: (text: string) => void;
  /** Called when the user taps Pay out while the withdraw notice is ON. */
  onBlocked: () => void;
}) {
  const { miner, coinUsd, gramUsd } = view;
  const [step, setStep] = useState<"list" | "form" | "address">("list");
  const [method, setMethod] = useState<"gram" | "usdt">("gram");
  const isUsdt = method === "usdt";
  const payAddress = isUsdt ? miner.payoutAddressUsdt : miner.payoutAddress;
  const [amount, setAmount] = useState(() => (Math.floor(miner.pool * 100 + 1e-9) / 100).toFixed(2));
  const [addr, setAddr] = useState(miner.payoutAddress ?? "");
  const [addrUsdt, setAddrUsdt] = useState(miner.payoutAddressUsdt ?? "");
  const [saving, setSaving] = useState(false);

  const give = Math.floor((Number(amount) || 0) * 100 + 1e-9) / 100;
  const youGet = give * coinUsd;
  const gram = isUsdt ? youGet : gramUsd > 0 ? youGet / gramUsd : 0; // amount of the chosen asset

  const miner_has = (which: "gram" | "usdt") => Boolean(which === "usdt" ? miner.payoutAddressUsdt : miner.payoutAddress);

  async function saveAddress(which: "gram" | "usdt") {
    setSaving(true);
    try {
      onView(await setPayoutAddressFn({ data: { address: (which === "usdt" ? addrUsdt : addr).trim(), method: which } }));
      toast.success(miner_has(which) ? "Address updated" : "Address saved");
      setStep("form");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the address");
    } finally {
      setSaving(false);
    }
  }

  function payOut() {
    if (view.withdrawNotice) {
      onBlocked(); // scroll up to the notice and shake it; nothing is sent
      return;
    }
    if (!payAddress) {
      toast.error("Set your payout address first.");
      return;
    }
    if (give < view.minWithdraw) {
      onNotice(`Minimum ${view.minWithdraw}`);
      return;
    }
    if (view.maxWithdraw > 0 && give > view.maxWithdraw) {
      toast.error(`Maximum withdrawal is ${view.maxWithdraw} coin.`);
      return;
    }
    if (give > miner.pool + 1e-9) {
      toast.error("Not enough balance.");
      return;
    }
    onWithdraw(give, method);
    setStep("list");
  }

  return (
    <section className="relative z-10 flex flex-col gap-3 px-2.5 pb-8 pt-2">
      <div className="flex overflow-hidden rounded-full shadow-border">
        <div className="pill-withdraw flex flex-1 items-center px-4 py-2.5 text-[14px] font-extrabold">Withdraw funds</div>
        <div className="flex items-center gap-1 bg-paper px-4 py-2.5 text-[15px] font-extrabold tabular-nums text-ink">
          <span className="text-withdraw">$</span>
          {usd(miner.pool * coinUsd)}
        </div>
      </div>

      {step === "list" ? (
        <>
          <p className="px-1 text-center text-[12px] font-bold leading-snug text-muted">
            Choose what you want to receive. Both Gram and USDT are paid on the <span className="font-black text-ink">TON network</span>.
          </p>
          {(["gram", "usdt"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setMethod(m);
                setStep("form");
              }}
              className="plaque flex items-center gap-3 rounded-md px-3 py-2.5 text-left"
            >
              {m === "usdt" ? <UsdtMark className="size-11 shrink-0" /> : <TonMark className="size-11 shrink-0" />}
              <span>
                <span className="flex items-center gap-2 text-[15px] font-extrabold">
                  {m === "usdt" ? "USDT" : "Gram"}
                  <NetworkBadge />
                </span>
                <span className="flex items-center gap-1 text-[13px] font-semibold">
                  Minimum: <GoldCoin className="size-4" /> {formatMtp(view.minWithdraw, 2)} = <span className="text-withdraw">$</span>{" "}
                  {usd(view.minWithdraw * coinUsd)}
                </span>
              </span>
            </button>
          ))}
        </>
      ) : null}

      {step === "form" ? (
        <div className="paper-card rounded-md p-4">
          <NetworkWarning action="withdraw" className="mb-3" />
          <label className="text-[14px] font-extrabold">Give</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            <GoldCoin className="size-8" />
            <input
              className={FIELD}
              inputMode="decimal"
              value={amount}
              onChange={(e) => {
                const v = e.target.value.replace(",", ".");
                if (/^\d*\.?\d{0,2}$/.test(v)) setAmount(v);
              }}
            />
          </div>
          <label className="mt-3 block text-[14px] font-extrabold">You get</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            <span className="w-8 text-center text-[22px] font-black text-withdraw">$</span>
            <div className={FIELD}>{usd(youGet)}</div>
          </div>
          <label className="mt-3 block text-[14px] font-extrabold">{isUsdt ? "Get USDT:" : "Get Gram coins:"}</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            {isUsdt ? <UsdtMark className="size-8" /> : <TonMark className="size-8" />}
            <div className={FIELD}>{gram.toFixed(6)}</div>
          </div>
          <label className="mt-3 block text-[14px] font-extrabold">My address (TON network):</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            {isUsdt ? <UsdtMark className="size-8" /> : <TonMark className="size-8" />}
            <button
              type="button"
              onClick={() => {
                // Always open the editor with the address that is saved right now.
                setAddr(miner.payoutAddress ?? "");
                setAddrUsdt(miner.payoutAddressUsdt ?? "");
                setStep("address");
              }}
              className="field-box flex h-11 w-full items-center justify-between gap-2 px-3 text-[12px] font-black uppercase tracking-wide"
            >
              <span>{payAddress ? shortAddress(payAddress) : "Set payout address"}</span>
              {payAddress ? <span className="rounded bg-white/10 px-2 py-0.5 text-[11px]">Edit</span> : null}
            </button>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button type="button" onClick={() => setStep("list")} className="plaque rounded-lg px-4 text-[14px] font-extrabold">
              Back
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={payOut}
              className="btn-collect h-11 w-36 rounded-lg font-display text-[16px] font-black disabled:opacity-60"
            >
              Pay out
            </button>
          </div>
        </div>
      ) : null}

      {step === "address" ? (
        <div className="paper-card rounded-md p-4">
          <NetworkWarning action="withdraw" className="mb-3" />
          <p className="text-[14px] font-extrabold">Your payout addresses (TON network)</p>
          <p className="mt-1 text-[12px] font-semibold text-muted">You can change an address any time. Pending requests keep the address they were made with.</p>
          {(["gram", "usdt"] as const).map((m) => (
            <div key={m} className="mt-3 grid grid-cols-[auto_1fr_auto] items-center gap-2">
              {m === "usdt" ? <UsdtMark className="size-8" /> : <TonMark className="size-8" />}
              <input
                className={FIELD}
                placeholder={m === "usdt" ? "USDT address on TON (UQ…)" : "Gram address on TON (UQ…)"}
                value={m === "usdt" ? addrUsdt : addr}
                onChange={(e) => (m === "usdt" ? setAddrUsdt(e.target.value) : setAddr(e.target.value))}
              />
              <button
                type="button"
                disabled={saving || (m === "usdt" ? addrUsdt : addr).trim().length < 8}
                onClick={() => void saveAddress(m)}
                className="btn-collect h-11 w-20 rounded-lg font-display text-[14px] font-black disabled:opacity-60"
              >
                {miner_has(m) ? "Update" : "Save"}
              </button>
            </div>
          ))}
          <div className="mt-4 flex justify-end">
            <button type="button" onClick={() => setStep("form")} className="plaque rounded-lg px-4 py-2 text-[14px] font-extrabold">
              Back
            </button>
          </div>
        </div>
      ) : null}

      <History view={view} />
    </section>
  );
}

function History({ view }: { view: MinerView }) {
  const COLS = "grid grid-cols-[1.2fr_0.8fr_0.8fr_0.8fr_1fr] items-center gap-1 px-3 text-[12px]";
  return (
    <>
      <div className="plaque rounded-md py-3">
        <div className={`${COLS} font-extrabold`}>
          <span>Date</span>
          <span>Method</span>
          <span>Sum</span>
          <span>Coin</span>
          <span>Status</span>
        </div>
      </div>
      {view.withdrawals.length ? (
        <div className="plaque rounded-md py-1">
          {view.withdrawals.map((w) => (
            <div key={w.id} className={`${COLS} py-2 font-semibold`}>
              <span className="tabular-nums">
                {new Date(w.createdAt).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
              </span>
              <span>{w.method === "usdt" ? "USDT" : "Gram"}</span>
              <span className="tabular-nums">${usd(w.usd ?? 0)}</span>
              <span className="tabular-nums">{formatMtp(w.amount, 2)}</span>
              <span className="capitalize">{w.status}</span>
            </div>
          ))}
        </div>
      ) : null}
    </>
  );
}
