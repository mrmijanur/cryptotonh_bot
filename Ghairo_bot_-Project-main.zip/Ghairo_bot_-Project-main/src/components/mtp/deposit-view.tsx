import type { ReactNode } from "react";
import { Copy } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { checkDepositFn, openDepositFn } from "@/lib/mtp/functions";
import type { MinerView, OpenedDeposit } from "@/lib/mtp/types";
import { formatMtp } from "@/lib/utils";
import { GoldCoin, TonMark, UsdtMark } from "./icons";
import { NetworkBadge, NetworkWarning } from "./network-note";

const FIELD = "field-box flex h-11 w-full items-center px-3 text-[15px] font-semibold tabular-nums text-ink outline-none";

async function copy(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success("Copied");
  } catch {
    toast.error("Could not copy");
  }
}

function usd(n: number) {
  return n.toFixed(2);
}

export function DepositView({
  view,
  busy,
  onView,
  onNotice,
}: {
  view: MinerView;
  busy: boolean;
  onView: (view: MinerView) => void;
  onNotice: (text: string) => void;
}) {
  const info = view.deposit;
  const gramUsd = view.gramUsd;
  const [step, setStep] = useState<"list" | "form" | "pay">("list");
  const [method, setMethod] = useState<"ton" | "usdt">("ton");
  const unitUsd = method === "ton" ? gramUsd : 1; // USDT is always $1
  const rate = method === "ton" ? info.tonRate : info.usdtRate;
  const minUnits = method === "ton" ? info.minTon : info.minUsdt;
  const [usdText, setUsdText] = useState("1.00");
  const [opened, setOpened] = useState<OpenedDeposit | null>(null);
  const [working, setWorking] = useState(false);

  const usdValue = Number(usdText) || 0;
  const gram = unitUsd > 0 ? usdValue / unitUsd : 0; // amount in the chosen asset
  const coins = gram * rate;
  const totalUsd = useMemo(
    () =>
      view.deposits
        .filter((d) => d.status === "completed")
        .reduce((s, d) => s + d.amount * (d.token === "usdt" ? 1 : gramUsd), 0),
    [view.deposits, gramUsd],
  );

  function pick(next: "ton" | "usdt") {
    setMethod(next);
    const nextUnit = next === "ton" ? gramUsd : 1;
    const nextMin = next === "ton" ? info.minTon : info.minUsdt;
    setUsdText(usd(Math.max(1, nextMin * nextUnit)));
    setStep("form");
  }

  async function topUp() {
    // The Gram price moves a little, so allow 0.5% slack. The banner shows the minimum rounded UP to the cent.
    if (gram < minUnits * 0.995) {
      onNotice(`Minimum $${(Math.ceil(minUnits * unitUsd * 100 - 1e-6) / 100).toFixed(2)}`);
      return;
    }
    setWorking(true);
    try {
      setOpened(await openDepositFn({ data: { token: method, amount: Math.round(gram * 1e6) / 1e6 } }));
      setStep("pay");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not open the deposit");
    } finally {
      setWorking(false);
    }
  }

  return (
    <section className="relative z-10 flex flex-col gap-3 px-2.5 pb-8 pt-2">
      <div className="flex overflow-hidden rounded-full shadow-border">
        <div className="pill-left flex flex-1 items-center px-4 py-2.5 text-[14px] font-extrabold">Balance replenishment</div>
        <div className="flex items-center gap-1 bg-paper px-4 py-2.5 text-[15px] font-extrabold tabular-nums text-ink">
          <span className="text-withdraw">$</span>
          {usd(totalUsd)}
        </div>
      </div>

      {step === "list" ? (
        <>
          <p className="px-1 text-center text-[12px] font-bold leading-snug text-muted">
            Choose how you want to top up. Both Gram and USDT are sent on the <span className="font-black text-ink">TON network</span>.
          </p>
          <MethodRow
            icon={<TonMark className="size-11 shrink-0" />}
            name="Gram"
            usdMin={(Math.ceil(info.minTon * gramUsd * 100 - 1e-6) / 100).toFixed(2)}
            coinMin={formatMtp(info.minTon * info.tonRate, 2)}
            disabled={!info.enabled || info.tonRate <= 0}
            onClick={() => pick("ton")}
          />
          <MethodRow
            icon={<UsdtMark className="size-11 shrink-0" />}
            name="USDT"
            usdMin={(Math.ceil(info.minUsdt * 100 - 1e-6) / 100).toFixed(2)}
            coinMin={formatMtp(info.minUsdt * info.usdtRate, 2)}
            disabled={!info.enabled || info.usdtRate <= 0}
            onClick={() => pick("usdt")}
          />
          {!info.enabled ? <p className="px-2 text-center text-[12px] font-semibold text-muted">Deposits are not open yet.</p> : null}
        </>
      ) : null}

      {step === "form" ? (
        <div className="paper-card rounded-md p-4">
          <NetworkWarning action="deposit" className="mb-3" />
          <label className="text-[14px] font-extrabold">Amount (USD)</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            <span className="w-8 text-center text-[22px] font-black text-withdraw">$</span>
            <input className={FIELD} inputMode="decimal" value={usdText} onChange={(e) => setUsdText(e.target.value)} />
          </div>
          <label className="mt-3 block text-[14px] font-extrabold">{method === "ton" ? "Gram" : "USDT"}</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            {method === "ton" ? <TonMark className="size-8" /> : <UsdtMark className="size-8" />}
            <div className={FIELD}>{gram.toFixed(6)}</div>
          </div>
          <label className="mt-3 block text-[14px] font-extrabold">Receive</label>
          <div className="mt-1 grid grid-cols-[auto_1fr] items-center gap-3">
            <GoldCoin className="size-8" />
            <div className={FIELD}>{formatMtp(coins, 2)}</div>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button type="button" onClick={() => setStep("list")} className="plaque rounded-lg px-4 text-[14px] font-extrabold">
              Back
            </button>
            <button
              type="button"
              disabled={working || busy}
              onClick={() => void topUp()}
              className="btn-collect h-11 w-36 rounded-lg font-display text-[16px] font-black disabled:opacity-60"
            >
              Top up
            </button>
          </div>
        </div>
      ) : null}

      {step === "pay" && opened ? (
        <PayScreen
          opened={opened}
          gramUsd={gramUsd}
          onRefresh={onView}
          onDone={(next) => {
            onView(next);
            setStep("list");
            setOpened(null);
          }}
          onBack={() => setStep("list")}
        />
      ) : null}

      <History view={view} />
    </section>
  );
}

function PayScreen({
  opened,
  gramUsd,
  onRefresh,
  onDone,
  onBack,
}: {
  opened: OpenedDeposit;
  gramUsd: number;
  onRefresh: (view: MinerView) => void;
  onDone: (view: MinerView) => void;
  onBack: () => void;
}) {
  const [qr, setQr] = useState("");
  const [checking, setChecking] = useState(false);
  const isUsdt = opened.token === "usdt";
  const link = isUsdt
    ? `ton://transfer/${opened.address}?jetton=${opened.jetton ?? ""}&amount=${Math.round(opened.amount * 1e6)}&text=${encodeURIComponent(opened.memo)}`
    : `ton://transfer/${opened.address}?amount=${Math.round(opened.amount * 1e9)}&text=${encodeURIComponent(opened.memo)}`;

  useEffect(() => {
    let alive = true;
    void import("qrcode").then((QR) => QR.toDataURL(link, { margin: 1, width: 240 })).then((url) => alive && setQr(url));
    return () => {
      alive = false;
    };
  }, [link]);

  async function check(manual: boolean) {
    setChecking(true);
    try {
      const res = await checkDepositFn({ data: { id: opened.id, sent: manual } });
      if (res.status === "completed") {
        toast.success("Deposit received. Coins added to your balance.");
        onDone(res.view);
      } else if (manual) {
        onRefresh(res.view); // the deposit now shows as Pending in the history
        toast.message("Not received yet. It can take a minute after you send.");
      }
    } catch {
      if (manual) toast.error("Could not check the payment right now.");
    } finally {
      setChecking(false);
    }
  }

  useEffect(() => {
    const id = window.setInterval(() => void check(false), 8000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [opened.id]);

  return (
    <div className="paper-card rounded-md p-4">
      <p className="text-center text-[15px] font-extrabold">You can send any amount.</p>
      <div className="mt-2 flex justify-center">
        <NetworkBadge />
      </div>
      <NetworkWarning action="deposit" className="mt-3" />

      <Row usdt={isUsdt} label={isUsdt ? "Send USDT to this TON address" : "Send Gram to this TON address"} value={opened.address} />
      <Row usdt={isUsdt} label={`Amount $${usd(opened.usd)}`} value={String(opened.amount)} />
      <Row usdt={isUsdt} label="Memo (required)" value={opened.memo} />
      <p className="mt-1 text-[12px] font-semibold text-muted">
        Always include the memo, or we cannot match your payment.
        {isUsdt ? " Network: TON only." : ` Network: TON only. 1 Gram ≈ $${usd(gramUsd)}.`}
      </p>

      <div className="mt-3 flex justify-center">
        {qr ? <img src={qr} alt="" className="size-48 rounded-md bg-white p-1" /> : <div className="size-48" />}
      </div>

      <div className="mt-4 flex justify-center gap-2">
        <button type="button" onClick={onBack} className="plaque rounded-lg px-4 text-[14px] font-extrabold">
          Back
        </button>
        <button
          type="button"
          disabled={checking}
          onClick={() => void check(true)}
          className="btn-collect h-11 w-48 rounded-lg font-display text-[15px] font-black disabled:opacity-60"
        >
          {checking ? "Checking…" : "I have paid"}
        </button>
      </div>
    </div>
  );
}

function Row({ label, value, usdt }: { label: string; value: string; usdt?: boolean }) {
  return (
    <>
      <p className="mt-3 text-[14px] font-extrabold">{label}</p>
      <div className="mt-1 grid grid-cols-[auto_1fr_auto] items-center gap-2">
        {usdt ? <UsdtMark className="size-7" /> : <TonMark className="size-7" />}
        <div className="field-box flex h-11 items-center overflow-hidden px-3">
          <span className="truncate text-[12px] font-semibold">{value}</span>
        </div>
        <button type="button" onClick={() => void copy(value)} className="plaque flex size-11 items-center justify-center rounded-md" aria-label="Copy">
          <Copy className="size-4" />
        </button>
      </div>
    </>
  );
}

function History({ view }: { view: MinerView }) {
  // A deposit shows up in the history only once the user pressed "I have paid" (or it is completed).
  const rows = view.deposits.filter(
    (d) => d.token !== "nft" && (d.status === "completed" || Boolean(d.submittedAt)),
  );
  const COLS = "grid grid-cols-[1.2fr_0.8fr_0.8fr_0.8fr_1fr] items-center gap-1 px-3 text-[12px]";
  return (
    <>
      <div className="plaque rounded-md py-3">
        <div className={`${COLS} font-extrabold`}>
          <span>Date</span>
          <span>Method</span>
          <span>Sum</span>
          <span>Coin</span>
          <span>Status</span>
        </div>
      </div>
      {rows.length ? (
        <div className="plaque rounded-md py-1">
          {rows.map((d) => (
            <div key={d.id} className={`${COLS} py-2 font-semibold`}>
              <span className="tabular-nums">
                {new Date(d.createdAt).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
              </span>
              <span>{d.token === "usdt" ? "USDT" : "Gram"}</span>
              <span className="tabular-nums">${usd(d.amount * (d.token === "usdt" ? 1 : view.gramUsd))}</span>
              <span className="tabular-nums">{formatMtp(d.mtp ?? d.amount * (d.rate ?? 0), 2)}</span>
              <span className="capitalize">{d.status ?? "completed"}</span>
            </div>
          ))}
        </div>
      ) : null}
    </>
  );
}

function MethodRow({
  icon,
  name,
  usdMin,
  coinMin,
  disabled,
  onClick,
}: {
  icon: ReactNode;
  name: string;
  usdMin: string;
  coinMin: string;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" disabled={disabled} onClick={onClick} className="plaque flex items-center gap-3 rounded-md px-3 py-2.5 text-left disabled:opacity-50">
      {icon}
      <span>
        <span className="flex items-center gap-2 text-[15px] font-extrabold">
          {name}
          <NetworkBadge />
        </span>
        <span className="flex items-center gap-1 text-[13px] font-semibold">
          Minimum: <span className="text-withdraw">$</span> {usdMin} = <GoldCoin className="size-4" /> {coinMin}
        </span>
      </span>
    </button>
  );
}
