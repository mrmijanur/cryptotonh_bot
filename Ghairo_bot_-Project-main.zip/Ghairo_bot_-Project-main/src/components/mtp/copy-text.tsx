import { useRef, useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const LONG_PRESS_MS = 450;

/**
 * Wraps a short piece of text (an id, address, or hash) so pressing and holding it
 * (or a plain tap on desktop) copies the full value to the clipboard.
 * `children` is what's shown; `value` is what actually gets copied (usually longer,
 * e.g. the full address behind a shortened display like "UQCz…cooi").
 */
export function CopyText({
  value,
  children,
  label = "Copied",
  className,
}: {
  value: string;
  children: React.ReactNode;
  label?: string;
  className?: string;
}) {
  const timer = useRef<number | null>(null);
  const fired = useRef(false);
  const [pressed, setPressed] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(label);
    } catch {
      toast.error("Could not copy");
    }
  }

  function start() {
    fired.current = false;
    setPressed(true);
    timer.current = window.setTimeout(() => {
      fired.current = true;
      setPressed(false);
      void copy();
    }, LONG_PRESS_MS);
  }

  function cancel() {
    setPressed(false);
    if (timer.current) {
      window.clearTimeout(timer.current);
      timer.current = null;
    }
  }

  return (
    <span
      role="button"
      tabIndex={0}
      className={cn(
        "cursor-pointer select-none rounded transition-colors",
        pressed && "bg-elevated",
        className,
      )}
      onPointerDown={start}
      onPointerUp={cancel}
      onPointerLeave={cancel}
      onPointerCancel={cancel}
      onContextMenu={(e) => e.preventDefault()}
      onClick={() => {
        // Desktop mouse users get a plain click; touch already fired on long-press above.
        if (!fired.current) void copy();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          void copy();
        }
      }}
    >
      {children}
    </span>
  );
}
