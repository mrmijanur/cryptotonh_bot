/** Loading screen shown while the app opens: a cartoon bomb runs from left to right. */
const CSS = `
@keyframes gh-in { 0% { opacity: 0; transform: translateY(6px); } 100% { opacity: 1; transform: translateY(0); } }
@keyframes gh-run {
  0% { left: -14%; opacity: 0; }
  12% { opacity: 1; }
  88% { opacity: 1; }
  100% { left: 100%; opacity: 0; }
}
@keyframes gh-bounce { 0%, 100% { transform: translateY(0) rotate(6deg); } 50% { transform: translateY(-7px) rotate(6deg); } }
@keyframes gh-leg-a { 0% { transform: rotate(-38deg); } 100% { transform: rotate(38deg); } }
@keyframes gh-leg-b { 0% { transform: rotate(38deg); } 100% { transform: rotate(-38deg); } }
@keyframes gh-spark { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.35); opacity: 0.75; } }
@keyframes gh-ground { 0% { background-position-x: 0; } 100% { background-position-x: -28px; } }
@keyframes gh-dust { 0% { opacity: 0.55; transform: scale(0.4); } 100% { opacity: 0; transform: translateX(-26px) scale(1.4); } }

.gh-splash { animation: gh-in 0.4s ease-out both; }
.gh-track { position: relative; width: 100%; max-width: 300px; height: 96px; overflow: hidden; }
.gh-bomb { position: absolute; bottom: 5px; width: 66px; height: 74px; animation: gh-run 2.6s linear infinite; }
.gh-bounce { width: 100%; height: 100%; animation: gh-bounce 0.36s ease-in-out infinite; }
.gh-leg { transform-box: fill-box; transform-origin: 50% 0%; }
.gh-leg-a { animation: gh-leg-a 0.36s ease-in-out infinite alternate; }
.gh-leg-b { animation: gh-leg-b 0.36s ease-in-out infinite alternate; }
.gh-spark { transform-box: fill-box; transform-origin: center; animation: gh-spark 0.28s ease-in-out infinite; }
.gh-ground {
  position: absolute; left: 0; right: 0; bottom: 0; height: 3px; border-radius: 2px;
  background: repeating-linear-gradient(90deg, #3d6fb8 0 14px, transparent 14px 28px);
  animation: gh-ground 0.45s linear infinite;
}
.gh-dust { position: absolute; bottom: 2px; left: -6px; width: 12px; height: 12px; border-radius: 9999px; background: #6f8fc4; animation: gh-dust 0.7s ease-out infinite; }
.gh-dust-2 { animation-delay: 0.23s; }
.gh-dust-3 { animation-delay: 0.46s; }

@media (prefers-reduced-motion: reduce) {
  .gh-bomb { animation: none; left: calc(50% - 33px); opacity: 1; }
  .gh-bounce, .gh-leg-a, .gh-leg-b, .gh-spark, .gh-ground, .gh-dust { animation: none; }
}
`;

function RunningBomb() {
  return (
    <div className="gh-bomb">
      <span className="gh-dust" />
      <span className="gh-dust gh-dust-2" />
      <span className="gh-dust gh-dust-3" />
      <div className="gh-bounce">
        <svg viewBox="0 0 100 110" width="100%" height="100%" aria-hidden="true">
          <defs>
            <radialGradient id="gh-body" cx="35%" cy="30%" r="80%">
              <stop offset="0" stopColor="#40506e" />
              <stop offset="0.55" stopColor="#1a2233" />
              <stop offset="1" stopColor="#06080e" />
            </radialGradient>
          </defs>

          {/* legs */}
          <g className="gh-leg gh-leg-a">
            <path d="M42 80 L40 97" stroke="#9fb4d6" strokeWidth="6" strokeLinecap="round" fill="none" />
            <ellipse cx="45" cy="102" rx="10" ry="5" fill="#4f9cff" />
          </g>
          <g className="gh-leg gh-leg-b">
            <path d="M60 80 L62 97" stroke="#9fb4d6" strokeWidth="6" strokeLinecap="round" fill="none" />
            <ellipse cx="65" cy="102" rx="10" ry="5" fill="#4f9cff" />
          </g>

          {/* body */}
          <circle cx="50" cy="58" r="28" fill="url(#gh-body)" />
          <circle cx="50" cy="58" r="28" fill="none" stroke="#4a5b7c" strokeOpacity="0.55" strokeWidth="1.4" />
          <ellipse cx="37" cy="42" rx="8" ry="5" transform="rotate(-30 37 42)" fill="#ffffff" opacity="0.18" />

          {/* cap and fuse */}
          <rect x="40" y="25" width="20" height="10" rx="3" fill="#2b364d" />
          <path d="M50 25 C50 16 59 14 62 8" stroke="#c9a66b" strokeWidth="3" strokeLinecap="round" fill="none" />
          <g className="gh-spark">
            <circle cx="62" cy="8" r="5.5" fill="#ffb020" />
            <circle cx="62" cy="8" r="2.6" fill="#fff3c4" />
            <path d="M62 0 V-2 M70 8 H73 M69 2 L72 -1 M55 2 L52 -1" stroke="#ffb020" strokeWidth="1.8" strokeLinecap="round" />
          </g>

          {/* face, looking to the right */}
          <circle cx="42" cy="55" r="7.5" fill="#f4f7ff" />
          <circle cx="61" cy="55" r="7.5" fill="#f4f7ff" />
          <circle cx="45.2" cy="56" r="3.6" fill="#0a0f1c" />
          <circle cx="64.2" cy="56" r="3.6" fill="#0a0f1c" />
          <path d="M45 71 Q53 77 61 70" stroke="#f4f7ff" strokeWidth="2.6" strokeLinecap="round" fill="none" />
        </svg>
      </div>
    </div>
  );
}

export function SplashScreen({ slow = false }: { slow?: boolean }) {
  return (
    <main
      className="gh-splash relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-6"
      style={{ background: "radial-gradient(120% 70% at 50% 0%, #15203a 0%, #0a0f1c 55%, #070b14 100%)" }}
    >
      <style>{CSS}</style>

      <div className="relative z-10 flex w-full max-w-[300px] flex-col items-center">
        <div className="gh-track">
          <RunningBomb />
          <div className="gh-ground" />
        </div>

        <h1 className="mt-7 font-display text-[22px] font-semibold uppercase tracking-[0.32em] text-[#eaf0ff]">Ghairo</h1>

        {slow ? (
          <div className="mt-4 flex flex-col items-center gap-3">
            <p className="text-[12px] font-medium tracking-wide text-[#8b9bb8]">Taking a little longer than usual…</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="h-10 rounded-full bg-[#4f9cff] px-6 font-display text-[13px] font-semibold text-[#06101f] transition-colors hover:bg-[#6aacff]"
            >
              Try again
            </button>
          </div>
        ) : (
          <p className="mt-3 text-[12px] font-medium tracking-[0.18em] text-[#8b9bb8]">Loading…</p>
        )}
      </div>
    </main>
  );
}
