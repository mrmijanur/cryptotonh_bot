import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { TOKEN_SYMBOL } from "@/lib/mtp/config";
import { checkDepositFn, prepareDepositFn, requestRefundFn } from "@/lib/mtp/functions";
import type { Deposit, DepositStatus, MinerView } from "@/lib/mtp/types";
import { formatMtp } from "@/lib/utils";
import { CopyText } from "./copy-text";
import { getTonUi } from "./ton-ui";

const STATUS_LABEL: Record<DepositStatus, string> = {
  pending: "Waiting for payment",
  expired: "Not paid",
  completed: "Completed",
  refund_requested: "Refund requested",
  refunded: "Refunded",
};

const sleep = (ms: number) => new Promise<void>((resolve) => window.setTimeout(resolve, ms));

type Phase = "idle" | "preparing" | "wallet" | "verifying";

export function DepositBox({
  view,
  busy,
  onView,
  lockedToken,
}: {
  view: MinerView;
  busy: boolean;
  onView: (view: MinerView) => void;
  lockedToken?: "ton" | "usdt";
}) {
  const info = view.deposit;
  const wallet = view.miner.wallet;
  const [token, setToken] = useState<"ton" | "usdt">(lockedToken ?? "ton");
  const [amount, setAmount] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState("");
  const [rowBusy, setRowBusy] = useState<string | null>(null);
  const [refundAsk, setRefundAsk] = useState<string | null>(null);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  useEffect(() => {
    if (lockedToken) setToken(lockedToken);
  }, [lockedToken]);

  const rate = token === "ton" ? info.tonRate : info.usdtRate;
  const parsed = Number(amount);
  const valid = Number.isFinite(parsed) && parsed > 0;
  const working = phase !== "idle";
  const symbol = token === "ton" ? "TON" : "USDT";
  const rows = view.deposits.filter((row) => row.token);

  async function startDeposit() {
    setError("");
    setPhase("preparing");
    let prepared;
    try {
      prepared = await prepareDepositFn({ data: { token, amount: parsed } });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not start the deposit.";
      setError(message);
      toast.error(message);
      setPhase("idle");
      return;
    }

    setPhase("wallet");
    try {
      const ui = await getTonUi();
      if (!ui.connected) {
        void ui.openModal();
        throw new Error("Reconnect your wallet, then try the deposit again.");
      }
      await ui.sendTransaction({ validUntil: prepared.validUntil, messages: prepared.messages });
    } catch (err) {
      const message =
        err instanceof Error && err.message.startsWith("Reconnect")
          ? err.message
          : "Payment was cancelled in your wallet.";
      if (alive.current) {
        setError(message);
        toast.error(message);
        setPhase("idle");
      }
      return;
    }

    if (alive.current) setPhase("verifying");
    const started = Date.now();
    let first = true;
    while (alive.current && Date.now() - started < 180_000) {
      try {
        const result = await checkDepositFn({ data: { id: prepared.id, sent: first } });
        first = false;
        onView(result.view);
        if (result.status === "completed") {
          if (alive.current) {
            setAmount("");
            setPhase("idle");
          }
          return;
        }
      } catch {
        /* keep polling */
      }
      await sleep(5000);
    }
    if (alive.current) {
      const message =
        "Payment not confirmed yet. If you already paid, wait a minute and tap Check payment below.";
      setError(message);
      toast.error(message);
      setPhase("idle");
    }
  }

  async function checkRow(row: Deposit) {
    setRowBusy(row.id);
    try {
      const result = await checkDepositFn({ data: { id: row.id } });
      onView(result.view);
      if (result.status !== "completed") {
        toast.error("Payment not found yet. If you just paid, wait a minute and try again.");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Check failed");
    } finally {
      if (alive.current) setRowBusy(null);
    }
  }

  async function refundRow(row: Deposit) {
    if (refundAsk !== row.id) {
      setRefundAsk(row.id);
      return;
    }
    setRefundAsk(null);
    setRowBusy(row.id);
    try {
      onView(await requestRefundFn({ data: { id: row.id } }));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Refund failed");
    } finally {
      if (alive.current) setRowBusy(null);
    }
  }

  const label =
    phase === "preparing"
      ? "Preparing…"
      : phase === "wallet"
        ? "Confirm in your wallet…"
        : phase === "verifying"
          ? "Waiting for confirmation…"
          : "Deposit";

  return (
    <div className="paper-card rounded-2xl p-4">
      {!info.enabled ? (
        <p className="text-sm text-warn">Deposits are not open yet.</p>
      ) : (
        <>
          {lockedToken ? null : (
            <div className="grid grid-cols-2 gap-2">
              {(["ton", "usdt"] as const).map((t) => {
                const open = (t === "ton" ? info.tonRate : info.usdtRate) > 0;
                return (
                  <Button
                    key={t}
                    variant={token === t ? "primary" : "secondary"}
                    disabled={working || !open}
                    onClick={() => setToken(t)}
                  >
                    {t === "ton" ? "TON" : open ? "USDT" : "USDT (soon)"}
                  </Button>
                );
              })}
            </div>
          )}
          <p className="text-xs text-muted">
            1 {symbol} = {formatMtp(rate, 2)} {TOKEN_SYMBOL}. Minimum{" "}
            {token === "ton" ? info.minTon : info.minUsdt} {symbol}
            {(token === "ton" ? info.maxTon : info.maxUsdt) > 0
              ? `, maximum ${token === "ton" ? info.maxTon : info.maxUsdt} ${symbol}`
              : ""}
            .
          </p>
          <label className="mt-3 block text-xs text-muted" htmlFor="dep-amt">
            Amount ({symbol})
          </label>
          <input
            id="dep-amt"
            inputMode="decimal"
            value={amount}
            disabled={working}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 h-11 w-full rounded-lg bg-elevated px-3 text-sm text-fg shadow-border outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
          />
          {valid ? (
            <p className="mt-2 text-xs text-muted">
              You get {formatMtp(parsed * rate, 2)} {TOKEN_SYMBOL} in your pool.
            </p>
          ) : null}
          {error ? <p className="mt-2 text-xs text-danger">{error}</p> : null}
          {!wallet ? <p className="mt-2 text-xs text-warn">Connect your wallet first.</p> : null}
          <Button
            className="mt-3 w-full"
            disabled={busy || working || !wallet || !valid}
            onClick={() => void startDeposit()}
          >
            {label}
          </Button>
        </>
      )}

      {rows.length > 0 ? (
        <div className="mt-4">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Your deposits</p>
          <ul className="mt-2 flex flex-col gap-2">
            {rows.map((row) => (
              <li key={row.id} className="rounded-xl bg-elevated px-3 py-3 shadow-border">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm tabular-nums">
                      {row.token === "nft"
                        ? `NFT · ${row.nftName ?? ""}`
                        : `${formatMtp(row.amount, 4)} ${(row.token ?? "").toUpperCase()}`}
                    </p>
                    <p className="text-[11px] text-muted">
                      <CopyText value={row.id} label="ID copied">
                        {row.id}
                      </CopyText>{" "}
                      · {new Date(row.createdAt).toLocaleDateString()}
                    </p>
                    {row.mtp ? (
                      <p className="text-[11px] text-muted">
                        Pool +{formatMtp(row.mtp, 2)} {TOKEN_SYMBOL}
                      </p>
                    ) : null}
                  </div>
                  <span className="text-xs text-muted">{STATUS_LABEL[row.status ?? "pending"]}</span>
                </div>
                {row.status === "pending" || row.status === "expired" ? (
                  <Button
                    className="mt-2 w-full"
                    variant="secondary"
                    disabled={rowBusy === row.id || working}
                    onClick={() => void checkRow(row)}
                  >
                    {rowBusy === row.id ? "Checking…" : "Check payment"}
                  </Button>
                ) : null}
                {row.status === "completed" ? (
                  <Button
                    className="mt-2 w-full"
                    variant="secondary"
                    disabled={rowBusy === row.id || working}
                    onClick={() => void refundRow(row)}
                  >
                    {refundAsk === row.id ? "Tap again to confirm refund" : "Request refund"}
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
