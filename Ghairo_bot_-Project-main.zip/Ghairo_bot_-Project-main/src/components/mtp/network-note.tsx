import { AlertTriangle, Globe } from "lucide-react";

/** Small "TON network" tag shown next to Gram and USDT. */
export function NetworkBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-[#f1d9a0] ${className}`}
    >
      <Globe className="size-3" strokeWidth={2.6} />
      TON network
    </span>
  );
}

/** Clear warning: Gram and USDT here are TON-network coins only. */
export function NetworkWarning({ action, className = "" }: { action: "deposit" | "withdraw"; className?: string }) {
  return (
    <div
      role="note"
      className={`rounded-lg border border-[#d8b46a]/35 bg-[#d8b46a]/10 px-3 py-2.5 text-left ${className}`}
    >
      <p className="flex items-center gap-1.5 text-[13px] font-black uppercase tracking-wide text-[#e6c987]">
        <AlertTriangle className="size-4" strokeWidth={2.6} />
        TON network only
      </p>
      <p className="mt-1 text-[12px] font-bold leading-snug text-ink">
        {action === "deposit"
          ? "Gram and USDT must be sent on the TON network. Money sent on any other network (BEP20, TRC20, ERC20, Polygon, Solana…) is lost and cannot be recovered."
          : "Gram and USDT are paid out on the TON network. Enter a TON address (it starts with UQ or EQ). An address from another network (BEP20, TRC20, ERC20…) will lose your money."}
      </p>
    </div>
  );
}
