import { Cog, Wrench } from "lucide-react";

/** Full-screen page shown while the admin has maintenance mode on. */
export function MaintenanceScreen({ text }: { text: string }) {
  return (
    <main className="paper-app splash relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div className="splash-glow pointer-events-none absolute left-1/2 top-1/2 size-[360px] -translate-x-1/2 -translate-y-[60%] rounded-full" />

      <div className="relative z-10 flex w-full max-w-[340px] flex-col items-center">
        <div className="relative h-[150px] w-[190px]">
          <Cog className="maint-gear absolute left-0 top-6 size-[96px] text-[#a07f3a]" strokeWidth={1.6} />
          <Cog className="maint-gear-rev absolute right-0 top-0 size-[78px] text-[#6f5a2c]" strokeWidth={1.6} />
          <Cog className="maint-gear absolute bottom-0 right-6 size-[54px] text-[#d8b46a]" strokeWidth={1.8} />
          <div className="maint-wrench absolute left-1/2 top-1/2 flex size-[58px] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#0d1018] shadow-[0_6px_16px_rgba(60,40,10,0.45)] ring-4 ring-[#f6cf72]/60">
            <Wrench className="size-7 text-[#f1d9a0]" strokeWidth={2.4} />
          </div>
        </div>

        <span className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#0d1018] px-3.5 py-1.5 text-[11px] font-black uppercase tracking-[0.2em] text-[#f1d9a0]">
          <span className="maint-dot size-2 rounded-full bg-[#f1d9a0]" />
          Updates in progress
        </span>

        <h1 className="mt-4 font-display text-[28px] font-black leading-tight text-ink">We are upgrading Ghairo</h1>
        <p className="mt-2 text-[15px] font-semibold leading-snug text-muted">
          Our team is polishing things behind the scenes to make your experience even better. We will be back very soon.
        </p>

        {text ? (
          <p className="paper-card mt-4 w-full rounded-xl px-4 py-3 text-[14px] font-extrabold leading-snug text-ink">{text}</p>
        ) : null}

        <div className="mt-6 h-[5px] w-48 overflow-hidden rounded-full bg-white/10">
          <div className="splash-bar h-full w-1/2 rounded-full bg-gradient-to-r from-[#f1d9a0] via-[#d8b46a] to-[#f1d9a0]" />
        </div>
        <p className="mt-3 text-[12px] font-bold tracking-wide text-muted">Your coins and gems are safe. No action needed.</p>
      </div>
    </main>
  );
}
