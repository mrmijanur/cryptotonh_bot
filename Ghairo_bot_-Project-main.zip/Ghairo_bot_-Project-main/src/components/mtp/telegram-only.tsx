import { APP_NAME } from "@/lib/mtp/config";
import { BrandGem } from "./icons";

export function TelegramOnly() {
  return (
    <main className="flex min-h-svh justify-center bg-tg">
      <div className="paper-app relative flex min-h-svh w-full max-w-[430px] flex-col items-center justify-center px-6 text-center">
        <BrandGem className="relative z-10 h-28 w-28" />
        <h1 className="relative z-10 mt-5 font-display text-2xl font-semibold tracking-tight text-ink">
          {APP_NAME}
        </h1>
        <p className="relative z-10 mt-3 max-w-[28ch] text-sm leading-relaxed text-muted">
          Please open this from Telegram. Ghairo only runs inside the official Mini App.
        </p>
      </div>
    </main>
  );
}
