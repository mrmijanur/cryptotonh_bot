import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  bootstrapMiner,
  checkChannelFn,
  buyBirdFn,
  claimFn,
  claimSquadCommissionFn,
  getMinerState,
  startMiningFn,
  withdrawFn,
} from "@/lib/mtp/functions";
import type { BootResult, MinerView } from "@/lib/mtp/types";
import { formatMtp } from "@/lib/utils";
import { DepositView } from "./deposit-view";
import { GameView } from "./game-view";
import { LocaleProvider, useI18n } from "./i18n";
import { GoldCoin } from "./icons";
import { JoinGate } from "./join-gate";
import { MaintenanceScreen } from "./maintenance-screen";
import { SplashScreen } from "./splash-screen";
import { ReferralsView } from "./referrals-view";
import { TabBar, type TabId } from "./tab-bar";
import { TelegramOnly } from "./telegram-only";
import { MIN_CLAIM } from "@/lib/mtp/config";
import { waitForTelegram } from "./telegram";
import { WithdrawView } from "./withdraw-view";

function initialTab(): TabId {
  if (typeof window === "undefined") return "game";
  const requested = new URLSearchParams(window.location.search).get("tab");
  if (requested === "deposit" || requested === "withdraw" || requested === "referrals") return requested;
  if (requested === "wallet") return "deposit";
  if (requested === "squad") return "referrals";
  if (requested === "mine" || requested === "game") return "game";
  return "game";
}

export function AppShell({ initial }: { initial: BootResult }) {
  return (
    <LocaleProvider>
      <ShellBody initial={initial} />
    </LocaleProvider>
  );
}

function ShellBody({ initial }: { initial: BootResult }) {
  const { t } = useI18n();
  const [tab, setTab] = useState<TabId>(initialTab);
  const [boot, setBoot] = useState<BootResult>(initial);
  const [busy, setBusy] = useState(false);
  const [booting, setBooting] = useState(initial.access !== "ok");
  const [notice, setNotice] = useState<{ text: string; key: number } | null>(null);
  const showNotice = (text: string) => {
    const key = Date.now();
    setNotice({ text, key });
    window.setTimeout(() => setNotice((cur) => (cur?.key === key ? null : cur)), Math.min(7000, 2600 + text.length * 35));
  };
  const [gain, setGain] = useState<{ amount: number; key: number } | null>(null);
  const [slow, setSlow] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const noticeTimer = useRef<number | undefined>(undefined);
  // The withdraw notice stays hidden until the user taps Pay out. Then the page scrolls up, the notice
  // appears and shakes. It runs on every tap, and nothing is sent to the server.
  const pingWithdrawNotice = () => {
    setNoticeOpen(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
    window.setTimeout(() => {
      document.getElementById("withdraw-notice")?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 60);
    window.setTimeout(() => setShakeKey((k) => k + 1), 420);
    window.clearTimeout(noticeTimer.current);
    noticeTimer.current = window.setTimeout(() => setNoticeOpen(false), 9000);
  };
  useEffect(() => {
    setNoticeOpen(false); // leaving the Withdraw tab hides it again
  }, [tab]);

  useEffect(() => {
    let cancelled = false;
    const params = new URLSearchParams(window.location.search);
    const run = async () => {
      await waitForTelegram();
      const tg = window.Telegram?.WebApp;
      tg?.ready();
      tg?.expand();
      tg?.setHeaderColor("#070b14");
      tg?.setBackgroundColor("#070b14");
      try {
        const next = await bootstrapMiner({
          data: {
            initData: tg?.initData || undefined,
            startParam:
              tg?.initDataUnsafe?.start_param ||
              params.get("startapp") ||
              params.get("ref") ||
              undefined,
            name: tg?.initDataUnsafe?.user?.first_name,
          },
        });
        if (!cancelled) setBoot(next);
      } catch {
        /* keep SSR result */
      } finally {
        if (!cancelled) setBooting(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, []);

  const view = boot.access === "ok" ? boot.view : null;

  // The loading screen never hangs silently: after 3.5 seconds it offers a retry.
  useEffect(() => {
    if (view) return;
    const id = window.setTimeout(() => setSlow(true), 3500);
    return () => window.clearTimeout(id);
  }, [view]);
  useEffect(() => {
    if (!view) return;
    // Refresh every 25 seconds, only while the app is on screen, and right away when it comes back.
    const refresh = () => {
      if (document.hidden) return;
      getMinerState()
        .then((next) => {
          if (next.access === "ok") setBoot(next);
        })
        .catch(() => undefined);
    };
    const id = window.setInterval(refresh, 25_000);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, [view?.miner.id]);

  async function run(action: () => Promise<MinerView>) {
    setBusy(true);
    try {
      const before = boot.access === "ok" ? boot.view.miner.pool : 0;
      const next = await action();
      setBoot({ access: "ok", view: next });
      const diff = next.miner.pool - before;
      if (diff > 0.000001) {
        setGain({ amount: diff, key: Date.now() });
        window.setTimeout(() => setGain(null), 2200);
      }
      return next;
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Action failed";
      if (msg.startsWith("Minimum")) showNotice(msg);
      else toast.error(msg);
      throw err;
    } finally {
      setBusy(false);
    }
  }

  if (boot.access === "telegram_required" && !booting) {
    return <TelegramOnly />;
  }
  if (!view) {
    return <SplashScreen slow={slow} />;
  }
  if (view.maintenance) {
    return <MaintenanceScreen text={view.maintenance.text} />;
  }

  const gated = view.channels.length > 0 && !view.channelMember;

  return (
    <div className="flex min-h-svh justify-center bg-tg">
      <div className="paper-app relative flex min-h-svh w-full max-w-[430px] flex-col">
        <header className="relative z-10 grid grid-cols-[1.25fr_1fr] gap-2.5 px-3 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
          <div className="plaque relative px-4 py-2.5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-muted">Balance</p>
            <p className="mt-1 flex items-center gap-2 font-display text-[24px] font-bold tabular-nums gold-text">
              <GoldCoin className="size-7" />
              {(Math.floor(view.miner.pool * 100 + 1e-9) / 100).toFixed(2)}
            </p>
            {gain ? (
              <span key={gain.key} className="gain-pop pointer-events-none absolute right-3 top-2 text-[15px] font-bold text-withdraw">
                +{formatMtp(gain.amount, 4)}
              </span>
            ) : null}
          </div>
          <div className="plaque flex items-center justify-center gap-2.5 px-3 py-2 text-center">
            <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-b from-[#6db1ff] to-[#2a63d6] text-[13px] font-bold text-white">{(view.miner.name.trim()[0] ?? "F").toUpperCase()}</span>
            <span className="line-clamp-2 break-words text-left text-[13px] font-semibold leading-tight text-ink">{view.miner.name}</span>
          </div>
        </header>
        {tab === "withdraw" && view.withdrawNotice && noticeOpen ? (
          <div
            id="withdraw-notice"
            key={shakeKey}
            role="alert"
            className={`relative z-10 mx-3 mb-2.5 rounded-2xl border border-danger/40 bg-danger/10 px-4 py-2.5 text-center text-[14px] font-semibold leading-snug text-danger backdrop-blur ${shakeKey > 0 ? "notice-shake" : ""}`}
          >
            {view.withdrawNotice}
          </div>
        ) : null}
        {notice ? (
          <div key={notice.key} className="relative z-10 mx-3 mb-2.5 rounded-2xl bg-gradient-to-b from-[#6db1ff] to-[#3d85f5] py-2 text-center text-[13px] font-semibold text-white shadow-lg">
            {notice.text}
          </div>
        ) : null}

        <div className="relative z-10 min-h-0 flex-1 overflow-y-auto pt-3">
          {tab === "game" ? (
            <GameView
              view={view}
              busy={busy}
              onStart={() => void run(() => startMiningFn())}
              onClaim={() => void run(() => claimFn())}
              onMinClaim={() => showNotice(`Minimum ${MIN_CLAIM}`)}
              onBuy={(index) => void run(() => buyBirdFn({ data: { index } }))}
            />
          ) : null}
          {tab === "deposit" ? (
            <DepositView view={view} busy={busy} onView={(next) => setBoot({ access: "ok", view: next })} onNotice={showNotice} />
          ) : null}
          {tab === "withdraw" ? (
            <WithdrawView
              view={view}
              busy={busy}
              onView={(next) => setBoot({ access: "ok", view: next })}
              onWithdraw={(amount, method) => void run(() => withdrawFn({ data: { amount, method } }))}
              onNotice={showNotice}
              onBlocked={pingWithdrawNotice}
            />
          ) : null}
          {tab === "referrals" ? (
            <ReferralsView
              view={view}
              busy={busy}
              onClaimCommission={() => void run(() => claimSquadCommissionFn())}
            />
          ) : null}
        </div>

        <TabBar value={tab} onChange={setTab} />
      </div>

      {gated ? (
        <JoinGate
          channels={view.channels}
          busy={busy}
          onCheck={async () => {
            try {
              const next = await run(() => checkChannelFn());
              return next.channelMember;
            } catch {
              return false;
            }
          }}
        />
      ) : null}

    </div>
  );
}
