import { toast } from "sonner";
import { REFERRAL_DEPOSIT_PERCENT } from "@/lib/mtp/config";
import type { MinerView } from "@/lib/mtp/types";
import { formatMtp } from "@/lib/utils";
import { useI18n } from "./i18n";
import { GoldCoin, LinkMark } from "./icons";

const ROW = "grid grid-cols-[1.3fr_1fr_0.9fr_0.9fr] items-center px-4 text-[12px] font-semibold text-ink";

export function ReferralsView({
  view,
  busy,
  onClaimCommission,
}: {
  view: MinerView;
  busy: boolean;
  onClaimCommission: () => void;
}) {
  const { t } = useI18n();
  const link = view.inviteLink;
  const unclaimed = view.commissionUnclaimed;

  return (
    <section className="relative z-10 flex flex-col gap-3.5 px-3 pb-8 pt-1">
      <div className="paper-card p-4">
        <div className="grid grid-cols-[1.1fr_1fr] gap-3">
          <div className="slot-cell px-2 py-2 text-center">
            <p className="flex items-center justify-center gap-1.5 text-[14px] font-semibold leading-tight">
              <span>{t("totalIncome")}</span>
              <GoldCoin className="size-4" />
            </p>
            <p className="mt-0.5 text-[16px] font-bold tabular-nums gold-text">{formatMtp(view.miner.squadEarned, 2)}</p>
          </div>
          <div className="slot-cell flex items-center justify-center gap-3 rounded-md px-2 py-2 text-[14px] font-semibold">
            <span>{t("referralsLabel")}</span>
            <span className="text-[16px] font-extrabold tabular-nums">{view.miner.squadCount}</span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-[auto_1fr_auto] items-center gap-3">
          <GoldCoin className="size-9" />
          <div className="field-box flex h-11 items-center px-3 text-[15px] font-semibold tabular-nums text-ink">
            {formatMtp(unclaimed, 2)}
          </div>
          <button
            type="button"
            disabled={busy || unclaimed <= 0}
            onClick={onClaimCommission}
            className="btn-collect h-11 w-32 rounded-full font-display text-[13px] font-extrabold uppercase tracking-[0.12em] disabled:opacity-60"
          >
            {t("collect")}
          </button>
        </div>

        <div className="mt-3 grid grid-cols-[auto_1fr_auto] items-center gap-3">
          <LinkMark className="size-9" />
          <div className="field-box flex h-11 items-center overflow-hidden px-3">
            <span className="truncate text-[11px] font-semibold text-ink">{link}</span>
          </div>
          <button
            type="button"
            className="btn-collect h-11 w-32 rounded-full font-display text-[13px] font-extrabold uppercase tracking-[0.12em]"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(link);
                toast.success(t("copied"));
              } catch {
                toast.error("Could not copy");
              }
            }}
          >
            {t("copy")}
          </button>
        </div>

        <div className="mt-4 flex items-center gap-4 rounded-2xl bg-gradient-to-br from-[#d8b46a]/15 to-transparent px-4 py-3.5 ring-1 ring-[#d8b46a]/25">
          <p className="font-display text-[34px] font-bold leading-none gold-text">{Math.round(REFERRAL_DEPOSIT_PERCENT * 100)}%</p>
          <p className="text-[13px] font-medium leading-snug text-muted">{t("fromReplenish")}</p>
        </div>
      </div>

      <div className="plaque py-3 text-muted">
        <div className={`${ROW} text-[10px] uppercase tracking-[0.18em]`}>
          <span>{t("date")}</span>
          <span>{t("user")}</span>
          <span>{t("deposit")}</span>
          <span>{t("income")}</span>
        </div>
      </div>

      {view.referralHistory.length === 0 ? null : (
        <div className="plaque py-1">
          {view.referralHistory.map((row) => (
            <div key={row.id} className={`${ROW} py-2.5 font-semibold`}>
              <span className="tabular-nums">
                {new Date(row.createdAt).toLocaleString("en-GB", {
                  day: "2-digit",
                  month: "2-digit",
                  year: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
              <span className="truncate">{row.note ?? "—"}</span>
              <span className="flex items-center gap-1 tabular-nums">
                <GoldCoin className="size-3.5" />
                {formatMtp(row.deposit ?? 0, 2)}
              </span>
              <span className="flex items-center gap-1 tabular-nums">
                <GoldCoin className="size-3.5" />
                {formatMtp(row.amount, 2)}
              </span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
