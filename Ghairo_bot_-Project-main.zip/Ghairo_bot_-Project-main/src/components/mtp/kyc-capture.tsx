import { CheckCircle2, Video } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import type { LivenessStatus } from "@/lib/mtp/types";

const RECORD_MS = 8000;

type Phase = "idle" | "recording" | "uploading" | "done" | "error";

/**
 * Records a short front-camera selfie clip and uploads it for admin KYC review.
 * Unlike the old liveness check, nothing is scored on-device — a human reviews the video.
 */
export function KycCapture({
  status,
  onSubmitted,
}: {
  status?: LivenessStatus;
  onSubmitted: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedRef = useRef(0);
  const [phase, setPhase] = useState<Phase>("idle");
  const [remaining, setRemaining] = useState(RECORD_MS / 1000);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => stopStream, []);

  function stopStream() {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }

  async function start() {
    setError(null);
    chunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 480 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (video) {
        video.srcObject = stream;
        await video.play();
      }
      const mimeType = ["video/webm;codecs=vp8", "video/webm", "video/mp4"].find(
        (type) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(type),
      );
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      recorderRef.current = recorder;
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => void finish();
      startedRef.current = Date.now();
      recorder.start();
      setPhase("recording");
      setRemaining(RECORD_MS / 1000);
      const tick = window.setInterval(() => {
        const left = Math.max(0, RECORD_MS - (Date.now() - startedRef.current));
        setRemaining(Math.ceil(left / 1000));
        if (left <= 0) {
          window.clearInterval(tick);
          if (recorderRef.current?.state === "recording") recorderRef.current.stop();
        }
      }, 200);
    } catch (err) {
      stopStream();
      setPhase("error");
      setError(
        err instanceof Error && err.name === "NotAllowedError"
          ? "Camera access was denied. Allow camera access, then try again."
          : "Could not start the camera.",
      );
    }
  }

  async function finish() {
    const durationMs = Date.now() - startedRef.current;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    const blob = new Blob(chunksRef.current, { type: recorderRef.current?.mimeType || "video/webm" });
    if (blob.size === 0) {
      setPhase("error");
      setError("No video was captured. Please try again.");
      return;
    }
    setPhase("uploading");
    try {
      const tg = window.Telegram?.WebApp;
      const form = new FormData();
      form.set("initData", tg?.initData || "");
      form.set("durationMs", String(durationMs));
      form.set("video", blob, "kyc.webm");
      const res = await fetch("/api/kyc-submit", { method: "POST", body: form });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!res.ok || !data?.ok) {
        throw new Error(data?.error || "Could not submit your video. Please try again.");
      }
      setPhase("done");
      onSubmitted();
      window.setTimeout(() => tg?.close?.(), 1800);
    } catch (err) {
      setPhase("error");
      setError(err instanceof Error ? err.message : "Upload failed.");
    }
  }

  if (status === "pending" && phase === "idle") {
    return (
      <div className="flex flex-col items-center gap-2 rounded-2xl bg-surface px-4 py-10 text-center shadow-border">
        <CheckCircle2 className="size-6 text-mint" />
        <p className="text-sm text-fg">Submitted for review</p>
        <p className="text-xs text-muted">You will get a message here once an admin checks it.</p>
      </div>
    );
  }

  if (phase === "done") {
    return (
      <div className="flex flex-col items-center gap-2 rounded-2xl bg-surface px-4 py-10 text-center shadow-border">
        <CheckCircle2 className="size-6 text-mint" />
        <p className="text-sm text-fg">Submitted for review</p>
        <p className="text-xs text-muted">Closing…</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 rounded-2xl bg-surface p-4 shadow-border">
      <div className="relative aspect-square w-full overflow-hidden rounded-xl bg-elevated">
        <video ref={videoRef} playsInline muted className="size-full object-cover" />
        {phase === "recording" ? (
          <span className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-danger/90 px-2 py-1 text-[11px] font-medium text-white">
            <span className="size-1.5 animate-pulse rounded-full bg-white" />
            {remaining}s
          </span>
        ) : null}
      </div>

      {phase === "idle" || phase === "error" ? (
        <>
          <p className="text-xs text-muted">
            Look at the camera for {RECORD_MS / 1000} seconds. This clip is reviewed by an admin only.
          </p>
          {error ? <p className="text-xs text-danger">{error}</p> : null}
          <Button className="w-full" onClick={() => void start()}>
            <Video className="size-4" />
            Start recording
          </Button>
        </>
      ) : phase === "recording" ? (
        <p className="text-center text-xs text-muted">Recording… hold still.</p>
      ) : (
        <p className="text-center text-xs text-muted">Submitting…</p>
      )}
    </div>
  );
}
