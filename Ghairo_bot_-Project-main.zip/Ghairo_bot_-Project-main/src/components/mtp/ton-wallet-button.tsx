import { useEffect, useRef, useState } from "react";
import { Link2Off, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { shortAddress } from "@/lib/utils";
import { CopyText } from "./copy-text";
import { getTonUi } from "./ton-ui";

type TonUi = {
  openModal: () => Promise<void>;
  disconnect: () => Promise<void>;
  onStatusChange: (fn: (wallet: TonWallet | null) => void) => () => void;
};

type TonWallet = {
  account?: { address?: string };
  device?: { appName?: string };
};

function crc16(data: Uint8Array): number {
  let crc = 0;
  for (const byte of data) {
    crc ^= byte << 8;
    for (let i = 0; i < 8; i += 1) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc;
}

// Raw "0:<64 hex>" -> user-friendly non-bounceable "UQ..." (same form Tonkeeper shows).
// Anything that is not a raw address is returned unchanged.
function rawToFriendly(raw: string): string {
  const m = /^(-?\d+):([0-9a-fA-F]{64})$/.exec(raw.trim());
  if (!m) return raw;
  const workchain = Number(m[1]);
  if (workchain !== 0 && workchain !== -1) return raw;
  const bytes = new Uint8Array(36);
  bytes[0] = 0x51;
  bytes[1] = workchain & 0xff;
  for (let i = 0; i < 32; i += 1) {
    bytes[2 + i] = parseInt(m[2]!.slice(i * 2, i * 2 + 2), 16);
  }
  const crc = crc16(bytes.subarray(0, 34));
  bytes[34] = crc >> 8;
  bytes[35] = crc & 0xff;
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_");
}

export function TonWalletButton({
  address,
  provider,
  busy,
  onConnected,
  onDisconnected,
}: {
  address?: string;
  provider?: string;
  busy?: boolean;
  onConnected: (address: string, provider: string) => void;
  onDisconnected: () => void;
}) {
  const [ui, setUi] = useState<TonUi | null>(null);
  const [friendly, setFriendly] = useState(address ? rawToFriendly(address) : "");
  const connected = useRef(onConnected);
  const disconnected = useRef(onDisconnected);
  const sawWallet = useRef(false);
  connected.current = onConnected;
  disconnected.current = onDisconnected;

  useEffect(() => {
    let unsub: (() => void) | undefined;
    let cancelled = false;
    void (async () => {
      try {
        const instance = await getTonUi();
        unsub = instance.onStatusChange((wallet) => {
          const raw = wallet?.account?.address;
          if (raw) {
            sawWallet.current = true;
            setFriendly(rawToFriendly(raw));
            connected.current(raw, wallet?.device?.appName || "TON");
          } else if (sawWallet.current) {
            sawWallet.current = false;
            setFriendly("");
            disconnected.current();
          }
        });
        if (!cancelled) setUi(instance as unknown as TonUi);
      } catch (err) {
        console.error("[mtp] TonConnect failed to load", err);
      }
    })();
    return () => {
      cancelled = true;
      unsub?.();
    };
  }, []);

  useEffect(() => {
    if (address) setFriendly(rawToFriendly(address));
  }, [address]);

  if (address) {
    return (
      <div className="flex flex-col gap-2">
        <div className="rounded-xl bg-elevated px-3 py-3 shadow-border">
          <p className="text-[11px] font-medium uppercase tracking-[0.14em] text-subtle">
            Connected{provider ? ` · ${provider}` : ""}
          </p>
          <p className="mt-1 break-all font-mono text-sm text-fg">
            <CopyText value={friendly || address} label="Address copied">
              {shortAddress(friendly || address)}
            </CopyText>
          </p>
        </div>
        <Button
          variant="secondary"
          className="w-full"
          disabled={busy}
          onClick={() => {
            sawWallet.current = false;
            void ui?.disconnect();
            onDisconnected();
          }}
        >
          <Link2Off className="size-4" />
          Disconnect
        </Button>
      </div>
    );
  }

  return (
    <Button
      size="lg"
      className="w-full"
      disabled={busy}
      onClick={() => {
        void ui?.openModal();
      }}
    >
      <Wallet className="size-4" />
      Connect
    </Button>
  );
      }
